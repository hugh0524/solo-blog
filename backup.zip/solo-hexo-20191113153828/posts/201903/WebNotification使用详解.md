title: Web Notification使用详解
date: '2019-03-06 17:06:33'
updated: '2019-03-06 17:06:33'
tags: [notification, web, js]
permalink: /articles/2019/03/06/1551862945596.html
---
<h2>1. notication Api</h2>
<p>用于向用户发送桌面通知，在MAC上会同步到系统通知内</p>
<h2>2. 构造方法</h2>
<pre class="line-numbers language-html"><code class=" language-html">let notification = new Notification(title, options)</code></pre>
<h3 id="参数" class="highlight-spanned">参数</h3>
<dl><dt><code>title</code></dt><dd>一定会被显示的通知标题</dd><dt><code>options</code>&nbsp;<span class="inlineIndicator optional optionalInline">可选</span></dt><dd>一个被允许用来设置通知的对象。它包含以下属性：
<ul>
<li><code>dir</code>&nbsp;: 文字的方向；它的值可以是&nbsp;<code>auto（自动）</code>,&nbsp;<code>ltr（从左到右）</code>, or&nbsp;<code>rtl</code>（从右到左）</li>
<li><code>lang</code>: 指定通知中所使用的语言。这个字符串必须在&nbsp;<a rel="noopener" href="http://tools.ietf.org/html/bcp47" class="external external-icon" title="http://tools.ietf.org/html/bcp47">BCP 47 language tag</a>&nbsp;文档中是有效的。</li>
<li><code>body</code>: 通知中额外显示的字符串</li>
<li><code>tag</code>: 赋予通知一个ID，以便在必要的时候对通知进行刷新、替换或移除。</li>
<li><code>icon</code>: 一个图片的URL，将被用于显示通知的图标。</li>
</ul>
</dd></dl>
<p>&nbsp;</p>
<h3>属性：</h3>
<p><code>Notification.permission</code></p>
<p><code>&nbsp;- denied</code><span>&nbsp;(用户拒绝了通知的显示),</span></p>
<p><span>&nbsp; -&nbsp;</span><code>granted</code><span>&nbsp;(用户允许了通知的显示),&nbsp;</span></p>
<p><span>&nbsp; -&nbsp;</span><code>default</code><span>&nbsp;(因为不知道用户的选择，所以浏览器的行为与 denied 时相同).</span></p>
<p>&nbsp;</p>
<h3>事件</h3>
<p>&nbsp;click&nbsp; 点击通知信息时触发</p>
<p>&nbsp;error 遇到错误时触发</p>
<p>&nbsp;close 关闭通知时触发</p>
<p>&nbsp;show 显示通知时触发</p>
<p>&nbsp;</p>
<h3>方法</h3>
<p>静态方法&nbsp; Notification.<code>requestPermission()&nbsp;&nbsp;</code></p>
<p>&nbsp; &nbsp;用于向用户请求显示通知的权限， 具备一个回调， 获取到用户选择的授权。 只有在触发用户行为时才能被调用（如果onclick）</p>
<p>实例方法：</p>
<pre class="line-numbers language-html"><code class=" language-html">notification.close() 关闭通知<br /><br /></code></pre>
<p>&nbsp;</p>
<h2>3. 使用流程</h2>
<p>1. 选择触发时机</p>
<p>2. 调用静态属性查询是否有权限， 如果没有权限，调用静态方法申请权限</p>
<p>3. 获得权限后初始化Notication实例</p>
<p>4. 如果需要监听相关事件， 在实例上进行绑定</p>
<p><a href="https://tools.uproject.cn/tools/showDemo?id=11" target="_blank">案例</a></p>
<h2>4. 如果收到点击了拒绝， 如果再次开启通知</h2>
<p>以chrome为例，打开设置， 在允许一项中添加即可</p>
<pre class="brush: js"><a href="http://tools.uproject.cn/upload/article/1551862831219.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/1551862831219.jpg" alt="" width="404" height="323" /></a></pre>
<p>&nbsp;</p>
<p>&nbsp;</p>