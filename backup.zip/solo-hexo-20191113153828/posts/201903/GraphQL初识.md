title: GraphQL初识
date: '2019-03-18 15:37:16'
updated: '2019-03-18 16:03:16'
tags: [web, node, js, graphql]
permalink: /articles/2019/03/18/1552894450539.html
---

  
# 复习下restful API
1. 在RESTful架构中，每个网址代表一种资源（resource）
2. 对于资源的具体操作类型，由HTTP动词表示。
3. API应该提供参数，过滤返回结果。
4. 合理利用http状态码
5. document, Hypermedia APIs (swagger)

# graphql
## 是什么
GraphQL 是一个用于 API 的查询语言，是一个使用基于类型系统来执行查询的服务端运行时（类型系统由你的数据定义）。GraphQL 并没有和任何特定数据库或者存储引擎绑定，而是依靠你现有的代码和数据支撑。
## 优势
1. 解决问题  
   1. 填充一个视图需要的数据进行多次往返拉取
   2. 客户端对服务端产生依赖
   3. 糟糕的前端开发体验
2. VS RESTFUL
   ![image](https://user-gold-cdn.xitu.io/2017/7/27/8939020a45471f20e8b3d08790e11c2c?imageView2/0/w/1280/h/960/ignore-error/1)
    
    
## 知识点简介
1. 应用方式
    ![image](https://gtms01.alicdn.com/tps/i1/TB1MXPNLpXXXXaqXVXX1m7LTXXX-2040-1532.png )


2. Schema 编写
   1. 标量类型：Int、Float、String、Boolean、 ID
>      b: Int  c:String
   2. 枚举、列表[String]、非空类型 ！
    >   enum type {
        a 
        b 
     }
   
  3. 接口类型、联合类型、用户输入类型
   4. 操作对象- query、mutation
 > type Query { 
    method(param: Type): returnType
   }
   
3. Query & Mutation

> 如何进行查询 及操作


## 可能遇到的问题
1. 数据关联查询
2. 查询N+1问题 （dataLoader）
3. 如何调试
4. 分页查询
5. 是否一定需要一个中心化的节点





# sass cms（待续）
1. 业务设计 
  
2. 功能


# 参考文档
1. [Graphql](http://graphql.cn/learn/queries/#fields) 
2. [graphql-tools](https://www.apollographql.com/docs/graphql-tools/) 
3. [restful design](https://codeplanet.io/principles-good-restful-api-design/)
4. [art-template](http://aui.github.io/art-template/zh-cn/docs/imports.html)