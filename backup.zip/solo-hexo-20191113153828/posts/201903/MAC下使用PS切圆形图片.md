title: MAC 下使用PS切圆形图片
date: '2019-03-09 09:57:24'
updated: '2019-03-09 09:57:24'
tags: [ps, 切图, 切圆形, web, 前端]
permalink: /articles/2019/03/09/1552096644510.html
---
<h2>1. 需求</h2>
<p>&nbsp; 需要在一个大图上，保留一个圆形的区域</p>
<p>&nbsp;</p>
<h2>2. 做法</h2>
<p>&nbsp; &nbsp;a. 选择图片， 打开ps</p>
<p>&nbsp; &nbsp;b. 首先使用椭圆选择工具，&nbsp;</p>
<p>&nbsp; &nbsp;<a href="http://tools.uproject.cn/upload/article/1552096292493.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/1552096292493.jpg" alt="" width="400" height="299" /></a></p>
<p>&nbsp; c. 按住shift键， 使选择区域是一个正圆形。 画出一个合适大小的圆</p>
<p><a href="http://tools.uproject.cn/upload/article/1552096421244.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/1552096421244.jpg" alt="" width="400" height="261" /></a></p>
<p>&nbsp; d. 移动圆形到合适位置， 使用command + J， 会将除选取区域外的内容删除，变成空白背景。 选择图层， 取消背景。</p>
<p><a href="http://tools.uproject.cn/upload/article/1552096546092.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/1552096546092.jpg" alt="" width="400" height="207" /></a></p>
<p>e. 最后使用裁剪工具，裁剪成合适大小即可</p>