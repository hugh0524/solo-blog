title: js中call用法
date: '2016-05-04 13:16:28'
updated: '2016-05-04 13:16:28'
tags: [前端, web, call, js]
permalink: /articles/2016/05/04/1462334242036.html
---
<p>一、使用call继承对象方法</p>
<pre class="brush: js">function a(){
  this.m1=function(){
      console.log("a-m1-n");
  }
}
a.prototype.m2=function(){
  console.log("a-m1-p");
}
a.m3=function(){
  console.log("a-m3-l");
}

function b(){
    a.call(this);
}
var nb = new b();

nb.m1();//a-m1-n
nb.m2();//error
nb.m3();//error
</pre>
<p>二、使用call、apply调用其他对象的方法</p>
<p>eg1:判断对象类型</p>
<pre class="brush: js">var o = []
Object.prototype.toString.call(o) == "[object Array]"//true</pre>
<p>eg2:让对象具备Array的能力</p>
<pre class="brush: js">var dnode = document.getElementsByTagName("input")

dnode = Array.prototype.slice.call(dnode)

dnode.length//3

dnode.join("===")//"[object HTMLInputElement]===[object HTMLInputElement]===[object HTMLInputElement]"
</pre>
<p>eg3：</p>
<pre class="brush: js">function Animal(){
}
Animal.prototype={
  food:"",
  say: function(){
    alert("I love "+this.food);
  }
}

function dog(){
}
dog.prototype={
  food:"meat"
}
function cat(){
}
cat.prototype={
  food:"fish"
}

var animal = new Animal();
animal.say.call(new cat());//i love fish
animal.say.call(new dog());//i love meat
</pre>