title: Express + GraphQL构建简单的cms框架DEMO
date: '2019-04-03 23:13:26'
updated: '2019-04-22 10:06:59'
tags: [node, web, 前端, graphql, express]
permalink: /articles/2019/04/03/1554276742410.html
---
<h2>1. 技术选择</h2>
<p>Express + <a href="https://blog.uproject.cn/articles/2019/03/18/1552894450539.html" target="_blank">GraphQL</a> + VUE + mysql</p>
<p><a href="https://github.com/hugh0524/graphcmsdemo" target="_parent">gitHub地址</a></p>
<p><a href="https://gitee.com/yixi524/graphcmsdemo/settings" target="_blank">gitee地址&nbsp;</a></p>
<h2>2. 实现目标</h2>
<p>a. 实现创建cms系统及相应业务界面</p>
<p>b. 实现组件关联</p>
<p>c. 实现页面可编辑</p>
<p>&nbsp;</p>
<h2>3. 插件选择</h2>
<p>a. express-graphql - 用于集成graphql到express框架中</p>
<p>b. vue-apollo &amp; vue-apollo - 用于在client端调用graphql的接口</p>
<p>c. graphql-tools - 帮助我们使用js更方便的构建graphql schame</p>
<p>&nbsp;</p>
<h2>4. demo运行示意图</h2>
<h2><a href="http://tools.uproject.cn/upload/article/demo-cms-1.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/demo-cms-1.jpg" alt="" width="300" height="137" /></a><a href="http://tools.uproject.cn/upload/article/demo-cms-2.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/demo-cms-2.jpg" alt="" width="300" height="93" /></a><a href="http://tools.uproject.cn/upload/article/demo-cms-3.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/demo-cms-3.jpg" alt="" width="300" height="150" /></a><a href="http://tools.uproject.cn/upload/article/demo-cms-4.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/demo-cms-4.jpg" alt="" width="300" height="147" /></a><a href="http://tools.uproject.cn/upload/article/demo-cms-5.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/demo-cms-5.jpg" alt="" width="300" height="160" /></a><a href="http://tools.uproject.cn/upload/article/demo-cms-2.jpg" class="fancybox" data-fancybox-group="group"></a></h2>
<p>&nbsp;</p>
<h2>5. 具体实现分解</h2>
<h3>1. 首先分析graphql的特点</h3>
<p>主要包含以下内容 1个schame, 5种基本类型+3中扩展类型+自定义类型， 2种主要操作query&amp;mutation</p>
<h3>2.&nbsp; 如何构建一个可用的schame，详情见第3步</h3>
<p>如果使用官方的graphql库，示例操作如下</p>
<pre class="prettyprint">npm install graphql</pre>
<p>构建schame如下</p>
<pre class="prettyprint">var {
  GraphQLList,
  GraphQLObjectType,
  GraphQLSchema,
  GraphQLString,
  GraphQLInt,
  GraphQLFloat,
  GraphQLEnumType,
  GraphQLNonNull,
  GraphQLInterfaceType,
  GraphQLInputObjectType
} = require('graphql');

const componentsSchema = require('./components');
const themesSchema = require('./themes');

const testSchema = require('./test');

const Query=new GraphQLObjectType({
  name:'CommonQuery',
  description:'通用查询',
  fields:()=&gt;(Object.assign({},
    componentsSchema.query,
    themesSchema.query,
    testSchema.query
  ))
});
const Mutation=new GraphQLObjectType({
  name:'CommonMutation',
  description:'通用编辑',
  fields:()=&gt;(Object.assign({},
    componentsSchema.mutation
  ))
});
const schema = new GraphQLSchema({
  query: Query,
  mutation: Mutation
});

module.exports = schema;</pre>
<p>&nbsp;</p>
<p>或者</p>
<pre class="prettyprint">var { graphql, buildSchema } = require('graphql');

var schema = buildSchema(`
  type Query {
    hello: String
  }
`);</pre>
<p>&nbsp;</p>
<p>再配合express-graphql</p>
<pre class="prettyprint">var graphqlHTTP = require('express-graphql');

app.use('/graphql2', graphqlHTTP({
  schema: schemas,
  graphiql: true
}));</pre>
<p>&nbsp;</p>
<p>测试访问&nbsp;http://localhost:9004/graphql2</p>
<p><a href="http://tools.uproject.cn/upload/article/demo-cms-run-1.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/demo-cms-run-1.jpg" alt="" width="400" height="267" /></a></p>
<p>&nbsp;</p>
<h3>3. 基于业务特点构建通用的schame模板</h3>
<h4>a. 基于单表的增删改查</h4>
<p>&nbsp;我们已经了解到graphql实现的是类似controller/action层的功能， 那单表增删改查操作其实就是普通的数据库操作了，利用mysql库，<a href="https://github.com/hugh0524/graphcmsdemo/blob/master/server/utils/DB.js" target="_blank">可以轻松实现</a></p>
<h4>b. 使用第2步介绍的库构建schema</h4>
<p>首先定义一张组件表</p>
<p><a href="http://tools.uproject.cn/upload/article/1555143574072.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/1555143574072.jpg" alt="" width="404" height="68" /></a></p>
<h4>&nbsp;c. 定义针对组件表的查询、新增功能</h4>
<pre class="prettyprint">var daoUtil = new BaseDao();
const tableName = "m_components";

const Components = new GraphQLObjectType({
  name:'Components',
  description:"组件对象POJO",
  fields: () =&gt; {
    return ({
      id: {type: new GraphQLNonNull(GraphQLInt)},
      name: {type: new GraphQLNonNull(GraphQLString)},
      theme: {type: new GraphQLNonNull(GraphQLInt)},
      frontShow: {type: GraphQLString},
      backShow: {type: GraphQLString},
      createAt: {type: GraphQLString},
      createBy: {type: new GraphQLNonNull(GraphQLInt)},
    });
  }
});

module.exports = {
  query: {
    components_list: {
      type: new GraphQLList(Components),
      description: '查询组件列表',
      resolve: async function(source) {
        return (await daoUtil.queryAll(tableName));
      }
    }
  },
  mutation: {
    components_add: {
      type: Components,
      description: '添加组件',
      args: {
        id: {type: GraphQLInt},
        name: {type: new GraphQLNonNull(GraphQLString)},
        theme: {type: new GraphQLNonNull(GraphQLString)},
      },
      resolve: async function(source, {id, name, theme}) {
        var user = {
          name: name,
          theme: theme,
        };
        return await daoUtil.insert(tableName, user);
      }
    }
  }
}
</pre>
<p>&nbsp;</p>
<h4>d. 使用自带的graphql编辑器测试</h4>
<p>使用方法见：<a href="https://blog.uproject.cn/articles/2019/04/13/1555144783576.html" target="_blank">graphiql</a></p>
<h3>4. 使用模板自动构建schame</h3>
<p>常见的schame构建如上, 基于此，我们抽取出公共的部分， 使用模板生成对应对象的所有操作</p>
<h4>a. 模板分析</h4>
<p>模板中应该具备对象的可操作列表， 入参、返回</p>
<pre class="prettyprint">type Query {
 {{each $data}}
  {{$value.name}}_all: [{{$value.modal}}]
  {{$value.name}}_page(page: Int!,limit: Int!, where:[where_query]): {{$value.modal}}_page
  {{$value.name}}_byId(id: Int!): {{$value.modal}}
  {{$value.name}}_byField({{each $value.columns}}  {{$value.Field}}:{{$value.fieldType}}, {{/each}}): [{{$value.modal}}]
 {{/each}}
}

type Mutation {
  {{each $data}}
    {{$value.name}}_add( {{each $value.columns}} {{if !$value.unUserInMutation}} {{$value.Field}}:{{$value.Type}},{{/if}} {{/each}} ): {{$value.modal}}
    {{$value.name}}_batch(list: [{{$value.modal}}_mutation]!): batch_result
    {{$value.name}}_delete(id: Int!): batch_result
    {{$value.name}}_updateById({{each $value.columns}}  {{$value.Field}}:{{$value.fieldType}}, {{/each}}): {{$value.modal}}
  {{/each}}
}</pre>
<p>以上是对外提供的query和Mutation。 $data为所有对象的list</p>
<p>{{$value.modal}} 对应了创建的每个对象在schame中对应的可操作对象</p>
<pre class="prettyprint">type {{$value.modal}} {
  {{each $value.columns }}
    {{$value.Field}}:{{$value.Type}}
  {{/each}}
  {{each $value.relations relation}}
    {{relation.modal}}:{{if relation.type == 'o2o'}} {{relation.modal}} {{/if}}{{if relation.type == 'o2m'}} [{{relation.modal}}] {{/if}}
  {{/each}}
}</pre>
<p>&nbsp;{{$value.modal}}_page 对应了构建的分页对象在schame中对应的对象</p>
<pre class="prettyprint">type {{$value.modal}}_page {
  page: Int!,
  limit: Int!,
  list: [{{$value.modal}}],
  total: Int!
}</pre>
<p>最后，通过以下代码封装操作</p>
<pre class="prettyprint">schema {
  query: Query
  mutation: Mutation
}</pre>
<h4>b. 调用模板方法渲染方法，同时构建schame对象</h4>
<pre class="prettyprint">var gql = template(this.artPath, data);
      // console.log(gql)
      let typeDefs = `${gql}`
      let jsSchema = makeExecutableSchema({
        typeDefs,
        resolvers,
      });</pre>
<h3>5. 其他</h3>
<h4>a. 如何实现关联查询</h4>
<p>通过定义一个配置文件， 管理对象间的关系</p>
<pre class="prettyprint">"m_components": [{
      "type": "o2m",
      "field": "id",
      "targetTable": "m_component_props",
      "targetField": "componentId"
    },{
      "type": "o2o",
      "field": "theme",
      "targetTable": "m_theme",
      "targetField": "id"
    }]</pre>
<p>通过schame绑定查询关系</p>
<pre class="prettyprint">{{each $value.relations relation}}
    {{relation.modal}}:{{if relation.type == 'o2o'}} {{relation.modal}} {{/if}}{{if relation.type == 'o2m'}} [{{relation.modal}}] {{/if}}
  {{/each}}</pre>
<h4>b. 如何解决N+1查询问题</h4>
<p>由于graphql会根据schame,一层层解析，最终返回结果，导致关联查询时，会出现N+1查询的问题</p>
<p>解决N+1查询的基本方法就是讲查询条件集中到一个sql中</p>
<p>在我们的范例中， 可以利用resolver中context对象在各个resolver间传递， 结合关系查询配置， 在父节点中集成查询，然后传递到子resolver中返回</p>
<p>resolver中接受参数如下</p>
<ul>
<li><code>obj</code>&nbsp;上一级对象，如果字段属于根节点查询类型通常不会被使用。</li>
<li><code>args</code>&nbsp;可以提供在 GraphQL 查询中传入的参数。</li>
<li><code>context</code>&nbsp;会被提供给所有解析器，并且持有重要的上下文信息比如当前登入的用户或者数据库访问对象。</li>
<li><code>info</code>&nbsp;一个保存与当前查询相关的字段特定信息以及 schema 详细信息的值</li>
</ul>
<p>&nbsp;</p>
<p>============================完结==============</p>
<p>&nbsp;</p>
<p><img src="https://badge.juejin.im/entry/5cbd218ff265da037a3ce9ec/likes.svg?style=flat-square" alt="" /></p>