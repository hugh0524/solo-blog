title: Graphiql使用
date: '2019-04-14 13:51:53'
updated: '2019-04-14 15:44:59'
tags: [graphql, graphiql]
permalink: /articles/2019/04/13/1555144783576.html
---
<h2>1. 生成schame及发布api过程参考：<a href="https://blog.uproject.cn/articles/2019/04/03/1554276742410.html" target="_blank">Demo</a></h2>
<h2>2. 了解graphiql， 它是graphql服务内置的一个编辑器， 将graphql接口文档化， 同时提供便捷调用的能力</h2>
<p>&nbsp; a. graphiql长啥样</p>
<p><a href="http://tools.uproject.cn/upload/article/1555144715921.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/1555144715921.jpg" alt="" width="654" height="326" /></a></p>
<p>&nbsp;</p>
<p>b. 查询或更新字段解释</p>
<p><a href="http://tools.uproject.cn/upload/article/1555145385122.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/1555145385122.jpg" alt="" width="388" height="373" /></a></p>
<h2>3. 使用方法</h2>
<p>1. 查询</p>
<blockquote>
<p>您可以将 GraphQL 查询中的每个字段视为返回子类型的父类型函数或方法。事实上，这正是 GraphQL 的工作原理。每个类型的每个字段都由一个&nbsp;<em>resolver</em>&nbsp;函数支持，该函数由 GraphQL 服务器开发人员提供。当一个字段被执行时，相应的&nbsp;<em>resolver</em>&nbsp;被调用以产生下一个值。</p>
<p>如果字段产生标量值，例如字符串或数字，则执行完成。如果一个字段产生一个对象，则该查询将继续执行该对象对应字段的解析器，直到生成标量值。GraphQL 查询始终以标量值结束。</p>
<p>&nbsp;</p>
</blockquote>
<p>a. 查询单表所有数据</p>
<p><a href="http://tools.uproject.cn/upload/article/1555145727142.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/1555145727142.jpg" alt="" width="400" height="178" /></a>&nbsp;</p>
<p>&nbsp;b. 按查询条件查询</p>
<p><a href="http://tools.uproject.cn/upload/article/1555145940838.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/1555145940838.jpg" alt="" width="400" height="151" /></a></p>
<p>c. 一对一 或 一对多关联查询</p>
<p><a href="http://tools.uproject.cn/upload/article/1555146348204.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/1555146348204.jpg" alt="" width="400" height="158" /></a></p>
<p>d. 分页查询，等同于条件查询</p>
<p><a href="http://tools.uproject.cn/upload/article/1555146512168.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/1555146512168.jpg" alt="" width="400" height="78" /></a></p>
<p>2. 更新、删除、新增</p>
<p>a. 新增</p>
<p><a href="http://tools.uproject.cn/upload/article/1555147085832.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/1555147085832.jpg" alt="" width="400" height="173" /></a>&nbsp;</p>
<p>b. 删除</p>
<p><a href="http://tools.uproject.cn/upload/article/1555220705318.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/1555220705318.jpg" alt="" width="400" height="106" /></a></p>
<p>c. 修改</p>
<p><a href="http://tools.uproject.cn/upload/article/1555221021098.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/1555221021098.jpg" alt="" width="400" height="142" /></a></p>