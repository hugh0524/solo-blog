title: 字符串解析成json
date: '2017-06-01 10:34:46'
updated: '2017-06-01 10:34:46'
tags: [parse, json, 前端, web, js]
permalink: /articles/2017/06/01/1496284485870.html
---
<h2>1、eval</h2>
<pre class="brush: js"> eval("({a:1})")</pre>
<p>&nbsp;</p>
<h2>2、JSON对象</h2>
<p>ie8以上支持JSON对象</p>
<pre class="brush: js">JSON.parse(jsonString)</pre>
<p>&nbsp;</p>
<h2>3、Function</h2>
<pre class="brush: js">new Function ([arg1[, arg2[, ...argN]],] functionBody)</pre>
<p>eg:</p>
<pre class="brush: js">function parseJson(jsonString){
  return new Function("return " + jsonString)()
}</pre>
<p>&nbsp;</p>
<p>调用：</p>
<p>parseJson("{a:1,b:2}")// {a:1,b:2}</p>