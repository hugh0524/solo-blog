title: 【Exception】canvas调用toDataURL报security exception
date: '2017-06-30 14:24:56'
updated: '2017-06-30 14:37:48'
tags: [canvas, js, exception, web, 前端]
permalink: /articles/2017/06/05/1496652336416.html
---
<h2>1、原因</h2>
<p>toDataURL的canvas元素有用到跨域的图片</p>
<p>如果前端选择图片并转化成base64写入canvas，也会有这个问题</p>
<p>&nbsp;</p>
<h2>2、解决方案</h2>
<p>如果有使用background,先转换成img标签</p>
<p>1）图片加 crossOrigin = "anonymous"&nbsp;</p>
<p>&nbsp; &nbsp;</p>
<p>2）加mete(未测试)</p>
<pre><code>&lt;meta http-equiv="Content-Security-Policy" content="default-src *; script-src *;img-src * 'self' data: http:;"&gt;<br /><br /><br /></code></pre>
<p>3）现将图片上传至同域服务器，在使用img加载该图片</p>