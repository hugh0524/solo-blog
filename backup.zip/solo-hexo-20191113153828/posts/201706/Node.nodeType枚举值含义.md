title: Node.nodeType枚举值含义
date: '2017-06-01 17:58:29'
updated: '2017-06-01 17:58:29'
tags: [web, html, 前端, node]
permalink: /articles/2017/06/01/1496311109531.html
---
<table class="standard-table" border="1">
<thead>
<tr><th scope="col">Constant</th><th scope="col">Value</th><th scope="col">Description</th></tr>
</thead>
<tbody>
<tr>
<td><strong><span style="color: #ff0000;"><code>Node.ELEMENT_NODE</code></span></strong></td>
<td><code>1</code></td>
<td>An&nbsp;<code>Element</code>&nbsp;node such as&nbsp;<code>&lt;p&gt;</code>&nbsp;or&nbsp;<code>&lt;div&gt;</code><code>.</code></td>
</tr>
<tr>
<td><code>Node.TEXT_NODE</code></td>
<td><code>3</code></td>
<td>The actual&nbsp;<code>Text</code>&nbsp;of&nbsp;<code>Element</code>&nbsp;or&nbsp;<code>Attr</code>.</td>
</tr>
<tr>
<td><code>Node.PROCESSING_INSTRUCTION_NODE</code></td>
<td><code>7</code></td>
<td>A&nbsp;<code>ProcessingInstruction</code>&nbsp;of an XML document such as&nbsp;<code>&lt;?xml-stylesheet ... ?&gt;</code>&nbsp;declaration.</td>
</tr>
<tr>
<td><span style="color: #ff0000;"><strong><code>Node.COMMENT_NODE</code></strong></span></td>
<td><code>8</code></td>
<td>A&nbsp;<code>Comment</code>&nbsp;node.</td>
</tr>
<tr>
<td><code>Node.DOCUMENT_NODE</code></td>
<td><code>9</code></td>
<td>A&nbsp;<code>Document</code>&nbsp;node.</td>
</tr>
<tr>
<td><code>Node.DOCUMENT_TYPE_NODE</code></td>
<td><code>10</code></td>
<td>A&nbsp;<code>DocumentType</code>&nbsp;node e.g.&nbsp;<code>&lt;!DOCTYPE html&gt;</code>&nbsp;for HTML5 documents.</td>
</tr>
<tr>
<td><code>Node.DOCUMENT_FRAGMENT_NODE</code></td>
<td><code>11</code></td>
<td>A&nbsp;<code>DocumentFragment</code>&nbsp;node.</td>
</tr>
</tbody>
</table>