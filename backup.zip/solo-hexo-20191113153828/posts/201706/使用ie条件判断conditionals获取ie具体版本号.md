title: 使用ie条件判断conditionals获取ie具体版本号
date: '2017-06-01 15:59:35'
updated: '2017-06-01 16:30:44'
tags: [ie, js, version, web, 前端]
permalink: /articles/2017/06/01/1496303975257.html
---
<h2>1、获取方法</h2>
<pre class="brush: js">var ieVersion = document &amp;&amp; (function() {
    var version = 3, div = document.createElement('div'), iElems = div.getElementsByTagName('i');

    // Keep constructing conditional HTML blocks until we hit one that resolves to an empty fragment
while (
        div.innerHTML = '&lt;!--[if gt IE ' + (++version) + ']&gt;&lt;i&gt;&lt;/i&gt;&lt;![endif]--&gt;',
        iElems[0]
    ) {}
    return version &gt; 4 ? version : undefined;
}());</pre>
<pre></pre>
<h2>2、注意点</h2>
<p>ie10以上不支持 conditional comments</p>