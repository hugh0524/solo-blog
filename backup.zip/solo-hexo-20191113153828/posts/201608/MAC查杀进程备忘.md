title: MAC查杀进程备忘
date: '2016-08-13 23:19:09'
updated: '2016-08-13 23:19:09'
tags: [lsof, kill, mac]
permalink: /articles/2016/08/13/1471101490245.html
---
<p>1、查找进程</p>
<p>lsof -i:9000</p>
<p>java &nbsp; &nbsp;1045 xxxx &nbsp; 56u &nbsp;IPv6 0xf44afb803d6579e7 &nbsp; &nbsp; &nbsp;0t0 &nbsp;TCP *:8009 (LISTEN)</p>
<p>&nbsp;</p>
<p>2、kill</p>
<p>kill PID</p>
<p>eg：kill 1045</p>
<p>&nbsp;</p>
<p>&nbsp;</p>