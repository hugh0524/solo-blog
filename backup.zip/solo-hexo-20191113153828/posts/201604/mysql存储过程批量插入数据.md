title: mysql存储过程批量插入数据
date: '2016-04-28 19:56:25'
updated: '2016-04-28 22:41:23'
tags: [DB, mysql, 存储过程]
permalink: /articles/2016/04/28/1461844573817.html
---
<pre class="brush: sql">DELIMITER $$ //定义分界符 $$
DROP PROCEDURE IF EXISTS `test`$$
CREATE PROCEDURE `test`()
 BEGIN
    DECLARE i INT DEFAULT 100000;
    DECLARE j INT DEFAULT 200;
    WHILE (i &lt;= 150000) DO
        INSERT INTO `t1` (`name`, `age`, `sex`) VALUES (i, 20, '1');
        SET i = i + 1;
        SET j = j + 1;         
        IF MOD(i,1000)=0 THEN COMMIT;
        END IF;    
    END WHILE;
 END$$
DELIMITER ;
CALL test(); </pre>
<p>&nbsp;</p>