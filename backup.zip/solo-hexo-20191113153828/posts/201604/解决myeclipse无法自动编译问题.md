title: 解决myeclipse无法自动编译问题
date: '2016-04-04 22:30:22'
updated: '2016-04-04 22:30:22'
tags: [编译, eclipse, java]
permalink: /articles/2016/04/04/1459780222048.html
---
<p>1、场景： 自动编译已勾选、clean操作多遍，依然无法自动编译</p>
<p>&nbsp; 情况：这时一般项目上会有红色感叹号，提示问题，可以先使用properties查看项目属性，</p>
<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 看看那个包丢失或出错，排查即可</p>
<p>&nbsp;</p>