title: contenteditable属性将普通元素变为编辑框
date: '2016-04-12 22:27:02'
updated: '2017-06-06 19:18:21'
tags: [placeholder, contenteditable, 编辑框, web, html5, html]
permalink: /articles/2016/04/12/1460471105220.html
---
<h1>属性：contenteditable</h1>
<p>作用：将普通元素变为编辑框</p>
<p>范例：&lt;div class="chatinput" contenteditable &gt;&lt;/div&gt;</p>
<p>属性值：</p>
<table class="dataintable" border="1">
<tbody>
<tr><th>值</th><th>描述</th></tr>
<tr>
<td>true</td>
<td>规定可以编辑元素内容。</td>
</tr>
<tr>
<td>false</td>
<td>规定无法编辑元素内容。</td>
</tr>
<tr>
<td><em>classname</em></td>
<td>继承父元素的 contenteditable 属性。</td>
</tr>
</tbody>
</table>
<p>浏览器支持性：</p>
<dl><dd></dd></dl>
<table class="main" width="1128" border="1">
<thead>
<tr><th class="first">&nbsp;</th><th class="ie">IE</th><th class="firefox">Firefox</th><th class="chrome">Chrome</th><th class="safari">Safari</th><th class="opera">Opera</th><th class="ios_saf">iOS Safari</th><th class="op_mini">Opera Mini</th><th class="op_mob">Opera Mobile</th><th class="android" colspan="2">Android Browser</th></tr>
</thead>
<tbody>
<tr><th>14 versions back</th>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td class="y" title="Supported">4.0<span class="res">: Supported</span></td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown" colspan="2">&nbsp;</td>
</tr>
<tr><th>13 versions back</th>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td class="y" title="Supported">5.0<span class="res">: Supported</span></td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown" colspan="2">&nbsp;</td>
</tr>
<tr><th>12 versions back</th>
<td title="Unknown">&nbsp;</td>
<td class="n" title="Not supported">2.0<span class="res">: Not supported</span></td>
<td class="y" title="Supported">6.0<span class="res">: Supported</span></td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown" colspan="2">&nbsp;</td>
</tr>
<tr><th>11 versions back</th>
<td title="Unknown">&nbsp;</td>
<td class="a" title="Partial support">3.0<span class="res">: Partial support</span></td>
<td class="y" title="Supported">7.0<span class="res">: Supported</span></td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown" colspan="2">&nbsp;</td>
</tr>
<tr><th>10 versions back</th>
<td title="Unknown">&nbsp;</td>
<td class="y" title="Supported">3.5<span class="res">: Supported</span></td>
<td class="y" title="Supported">8.0<span class="res">: Supported</span></td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown" colspan="2">&nbsp;</td>
</tr>
<tr><th>9 versions back</th>
<td title="Unknown">&nbsp;</td>
<td class="y" title="Supported">3.6<span class="res">: Supported</span></td>
<td class="y" title="Supported">9.0<span class="res">: Supported</span></td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown" colspan="2">&nbsp;</td>
</tr>
<tr><th>8 versions back</th>
<td title="Unknown">&nbsp;</td>
<td class="y" title="Supported">4.0<span class="res">: Supported</span></td>
<td class="y" title="Supported">10.0<span class="res">: Supported</span></td>
<td title="Unknown">&nbsp;</td>
<td class="y" title="Supported">9.0<span class="res">: Supported</span></td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown" colspan="2">&nbsp;</td>
</tr>
<tr><th>7 versions back</th>
<td title="Unknown">&nbsp;</td>
<td class="y" title="Supported">5.0<span class="res">: Supported</span></td>
<td class="y" title="Supported">11.0<span class="res">: Supported</span></td>
<td title="Unknown">&nbsp;</td>
<td class="y" title="Supported">9.5-9.6<span class="res">: Supported</span></td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown" colspan="2">&nbsp;</td>
</tr>
<tr><th>6 versions back</th>
<td title="Unknown">&nbsp;</td>
<td class="y" title="Supported">6.0<span class="res">: Supported</span></td>
<td class="y" title="Supported">12.0<span class="res">: Supported</span></td>
<td title="Unknown">&nbsp;</td>
<td class="y" title="Supported">10.0-10.1<span class="res">: Supported</span></td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown" colspan="2">&nbsp;</td>
</tr>
<tr><th>5 versions back</th>
<td title="Unknown">&nbsp;</td>
<td class="y" title="Supported">7.0<span class="res">: Supported</span></td>
<td class="y" title="Supported">13.0<span class="res">: Supported</span></td>
<td title="Unknown">&nbsp;</td>
<td class="y" title="Supported">10.5<span class="res">: Supported</span></td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown" colspan="2">&nbsp;</td>
</tr>
<tr><th>4 versions back</th>
<td class="y" title="Supported">5.5<span class="res">: Supported</span></td>
<td class="y" title="Supported">8.0<span class="res">: Supported</span></td>
<td class="y" title="Supported">14.0<span class="res">: Supported</span></td>
<td class="y" title="Supported">3.1<span class="res">: Supported</span></td>
<td class="y" title="Supported">10.6<span class="res">: Supported</span></td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td class="n" title="Not supported">10.0<span class="res">: Not supported</span></td>
<td title="Unknown" colspan="2">&nbsp;</td>
</tr>
<tr><th>3 versions back</th>
<td class="y" title="Supported">6.0<span class="res">: Supported</span></td>
<td class="y" title="Supported">9.0<span class="res">: Supported</span></td>
<td class="y" title="Supported">15.0<span class="res">: Supported</span></td>
<td class="y" title="Supported">3.2<span class="res">: Supported</span></td>
<td class="y" title="Supported">11.0<span class="res">: Supported</span></td>
<td class="n" title="Not supported">3.2<span class="res">: Not supported</span></td>
<td title="Unknown">&nbsp;</td>
<td class="n" title="Not supported">11.0<span class="res">: Not supported</span></td>
<td class="n" title="Not supported" colspan="2">2.1<span class="res">: Not supported</span></td>
</tr>
<tr><th>2 versions back</th>
<td class="y" title="Supported">7.0<span class="res">: Supported</span></td>
<td class="y" title="Supported">10.0<span class="res">: Supported</span></td>
<td class="y" title="Supported">16.0<span class="res">: Supported</span></td>
<td class="y" title="Supported">4.0<span class="res">: Supported</span></td>
<td class="y" title="Supported">11.1<span class="res">: Supported</span></td>
<td class="n" title="Not supported">4.0-4.1<span class="res">: Not supported</span></td>
<td title="Unknown">&nbsp;</td>
<td class="n" title="Not supported">11.1<span class="res">: Not supported</span></td>
<td class="n" title="Not supported" colspan="2">2.2<span class="res">: Not supported</span></td>
</tr>
<tr><th>Previous version</th>
<td class="y" title="Supported">8.0<span class="res">: Supported</span></td>
<td class="y" title="Supported">11.0<span class="res">: Supported</span></td>
<td class="y" title="Supported">17.0<span class="res">: Supported</span></td>
<td class="y" title="Supported">5.0<span class="res">: Supported</span></td>
<td class="y" title="Supported">11.5<span class="res">: Supported</span></td>
<td class="n" title="Not supported">4.2-4.3<span class="res">: Not supported</span></td>
<td title="Unknown">&nbsp;</td>
<td class="n" title="Not supported">11.5<span class="res">: Not supported</span></td>
<td class="n" title="Not supported">2.3<span class="res">: Not supported</span></td>
<td class="y" title="Supported">3.0<span class="res">: Supported</span></td>
</tr>
<tr class="now"><th>Current</th>
<td class="y" title="Supported">9.0<span class="res">: Supported</span></td>
<td class="y" title="Supported">12.0<span class="res">: Supported</span></td>
<td class="y" title="Supported">18.0<span class="res">: Supported</span></td>
<td class="y" title="Supported">5.1<span class="res">: Supported</span></td>
<td class="y" title="Supported">11.6<span class="res">: Supported</span></td>
<td class="y" title="Supported">5.0<span class="res">: Supported</span></td>
<td class="n" title="Not supported">5.0-6.0<span class="res">: Not supported</span></td>
<td class="n" title="Not supported">12.0<span class="res">: Not supported</span></td>
<td class="y" title="Supported" colspan="2">4.0<span class="res">: Supported</span></td>
</tr>
<tr><th>Near future</th>
<td class="y" title="Supported">10.0<span class="res">: Supported</span></td>
<td class="y" title="Supported">13.0<span class="res">: Supported</span></td>
<td class="y" title="Supported">19.0<span class="res">: Supported</span></td>
<td class="y" title="Supported">5.2<span class="res">: Supported</span></td>
<td class="y" title="Supported">12.0<span class="res">: Supported</span></td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown" colspan="2">&nbsp;</td>
</tr>
<tr><th>Farther future</th>
<td title="Unknown">&nbsp;</td>
<td class="y" title="Supported">14.0<span class="res">: Supported</span></td>
<td class="y" title="Supported">20.0<span class="res">: Supported</span></td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown">&nbsp;</td>
<td title="Unknown" colspan="2">&nbsp;</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
<p>如何使contenteditable元素 支持placeholder,使用css</p>
<pre class="brush: css"> [contenteditable=true]:empty:before{
        content: attr(placeholder);
        display: block; /* For Firefox */
      }</pre>
<p>&nbsp;</p>
<p>&nbsp;</p>