title: java发送UDP请求
date: '2016-04-29 10:30:22'
updated: '2016-04-29 10:30:22'
tags: [线程池, thread, 多线程, java, udp, socket, 数据包]
permalink: /articles/2016/04/29/1461896357315.html
---
<h2>1、发送数据报</h2>
<p>(1)创建DatagramSocket并连接</p>
<pre class="brush: java">DatagramSocket client = new DatagramSocket();
InetAddress addr = InetAddress.getByName(reqHost);
int port = Integer.valueOf(reqPort);
client.connect(addr, port);</pre>
<p>(2)构造数据报</p>
<p>(3)发送数据</p>
<pre class="brush: java">client.send(sendPacket);</pre>
<p>(4)关闭连接</p>
<h2>2、接受数据</h2>
<p>(1)创建指定监听端口的socket服务</p>
<pre class="brush: java">DatagramSocket server = new DatagramSocket(10001);</pre>
<p>(2)构建接受数据报容器</p>
<pre class="brush: java"> byte[] buf = new byte[1024];//接受内容的大小，注意不要溢出  
          
        DatagramPacket dp = new DatagramPacket(buf,0,buf.length);//定义一个接收的包  </pre>
<p>(3)接受</p>
<pre class="brush: java">server.receive(recvPacket);<br /><br /></pre>
<p>(4)关闭资源</p>
<h2>3、示例代码</h2>
<pre class="brush: java">public class UdpSentUtil {
	private static DatagramSocket client;
	private static String reqHost = DOGlobals.getValue("cws.host");
	private static String reqPort = DOGlobals.getValue("cws.port");
	private static RecMsg recThead;
	private static UdpSentUtil self = new UdpSentUtil();
	public static ExecutorService fixedThreadPool = Executors.newFixedThreadPool(10); 
private UdpSentUtil(){
		try {
			client = new DatagramSocket();
			InetAddress addr = InetAddress.getByName(reqHost);
			int port = Integer.valueOf(reqPort);
			client.connect(addr, port);
			
			recThead = new RecMsg(client);
			recThead.start();
			System.out.println("=========="+recThead.getName());
			//reciveMsg();
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			client = null;
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			client = null;
		}
	}
public static UdpSentUtil getInstance(){
		if(self != null &amp;&amp; client != null &amp;&amp; client.isConnected()){
			return self;
		}else{
			self = new UdpSentUtil();
			return self;
		}
	}
public void sendNoRecive(byte[] sendBuf){
		DatagramPacket sendPacket = new DatagramPacket(sendBuf ,sendBuf.length);
		if(client != null){
			try {
				if(!client.isConnected()){
					InetAddress addr = InetAddress.getByName(reqHost);
					int port = Integer.valueOf(reqPort);
					client.connect(addr, port);
				}
				client.send(sendPacket);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
class RecMsg extends Thread{
		private DatagramSocket client;
		private String sign;
		
		public RecMsg(DatagramSocket client){
			this.client = client;
			this.sign = "";
		}
		public RecMsg(DatagramSocket client,String sign){
			this.client = client;
			this.sign = sign;
		}
		
		public void run() {
			// TODO Auto-generated method stub
			byte[] recvBuf = new byte[1024*4];
	        DatagramPacket recvPacket
	            = new DatagramPacket(recvBuf , recvBuf.length);
	        String recvStr = "";
			try {
	        	while(client != null){
	        		System.out.println(this.sign+"等待接受。。。。。。");
	        		client.receive(recvPacket);
	        		recvStr = new String(recvPacket.getData() , 0 ,recvPacket.getLength(),"UTF-8");
	        		System.out.println(this.sign+"收到信息："+recvStr);
	        		fixedThreadPool.execute(new ParseMsg(recvStr));
	        	}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	/**
	 * 解析信息
	 * @author user
	 *
	 */
	class ParseMsg extends Thread{
		private String msg;
		public ParseMsg(String msg){
			this.msg = msg;
		}
		
		public void run() {
			//解析xml数据
		}
		
		private void dealMsg(Document doc,String cid){
			//处理相应数据
		}
		
		private Map respToMap(List&lt;Element&gt; lrs){
			Map&lt;String,String&gt; m = new HashMap&lt;String, String&gt;();
			if(lrs != null){
				for (int i = 0; i &lt; lrs.size(); i++) {
					m.put(lrs.get(i).getName(), lrs.get(i).getText());
				}
			}
			return m;
		}
		
		public List respToList(List&lt;Element&gt; lrs){
			List&lt;Map&gt; lms = new ArrayList&lt;Map&gt;();
			if(lrs != null){
				for (int i = 0; i &lt; lrs.size(); i++) {
					lms.add(respToMap((List&lt;Element&gt;) lrs.get(i).selectNodes("./*")));
				}
			}
			return lms;
		}
	}
}</pre>
<p>&nbsp;</p>