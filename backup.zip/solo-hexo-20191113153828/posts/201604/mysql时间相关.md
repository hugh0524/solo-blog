title: mysql时间相关
date: '2016-04-06 18:25:14'
updated: '2016-04-06 18:25:49'
tags: [DB, mysql, date, 日期处理, DATE_FORMAT, UNIX_TIMESTAMP]
permalink: /articles/2016/04/06/1459938312896.html
---
<h2>1、获取系统时间</h2>
<p>&nbsp;&nbsp;&nbsp; <span style="color: #ff0000;">NOW()</span></p>
<h2>2、日期格式化</h2>
<p><span style="color: #ff0000;">&nbsp;&nbsp;&nbsp; DATE_FORMAT(date, format)</span></p>
<p><span style="color: #ff0000;"><span style="color: #00ff00;">eg:&nbsp;&nbsp;&nbsp; select date_format(now(),'%y-%m-%d');</span></span></p>
<p><span style="color: #ff0000;"><span style="color: #00ff00;"><span style="color: #000000;">查询出指定日期内 按小时分组得到的记录数</span><br /></span></span></p>
<p><span style="color: #ff0000;"><span style="color: #00ff00;">eg2： SELECT DATE_FORMAT(dtime1,'%y-%m-%d %H') timeval,COUNT(clogonip1) COT FROM tbuserlog WHERE dtime1&gt;"2016-4-1" AND dtime2&lt;"2016-4-6" GROUP BY (DATE_FORMAT(dtime1,'%y-%m-%d %H')) <br /></span></span></p>
<p><span style="color: #ff0000;"><span style="color: #00ff00;">&nbsp;</span></span></p>
<p>根据format字符串格式化date值:</p>
<p>&nbsp;</p>
<p>%S, %s 两位数字形式的秒（ 00,01, ..., 59）<br /> %I, %i 两位数字形式的分（ 00,01, ..., 59）<br /> %H 两位数字形式的小时，24 小时（00,01, ..., 23）<br /> %h 两位数字形式的小时，12 小时（01,02, ..., 12）<br /> %k 数字形式的小时，24 小时（0,1, ..., 23）<br /> %l 数字形式的小时，12 小时（1, 2, ..., 12）<br /> %T 24 小时的时间形式（hh:mm:ss）<br /> %r 12 小时的时间形式（hh:mm:ss AM 或hh:mm:ss PM）<br /> %p AM或PM<br /> %W 一周中每一天的名称（Sunday, Monday, ..., Saturday）<br /> %a 一周中每一天名称的缩写（Sun, Mon, ..., Sat）<br /> %d 两位数字表示月中的天数（00, 01,..., 31）<br /> %e 数字形式表示月中的天数（1, 2， ..., 31）<br /> %D 英文后缀表示月中的天数（1st, 2nd, 3rd,...）<br /> %w 以数字形式表示周中的天数（ 0 = Sunday, 1=Monday, ..., 6=Saturday）<br /> %j 以三位数字表示年中的天数（ 001, 002, ..., 366）<br /> %U 周（0, 1, 52），其中Sunday 为周中的第一天<br /> %u 周（0, 1, 52），其中Monday 为周中的第一天<br /> %M 月名（January, February, ..., December）<br /> %b 缩写的月名（ January, February,...., December）<br /> %m 两位数字表示的月份（01, 02, ..., 12）<br /> %c 数字表示的月份（1, 2, ...., 12）<br /> %Y 四位数字表示的年份<br /> %y 两位数字表示的年份<br /> %% 直接值&ldquo;%&rdquo;</p>
<h2>3、UNIX_TIMESTAMP</h2>
<p>未完待续。。。</p>
<p>&nbsp;</p>
<p><span style="color: #ff0000;">&nbsp;</span></p>