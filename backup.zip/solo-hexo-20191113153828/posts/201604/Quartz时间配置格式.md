title: Quartz时间配置格式
date: '2016-04-05 13:48:18'
updated: '2016-04-05 13:48:18'
tags: [定时任务, 时间配置, quartz, java]
permalink: /articles/2016/04/05/1459835298050.html
---
<p><strong>CronTrigger</strong><strong>配置格式</strong>:</p>
<p>格式: [秒] [分] [小时] [日] [月] [周] [年]</p>
<p>&nbsp;</p>
<table border="0" cellpadding="0">
<tbody>
<tr>
<td width="47">
<p align="left">序号</p>
</td>
<td width="58">
<p align="left">说明</p>
</td>
<td width="94">
<p align="left">是否必填</p>
</td>
<td width="166">
<p align="left">允许填写的值</p>
</td>
<td width="129">
<p align="left">允许的通配符</p>
</td>
</tr>
<tr>
<td width="47">
<p align="left">1</p>
</td>
<td width="58">
<p align="left">秒</p>
</td>
<td width="94">
<p align="left">是</p>
</td>
<td width="166">
<p align="left">0-59&nbsp;</p>
</td>
<td width="129">
<p align="left">, - * /</p>
</td>
</tr>
<tr>
<td width="47">
<p align="left">2</p>
</td>
<td width="58">
<p align="left">分</p>
</td>
<td width="94">
<p align="left">是</p>
</td>
<td width="166">
<p align="left">0-59</p>
</td>
<td width="129">
<p align="left">, - * /</p>
</td>
</tr>
<tr>
<td width="47">
<p align="left">3</p>
</td>
<td width="58">
<p align="left">小时</p>
</td>
<td width="94">
<p align="left">是</p>
</td>
<td width="166">
<p align="left">0-23</p>
</td>
<td width="129">
<p align="left">, - * /</p>
</td>
</tr>
<tr>
<td width="47">
<p align="left">4</p>
</td>
<td width="58">
<p align="left">日</p>
</td>
<td width="94">
<p align="left">是</p>
</td>
<td width="166">
<p align="left">1-31</p>
</td>
<td width="129">
<p align="left">, - * ? / L W</p>
</td>
</tr>
<tr>
<td width="47">
<p align="left">5</p>
</td>
<td width="58">
<p align="left">月</p>
</td>
<td width="94">
<p align="left">是</p>
</td>
<td width="166">
<p align="left">1-12 or JAN-DEC</p>
</td>
<td width="129">
<p align="left">, - * /</p>
</td>
</tr>
<tr>
<td width="47">
<p align="left">6</p>
</td>
<td width="58">
<p align="left">周</p>
</td>
<td width="94">
<p align="left">是</p>
</td>
<td width="166">
<p align="left">1-7 or SUN-SAT</p>
</td>
<td width="129">
<p align="left">, - * ? / L #</p>
</td>
</tr>
<tr>
<td width="47">
<p align="left">7</p>
</td>
<td width="58">
<p align="left">年</p>
</td>
<td width="94">
<p align="left">否</p>
</td>
<td width="166">
<p align="left">empty 或 1970-2099</p>
</td>
<td width="129">
<p align="left">, - * /</p>
</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
<p align="left"><strong>通配符说明</strong>:</p>
<p align="left"><strong>* </strong>：表示所有值. 例如:在分的字段上设置 "*",表示每一分钟都会触发。<br /><strong>?</strong> ：表示不指定值。使用的场景为不需要关心当前设置这个字段的值。例如:要在每月的10号触发一个操作，但不关心是周几，所以需要周位置的那个字段设置为"?" 具体设置为 0 0 0 10 * ?<br /><strong>-</strong> ：表示区间。例如 在小时上设置 "10-12",表示 10,11,12点都会触发。<br /><strong>,</strong> ：表示指定多个值，例如在周字段上设置 "MON,WED,FRI" 表示周一，周三和周五触发<br /><strong>/ </strong>：用于递增触发。如在秒上面设置"5/15" 表示从5秒开始，每增15秒触发(5,20,35,50)。 在月字段上设置'1/3'所示每月1号开始，每隔三天触发一次。<br /><strong>L</strong> ：表示最后的意思。在日字段设置上，表示当月的最后一天(依据当前月份，如果是二月还会依据是否是润年[leap]), 在周字段上表示星期六，相当于"7"或"SAT"。如果在"L"前加上数字，则表示该数据的最后一个。</p>
<p align="left">例如在周字段上设置"6L"这样的格式,则表示&ldquo;本月最后一个星期五"</p>
<p align="left"><strong>W</strong> ：表示离指定日期的最近那个工作日(周一至周五). 例如在日字段上设置"15W"，表示离每月15号最近的那个工作日触发。如果15号正好是周六，则找最近的周五(14号)触发, 如果15号是周未，则找最近的下周一(16号)触发.如果15号正好在工作日(周一至周五)，则就在该天触发。如果指定格式为 "1W",它则表示每月1号往后最近的工作日触发。如果1号正是周六，则将在3号下周一触发。(注，"W"前只能设置具体的数字,不允许区间"-").</p>
<p align="left">'L'和 'W'可以一组合使用。如果在日字段上设置"LW",则表示在本月的最后一个工作日触发</p>
<p align="left">&nbsp;</p>
<p align="left"><strong>#</strong> ：序号(表示每月的第几周星期几)，例如在周字段上设置"6#3"表示在每月的第三个周星期六.注意如果指定"6#5",正好第五周没有星期六，则不会触发该配置(用在母亲节和父亲节再合适不过了)</p>
<p align="left">周字段的设置，若使用英文字母是不区分大小写的 MON 与mon相同.</p>
<p><strong>常用示例: </strong></p>
<p>格式: [秒] [分] [小时] [日] [月] [周] [年]</p>
<p>0 0 12 * * ?&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;每天12点触发 <br />0 15 10 ? * *&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;每天10点15分触发 <br />0 15 10 * * ?&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;每天10点15分触发&nbsp; <br />0 15 10 * * ? *&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 每天10点15分触发&nbsp; <br />0 15 10 * * ? 2005&nbsp; &nbsp;&nbsp;&nbsp;2005年每天10点15分触发 <br />0 * 14 * * ?&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;每天下午的 2点到2点59分每分触发 <br />0 0/5 14 * * ?&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;每天下午的 2点到2点59分(整点开始，每隔5分触发)&nbsp; <br />0 0/5 14,18 * * ?&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 每天下午的 18点到18点59分(整点开始，每隔5分触发)</p>
<p>0 0-5 14 * * ?&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;每天下午的 2点到2点05分每分触发 <br />0 10,44 14 ? 3 WED&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;3月分每周三下午的 2点10分和2点44分触发 <br />0 15 10 ? * MON-FRI&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;从周一到周五每天上午的10点15分触发 <br />0 15 10 15 * ?&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;每月15号上午10点15分触发 <br />0 15 10 L * ?&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;每月最后一天的10点15分触发 <br />0 15 10 ? * 6L&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;每月最后一周的星期五的10点15分触发 <br />0 15 10 ? * 6L 2002-2005&nbsp; 从2002年到2005年每月最后一周的星期五的10点15分触发</p>
<p>0 15 10 ? * 6#3&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;每月的第三周的星期五开始触发 <br />0 0 12 1/5 * ?&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;每月的第一个中午开始每隔5天触发一次 <br />0 11 11 11 11 ?&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;每年的11月11号 11点11分触发</p>