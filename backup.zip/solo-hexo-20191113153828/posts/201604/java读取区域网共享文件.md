title: java读取区域网共享文件
date: '2016-04-28 22:22:33'
updated: '2016-04-28 22:22:33'
tags: [文件共享, bat, file, java]
permalink: /articles/2016/04/28/1461853339316.html
---
<p>1、使用开源jcifs</p>
<p>2、使用系统方法</p>
<p>（1）创建一个bat文件，供java程序调用</p>
<pre class="brush: vb">@echo off 
net use %1 /user:%2 %3
echo success
</pre>
<p>（2）java程序调用</p>
<pre class="brush: java">public static void runExe(String exe,String[] params,StringBuffer sbout) throws IOException{
		String cmd = exe;
		for (String param : params) {
			cmd+=" "+param;
		}
//		System.out.println(cmd);
		Process proc = Runtime.getRuntime().exec(cmd);
		
		BufferedReader stdout = new BufferedReader(new InputStreamReader(proc.getInputStream()));

		String line = null;
		while((line = stdout.readLine())!=null){
			sbout.append(line+"\n");
		}
	}</pre>
<pre class="brush: java">/**
	 * 
	 * @param host 需要访问的机器   192.168.152.169
	 * @param user 用户名
	 * @param pw   机器密码
	 * @param testDir 测试目录名	
	 * @return
	 * @throws IOException
	 * @throws URISyntaxException
	 */
	public static boolean netConn(String host,String user,String pw,String testDir) throws IOException, URISyntaxException{
		StringBuffer sb = new StringBuffer();
		runExe(RunExe.class.getResource("").toURI().getPath()+"res\\initConn.bat", new String[]{"\\\\"+host,user,pw}, sb);
//		System.out.println(sb.toString());
		if(sb.toString().contains("success")){
			Path p = Paths.get("\\\\"+host+"\\"+testDir);
			return p.toFile().exists();
		}
		return false;
	}</pre>
<pre class="brush: java">public static void main(String[] args) {
		try {
System.out.println(netConn("10.156.11.86","Administrator","123456", "Users"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			System.out.println("--------");
		}
		
	}</pre>
<p><span style="color: #ff0000;">注释：利用系统会记录登录状态的特性，使用bat连接到共享的机器，之后的访问就可以使用访问本地文件的方式进行操作</span></p>