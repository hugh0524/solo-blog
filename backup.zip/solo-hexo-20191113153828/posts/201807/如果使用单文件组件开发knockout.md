title: 如果使用‘单文件组件’开发knockout
date: '2018-07-24 23:30:37'
updated: '2018-07-29 15:56:57'
tags: [前端, template, 单文件组件, vue, web, js, knockout]
permalink: /articles/2018/06/05/1528212989664.html
---
<p>1、什么是单文件组件</p>
<p>参见<a href="https://cn.vuejs.org/v2/guide/single-file-components.html" target="_blank"> vue 单文件组件</a></p>
<p>2、如何在knockout中使用&lsquo;单文件组件&rsquo;</p>
<p>a. <a href="http://knockoutjs.com/documentation/component-binding.html" target="_blank">component</a></p>
<p>b. <a href="http://knockoutjs.com/documentation/component-registration.html#a-createviewmodel-factory-function" target="_blank">createViewModal 加载器</a></p>
<p>&nbsp;</p>
<p>3、需要达成的目标</p>
<pre class="brush: js">&lt;template&gt;
 &lt;div&gt;
   &lt;nodata params='title:"Hi，真不巧，网页走丢了&hellip;", desc:"不如返回首页，或者刷新网页试试吧。", btnHref:"/", btnText: "返回首页", img: noDataImg'&gt;&lt;/nodata&gt;
 &lt;/div&gt;
&lt;/template&gt;
&lt;script&gt;
 define(["components/share/views/noData"],function (nodata) {
   return {
     viewModel: function () {
       this.noDataImg = require ('../assets/images/share/404.png')
     },
     components: {nodata}
   }
 })
&lt;/script&gt;
&lt;style lang="less" scoped rel="stylesheet/less" type="text/less"&gt;
  
&lt;/style&gt;
</pre>
<p>4、如何修改</p>
<p>a. 基于vue-loader做修改，<a href="https://www.npmjs.com/package/kov-loader" target="_blank">kov-loader</a></p>
<p>b. 提供一个具备解析功能的入口文件</p>
<pre class="brush: js"> var Page = function (componentName, title, keywords, dataModel) {
        this.dataModel = ko.observable(dataModel || {});
        this.componentName = ko.observable(componentName || "blank");
        this.params = ko.observable({});

    }
    var page = new Page();

    var update = function (componentName, data, title, keywords, dataModel, template, params, restParams) {
        if (dataModel &amp;&amp; (data.template || data.render)) {
            if (!ko.components.isRegistered(componentName)) {
                if (dataModel &amp;&amp; typeof dataModel === "function") {
                    dataModel.prototype.dispose = function () {
                        // 组件被移除之前, 调用distory
                        if (data.beforeDistory &amp;&amp; typeof data.beforeDistory === "function") {
                            //data.beforeDistory(this);
                            data.beforeDistory.call(this);
                        }
                    }
                    if(dataModel.prototype.afterRender &amp;&amp; !dataModel.prototype.koDescendantsComplete){
                        dataModel.prototype.koDescendantsComplete = dataModel.prototype.afterRender;
                    }
                }
                var finalTemplate = (data.template ? data.template : "" ) + (data.render ? data.render : "");   //  render 为template标签的内容, 如果template对象 和render对象都有内容 则合并,否则只取其一
                ko.components.register(componentName, {
                    //viewModel: dataModel,
                    viewModel: {
                        createViewModel: function (params, componentInfo) {
                            var viewData = new dataModel(params, componentInfo);
                            //调用 beforeCreate
                            if (data.beforeCreate &amp;&amp; typeof data.beforeCreate === "function") {
                                data.beforeCreate.call(viewData);
                            }
                            return viewData;
                        }
                    },
                    template: finalTemplate
                });
            }
        }
        page.dataModel(dataModel || {});
        page.componentName(componentName || defPage.blankComponent);
        page.params(params || {});

    }

    var pageInit = function (data, componentName, restParams) {
        // 针对 webpack1 或 2打包的结果分析data
        if (typeof data === "function") {
            data = data();
        }
        if (data["default"]) {
            data = data["default"];
        }

        update(componentName, data, data.title, data.keywords, data.viewModel, data.template, data.params, restParams);

    }</pre>
<p>&nbsp;</p>
<p>&nbsp;</p>