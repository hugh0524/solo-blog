title: 精简js模板引擎学习
date: '2016-09-27 15:02:57'
updated: '2016-09-27 15:02:57'
tags: [web, 模板引擎, tmpl, js]
permalink: /articles/2016/09/27/1474959757829.html
---
<p><strong>代码：</strong></p>
<pre class="brush: js">var TemplateEngine = function(html, options) {
    var re = /&lt;%([^%&gt;]+)?%&gt;/g, reExp = /(^( )?(if|for|else|switch|case|break|{|}))(.*)?/g, code = 'var r=[];\n', cursor = 0;
    var add = function(line, js) {
        js? (code += line.match(reExp) ? line + '\n' : 'r.push(' + line + ');\n') :
            (code += line != '' ? 'r.push("' + line.replace(/"/g, '\\"') + '");\n' : '');
        return add;
    }
    while(match = re.exec(html)) {
        add(html.slice(cursor, match.index))(match[1], true);
        cursor = match.index + match[0].length;
    }
    add(html.substr(cursor, html.length - cursor));
    code += 'return r.join("");';
    return new Function(code.replace(/[\r\t\n]/g, '')).apply(options);
}</pre>
<p><strong>测试：</strong></p>
<pre class="brush: xml">TemplateEngine("&lt;span&gt;&lt;%this.name%&gt;&lt;/span&gt;",{name:22222})<br />TemplateEngine("&lt;%if(this.age&lt;20){%&gt;&lt;span&gt;&lt;%this.name%&gt;&lt;/span&gt;&lt;%}else{%&gt;&lt;strong&gt;&lt;%this.name%&gt;&lt;strong&gt;&lt;%}%&gt;",[{name:22222,age:33},{name:123,age:12}])</pre>
<p><strong><span style="font-family: 'arial black', 'avant garde';">知识点</span>：</strong></p>
<pre class="brush: js">new Function ([arg1[, arg2[, ...argN]],] functionBody)<br /><br /></pre>
<p>通过Function构造器创建,</p>
<p>按MDN的描述，这种方式相对效率较低</p>