title: wex5外部部署，如何刷新缓存
date: '2017-07-14 15:37:23'
updated: '2017-07-14 15:37:36'
tags: [版本控制, 缓存刷新, java, wex5]
permalink: /articles/2017/07/14/1500017825727.html
---
<p>1、<a href="http://bbs.wex5.com/thread-41364-1-1.html" target="_blank">参考官网文档</a></p>
<p>2、如果第一步无法解决，</p>
<p>找到 conf/server.xml</p>
<p>修改version的属性值</p>
<p>&nbsp;</p>
<p>解决方案来源：</p>
<p>wex5 读取配置的代码</p>
<p>ServerConfig</p>
<pre class="brush: java"> String str = paramString + "/conf/server.xml";
    File localFile = new File(str);
    if ((!localFile.exists()) || (localFile.isDirectory())) {
      return;
    }
    try
    {
      SAXReader localSAXReader = new SAXReader();
      Document localDocument = localSAXReader.read(localFile);
      Element localElement1 = localDocument.getRootElement();
      Iterator localIterator = localElement1.elements().iterator();
      while (localIterator.hasNext())
      {
        Object localObject = localIterator.next();
        Element localElement2 = (Element)localObject;
        if (localElement2 != null) {
          if (localElement2.getName().equals("default-user"))
          {
            jdField_a_of_type_JavaLangString = localElement2.elementTextTrim("name");
            b = localElement2.elementTextTrim("password");
          }
          else if (localElement2.getName().equals("version"))
          {
            c = localElement2.getTextTrim();
            if (SystemUtils.isNotEmptyString(c)) {
              c = c.replaceAll("\\.", "_");
            }
          }
          else if (localElement2.getName().equals("distributed"))
          {
            jdField_a_of_type_Boolean = localElement2.getTextTrim().equalsIgnoreCase("true");
          }
          else
          {
            jdField_a_of_type_JavaUtilMap.put(localElement2.getName(), localElement2.getTextTrim());
          }
        }
      }
    }</pre>
<p>&nbsp;</p>
<p>&nbsp;</p>