title: dom解析渲染过程中触发的事件
date: '2017-07-28 15:22:42'
updated: '2017-07-28 15:22:42'
tags: [readyState, domContentloaded, load, js, 前端, web, dom]
permalink: /articles/2017/07/28/1501226562569.html
---
<p>dom加载渲染过程中触发事件</p>
<pre class="brush: js">  window.addEventListener("load", function(event) {
        console.log("window load");
    });
    document.addEventListener("DOMContentLoaded", function(event) {
        console.log("DOM fully loaded and parsed");
    });
    document.onreadystatechange = function () {
        console.log(document.readyState)

        if(document.readyState == "interactive"){
            console.log("interactive script start")
            for(var i=0; i&lt;1000000000; i++){
                // 这个同步脚本将延迟DOM的解析。
            }
            var div = document.createElement("div");
            div.innerHTML = "test insert";
            document.getElementsByTagName("body")[0].appendChild(div)
            //debugger;
            console.log("interactive script end")
        }
    }
    console.log("body script start")
   for(var i=0; i&lt;1000000000; i++){
        // 这个同步脚本将延迟DOM的解析。
    }
    console.log("body script end")</pre>
<p>依次执行结果</p>
<p>&nbsp;body script start<br />body script end<br />&nbsp;interactive<br />&nbsp;interactive script start<br />&nbsp;interactive script end<br />&nbsp;DOM fully loaded and parsed<br />&nbsp;complete<br />&nbsp;window load</p>
<p>&nbsp;</p>