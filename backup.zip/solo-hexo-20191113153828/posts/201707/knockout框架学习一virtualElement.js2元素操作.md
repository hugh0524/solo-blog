title: knockout框架学习（一）--virtualElement.js（2）元素操作
date: '2017-07-06 13:57:11'
updated: '2017-07-06 14:19:49'
tags: [前端, web, js, knockout]
permalink: /articles/2017/07/06/1499320631253.html
---
<p>1、<span style="background-color: #e4e4ff; font-family: Menlo; font-size: 9pt;">childNodes 获取子节点</span></p>
<pre class="brush: js">childNodes: function(node) {
            return isStartComment(node) ? getVirtualChildren(node) : node.childNodes;
        }</pre>
<p><span style="background-color: #e4e4ff; font-family: Menlo; font-size: 9pt;">&nbsp;</span></p>
<p>2、emptyNode 清空子节点</p>
<pre class="brush: js">emptyNode: function(node) {
            if (!isStartComment(node))// 如果非ko开始节点
                ko.utils.emptyDomNode(node);
            else {
                var virtualChildren = ko.virtualElements.childNodes(node);
                for (var i = 0, j = virtualChildren.length; i &lt; j; i++)
                    ko.removeNode(virtualChildren[i]);
            }
        }<br /><br /></pre>
<p>&nbsp;</p>