title: onInput和onpropertychange事件
date: '2017-07-17 12:35:03'
updated: '2017-07-17 12:35:03'
tags: [onpropertychange, oninput, 前端, js, web, ie]
permalink: /articles/2017/07/17/1500266102970.html
---
<p>1、onInput&nbsp;<span>　</span></p>
<p>oninput 是&nbsp;<strong>HTML5</strong>&nbsp;的标准事件，对于检测&nbsp;textarea, input:text, input:password 和 input:search 这几个元素通过用户界面发生的内容变化非常有用，在内容修改后立即被触发，不像 onchange 事件需要失去焦点才触发。</p>
<p><strong>oninput</strong>事件在主流浏览器的兼容情况如下：</p>
<p><a href="http://tools.uproject.cn/images/1500265969402.png" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/images/1500265969402.png" alt="" width="400" height="101" /></a></p>
<p>&nbsp;</p>
<p>2、onpropertychange</p>
<p>Fires when a property changes on the object.</p>
<div class="alert"><strong>Note</strong>&nbsp;&nbsp;The&nbsp;<strong>onpropertychange</strong>&nbsp;event is only supported in conjunction with the legacy&nbsp;<strong>attachEvent</strong><span style="color: #ff0000;">&nbsp;IE-only</span> event registration model, which has&nbsp;deprecated&nbsp;since Windows Internet Explorer&nbsp;9 in favor of the W3C standard "<strong>addEventListener</strong>" event model.</div>
<div class="alert">&nbsp;</div>
<div class="alert">&nbsp;</div>
<div>&nbsp;</div>