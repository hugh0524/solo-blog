title: knockout框架学习（一）--virtualElement.js（1）
date: '2017-07-05 22:52:09'
updated: '2017-07-06 12:14:54'
tags: [前端, web, knockout, virtualElement, js]
permalink: /articles/2017/07/05/1499266296691.html
---
<p>1、virtualElement.js</p>
<p>利用注释 构建虚拟元素</p>
<blockquote>
<p>》IE9无法读取nodeValue属性，但是可使用text属性读取节点内容</p>
<p>&nbsp;</p>
</blockquote>
<p>2、判断使用哪种属性读取 注释节点的内容</p>
<pre class="brush: js">var commentNodesHaveTextProperty = document &amp;&amp; document.createComment("test").text === "&lt;!--test--&gt;";</pre>
<p>3、判断 起始和关闭标签</p>
<pre class="brush: js">var startCommentRegex = commentNodesHaveTextProperty ? /^&lt;!--\s*ko(?:\s+([\s\S]+))?\s*--&gt;$/ : /^\s*ko(?:\s+([\s\S]+))?\s*$/;
    var endCommentRegex =   commentNodesHaveTextProperty ? /^&lt;!--\s*\/ko\s*--&gt;$/ : /^\s*\/ko\s*$/;

    function isStartComment(node) {
        return (node.nodeType == 8) &amp;&amp; startCommentRegex.test(commentNodesHaveTextProperty ? node.text : node.nodeValue);
    }

    function isEndComment(node) {
        return (node.nodeType == 8) &amp;&amp; endCommentRegex.test(commentNodesHaveTextProperty ? node.text : node.nodeValue);
    }<br /><br /><br /></pre>
<p>&nbsp; 使用方法 &lt;!-- ko if: test --&gt; xxxxxxxx&lt;!-- /ko --&gt;</p>
<p>4、由开始标签 查找匹配的 关闭标签</p>
<p>1)获取当前子元素</p>
<pre class="brush: js">function getVirtualChildren(startComment, allowUnbalanced) {
        var currentNode = startComment;
        var depth = 1;
        var children = [];
        while (currentNode = currentNode.nextSibling) { //依次向下查找同级元素
            if (isEndComment(currentNode)) {
                depth--;
                if (depth === 0)
                    return children;
            }

            children.push(currentNode);

            if (isStartComment(currentNode)) // 如果有 起始标签，则 对应的 depth+1, 即 需要找到depth+1个endComment
                depth++;
        }
        if (!allowUnbalanced)
            throw new Error("Cannot find closing comment tag to match: " + startComment.nodeValue);
        return null;
    }</pre>
<p>&nbsp;</p>
<p>2）获取对应的关闭标签</p>
<pre class="brush: js">    function getMatchingEndComment(startComment, allowUnbalanced) {
        var allVirtualChildren = getVirtualChildren(startComment, allowUnbalanced);
        if (allVirtualChildren) {
            if (allVirtualChildren.length &gt; 0)
                return allVirtualChildren[allVirtualChildren.length - 1].nextSibling;
            return startComment.nextSibling;
        } else
            return null; // Must have no matching end comment, and allowUnbalanced is true
    }</pre>