title: CPS报告收集 - 前端监控
date: '2019-09-11 14:47:51'
updated: '2019-09-11 15:10:26'
tags: [安全, web, 前端, security, js]
permalink: /articles/2019/09/11/1568176109810.html
---
<h2>csp</h2>
<p>全称： C<code>ontent-Security-Policy&nbsp;<span>内容安全策略</span></code></p>
<p>是一种通过给浏览器加资源白名单的方式，进行站点保护的手段</p>
<p>可以有效的预防和阻止 类似XSS、<a href="https://blog.uproject.cn/articles/2019/04/29/1556508575314.html" target="_blank">运营商劫持</a>之类的攻击</p>
<p>&nbsp;</p>
<h2>&nbsp;CSP报告</h2>
<p>如果你的站点目前还不适合强制使用CSP拦截， 那么可以开启Content-Security-Policy-Report-Only</p>
<p>开启方法如下</p>
<p>在服务端响应时，加入&nbsp;Content-Security-Policy-Report-Only的头部，</p>
<p>指定规则和<span style="color: #ff0000;">report-uri</span></p>
<p><span style="color: #ff0000;">注： Content-security-policy 规则可以直接在meta头部标签指定， 但是report-uri属性不支持在meta设置</span></p>
<p><span style="color: #000000;">report-uri将接受到一个POST请求</span></p>
<p>参数JSON包含如下属性</p>
<p><code>document-uri：</code>发生违规的文档的URI。</p>
<p><code>referrer：</code>违规发生处的文档引用（地址）。</p>
<p><code>blocked-uri：</code>被CSP阻止的资源URI。如果被阻止的URI来自不同的源而非文档URI，那么被阻止的资源URI会被删减，仅保留协议，主机和端口号。</p>
<p><code>violated-directive：&nbsp;</code>违反的策略名称。</p>
<p><code>original-policy：&nbsp;</code>在&nbsp;<code>Content-Security-Policy</code>&nbsp;HTTP 头部中指明的原始策略。</p>
<p>&nbsp;</p>
<h2>使用</h2>
<h3>1. nodejs下</h3>
<p>利用<a href="https://github.com/helmetjs/csp" target="_blank">helmet-csp</a>包</p>
<p>范例如下</p>
<pre class="brush: js">var express = require('express');
const csp = require('helmet-csp')
var app = express();


app.use(csp({
    // Specify directives as normal.
    directives: {
        defaultSrc: ["'self'", 'default.com'],
        scriptSrc: ["'self'", "'unsafe-inline'"],
        styleSrc: ['style.com'],
        fontSrc: ["'self'", 'fonts.com'],
        imgSrc: ['img.com', 'data:'],
        reportUri: 'http://localhost:9999/api/track/csp-report/group/test',
        objectSrc: ["'none'"],
    },

    // This module will detect common mistakes in your directives and throw errors
    // if it finds any. To disable this, enable "loose mode".
    loose: false,

    // Set to true if you only want browsers to report errors, not block them.
    // You may also set this to a function(req, res) in order to decide dynamically
    // whether to use reportOnly mode, e.g., to allow for a dynamic kill switch.
    reportOnly: true,

    // Set to true if you want to blindly set all headers: Content-Security-Policy,
    // X-WebKit-CSP, and X-Content-Security-Policy.
    setAllHeaders: false,

    // Set to true if you want to disable CSP on Android where it can be buggy.
    disableAndroid: false,

    // Set to false if you want to completely disable any user-agent sniffing.
    // This may make the headers less compatible but it will be much faster.
    // This defaults to `true`.
    browserSniff: true
}))

app.get('/', function (req, res) {
    res.send(`
        &lt;html&gt;
        &lt;head&gt;
             &lt;style&gt;
            body{
                color: red;
            }
            &lt;/style&gt;
        &lt;/head&gt;
        &lt;body&gt;this is a csp test&lt;/body&gt;
        &lt;/html&gt;
    `);
});

app.listen(3000, function () {
    console.log('Example app listening on port 3000!');
});</pre>
<p>访问localhost:3000，会触发css拦截报告的消息</p>
<p>[Report Only] Refused to apply inline style because it violates the following Content Security Policy directive: "style-src style.com". Either the 'unsafe-inline' keyword, a hash ('sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU='), or a nonce ('nonce-...') is required to enable inline execution.</p>
<p>同时发送一条记录到report 服务</p>
<p>服务端需要设置bodyParser.json 支持 application/csp-report格式的数据</p>
<p>&nbsp;显示结果如下， 样式并不会被影响</p>
<p><a href="http://tools.uproject.cn/upload/article/1568184704319.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/1568184704319.jpg" alt="" width="500" height="74" /></a></p>
<h3>2. pathon</h3>
<pre class="brush: py">def middleware(request, response):
    response['Content-Security-Policy-Report-Only'] = \
        "default-src 'self'; " \
        "report-uri http://locahost:9000/api/track/csp-report/group/test"
    return response</pre>
<p>&nbsp;</p>
<p>&nbsp;</p>