title: debian 安装npm报错：Unable to locate package npm.
date: '2019-09-23 17:28:33'
updated: '2019-09-23 17:28:33'
tags: [shell, npm, 前端, web]
permalink: /articles/2019/09/23/1569230913698.html
---
<p>安装：</p>
<pre>- apt-get -y update<br />- apt-get -y install nodejs<br />- apt-get -y install npm<br /><br /><br /></pre>
<p>执行报错<br />Unable to locate package npm.<br /><br />解决</p>
<pre class="brush: bash">- curl -sL https://deb.nodesource.com/setup_10.x | bash -
      - apt-get -y update
      - apt-get -y install nodejs
      - apt-get -y install npm</pre>
<p><br /><br /><br /><br /></p>