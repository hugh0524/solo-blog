title: nodeJs child_process中fork的运用
date: '2019-02-26 14:13:16'
updated: '2019-02-26 14:16:45'
tags: [前端, node, js, fork, process, queue]
permalink: /articles/2019/02/26/1551161564273.html
---
<p>在做前端监控项目时， 用户侧消息，通过kafka侧的推送接口，推送到node服务，node服务会根据配置的规则进行存储及报警</p>
<p>消息发送的频次会比较高， 同时node是单线程的， 如果进行复杂的io操作， 必然会影响上游系统</p>
<p>解决方案：</p>
<h2>1. 接口收到消息后， 放入内存处理队列。 简单实现如下</h2>
<pre class="brush: js"> this.queueMap = {}

 addToQueue: function(name, obj) {
        var queue = this.queueMap[name];
        if(queue) {
            queue.push(obj)
        }else {
            this.queueMap[name] = [obj];
        }
    }

    popFormQueue: function(name) {
        var queue = this.queueMap[name];
        if(queue) {
            return queue.shift();
        }else {
            return null;
        }
    }</pre>
<p>&nbsp;</p>
<h2>2. 编写子线程启动脚本</h2>
<pre class="brush: js">process.on('message', function(m){
    if(m) {
   
        var curItem = null;
        try{
          
            for(var i = 0; i&lt; m.data.length; i++) {
                curItem = m.data[i]
                try{
                  // 执行业务处理部分  
          ruleService.doInterceptor(curItem.item, process)
                }catch(e){
                    process.send({info: "处理异常:"+e.message, data: curItem})
                }
            }
        }catch(e) {
            process.send({info: "处理异常:"+e.message})
        }

        process.send({info: '任务处理完毕, 等待执行下一个...'});
    }

});

process.send({info: '子线程已经开启,等待处理...'});</pre>
<p>&nbsp;</p>
<blockquote>
<p><strong>event: message -&gt; 用于接受父线程发来的消息</strong></p>
<p><strong>method: send -&gt; 用于向父线程发送消息</strong></p>
</blockquote>
<h2>3. 冲父线程fork一个子线程出来</h2>
<pre class="brush: js">var child = child_process.fork(path.resolve('./childProcess.js'), [], {silent: true});

    child.on('message', function(m){
        console.log('message from child: ' + JSON.stringify(m));
        if(m &amp;&amp; m.type == "notify") {
// 当接受到子线程特定消息时，执行响应的动作
            exeNotifyWeb(m.users, m.info);
        }
    });

    child.on('error', function(err) {
        console.log(err)
    })

    child.stdout.setEncoding('utf8');
    child.stdout.on('data', function(data){
        console.log(data);
    })

    child.on('exit', function(code){
        console.log("===exit=="+code)
   // 如果子线程由于异常意外退出， 则重新启动一个
        child = child_process.fork(path.resolve('./childProcess.js'),[], {silent: true});
    })

   // 使用定时任务 从任务队列中取出任务，交由子线程执行
    schedule.scheduleJob('* * * * * *', function() {
        // console.log("======task====")
        var items = [];
        for(var i=0;i&lt;10;i++){
            let curItem = popFormQueue("track_queue")
            if(curItem) {
                items.push(curItem)
            }
        }

        if(items.length &gt; 0)
            child.send({data:items});
    })</pre>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>