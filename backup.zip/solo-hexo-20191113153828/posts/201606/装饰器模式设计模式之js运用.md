title: 装饰器模式--设计模式之js运用
date: '2016-06-01 11:39:01'
updated: '2016-06-01 11:57:59'
tags: [web, 前端, js, 设计模式, 装饰器模式]
permalink: /articles/2016/06/01/1464752089025.html
---
<h2>1、装饰器模式</h2>
<p>装饰器模式（Decorator Pattern）允许向一个现有的对象添加新的功能，同时又不改变其结构。这种类型的设计模式属于结构型模式，它是作为现有的类的一个包装。</p>
<p>&nbsp;</p>
<h2>2、js使用</h2>
<p>1）实现被装饰者</p>
<pre class="brush: js">//被装饰者 Circle  Circle.js
function Circle(){
    this.name = "Circle";
}
Circle.prototype={
    draw:function(){
        console.log("Circle==draw");
    }
}


//被装饰者 Rectangle Rectangle.js
function Rectangle(){
    this.name = "Rectangle";
}
Rectangle.prototype={
    draw:function(){
        console.log("Rectangle==draw");
    }
}</pre>
<p>2)实现装饰者</p>
<pre class="brush: js">/**
 * 装饰者  color Color.js
 * @constructor
 */
function Color(decoratored){
    this.decoratored = decoratored;
    this.extends2(decoratored);
}

Color.prototype.setColor = function(s){
    console.log("对被装饰者："+this.decoratored.name+";设置color:"+s);
}


/**
 * 装饰者  size Size.js
 * @constructor
 */
function Size(decoratored){
    this.decoratored = decoratored;
    this.extends2(decoratored);
}

Size.prototype.setSize = function(s){
    console.log("对被装饰者："+this.decoratored.name+";设置Size:"+s);
}</pre>
<p>3）test</p>
<pre class="brush: js">&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head lang="en"&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;title&gt;&lt;/title&gt;
    &lt;script src="../base.js"&gt;&lt;/script&gt;
    &lt;script src="Rectangle.js"&gt;&lt;/script&gt;&lt;script src="Circle.js"&gt;&lt;/script&gt;
    &lt;script src="Size.js"&gt;&lt;/script&gt; &lt;script src="Color.js"&gt;&lt;/script&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;script&gt;
        var rect = new Rectangle();var circle = new Circle();
        var rs = new Size(rect);
        var rc = new Color(rs);
        rc.draw();
        rc.setSize(20);
        rc.setColor("red");

        var cs = new Size(circle);
        var cc = new Color(cs);
        cc.draw();
        cc.setSize(200);
        cc.setColor("red");
    &lt;/script&gt;
&lt;/body&gt;
&lt;/html&gt;</pre>
<p>结果：</p>
<p><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQQAAAB9CAIAAADLMIrgAAAJHklEQVR4nO2dW5ajIBRFnREjYkDMhsGwVg/H/vDyuHA1SVUsJdn7ozsPI4gcLlgcWFYAWNd1XZerMwBwFxADgPBJYkghxKvzABPzfjFEvxRcSE//LDx/7EgKblmWxf9aDNG/4ywwJWdEhuilOqXgn63h0b8gnEfp3uAsMCHniCFHhlyt8if5vTTkEjnyO+MHLqTte+e9a2NNE3+KilQ1Vkk0KWyptOFrOMbHfP58oI9tNsv3W6acc68FQbgpp0WGFFyt2eVVkGq3fdBEDhVEypscL1Jw24t8qv7/Lp3mdM8OJEpoanKrukz585z75ioZrHwGJ3aTmprcNsp2R6TrUZXf5FP4rqb2sUZ9+YOBS02/FYPOZzlpFWIMzvn4u/EO3IUzxwy5gvWVqg0asXScqhhKHGj01InBHGKYkSGf8UE3qYlWRkRb1zX6pTsgBe98iMG7p0dGcGvOepqU6+wiQUK30l0bWz/qYolzbll8CNIpL6dOMUYVO8Zhhx4CPIH8YEsy7o97nHM1Ud0fhLmZ9O8Mta4ycIV3MakYAN4PYgAQEAOAgBgABMQAICz/AODfv3///hEZAATEACAgBgABMQAIiAFA+DMx6Kmr3ey2ncludW6qMUs1+jIvqU5ztVP+5PlL1UuRYkz6k9V4u4Gdz+JUMbT3oa+S+h71joCtptdPx5u3Zwwaid7HFEJs5XNjXnYKjb4RdzB9vZ+MC5UTxDCYedZ1zcawpO+aj8OtKs7QlNYYxOw5fp9CCLIIQCgv7TnXW/UI/qX7P+GyBqb776EYmq9dbV3cb8TST9gvadxdgOdEhs2zE/3gonFtqPCxtIMxhFSdPmsuP9vevJZKtylG2sW9BnXLRnVSPFm3p1nWoC3C7X1T9Xak0DhHqire41FqPYPZ9jEkdk9O6iZF70LYarv0ZIf2yocYnA/NncyHluKLoRp6RFXS+MUoRR29D72NbdUNu/e+hqASnp64hL1Qc9WyBuWkjaFPTqfi3lDpsvU8ZMtsPd0o39acpfPY51of06Sf8m30IZ2ht7M4bczQ+yiNe+y2olqW1s2mzpE616gehNQeUxzbx3yQ0RzWPBy149MsaxC9Dylp/Yc0loILYTQYNoJK6pQlD1sLZTnDj/uEOfOqeO4dGs4Sw9Zib5E6xtS59V2IwYcYfAghSE9HVQJpD52Tlr1U5jCOqffEkILT97i7eU+Mu9cZljWQ/maS0GpcluqR7nTEVEUdhx3DvRny3aXYDhi+OzKUinRQvr4J3XYrXUs0hhD7tnFruWNMhhiKDoz1kV68hhsta7CfUe8bK/hYQ/cjQ5OC7jypUJWvI/Y3dS9DOYEYowqINx9Cn/M0SbXZG6YYSgx2IaiKEf2yLGUNlu2pUldxtmW8clzJj5e60lbBQEeG6I+b21pp7rWsQV+lmkc/KTgfjSp3EBnGJLuxkjGsGZ4WqTGDEc6+92lSGQYX2hpSjgree7f1g+oaLF0PRBfi8YNHuxX9RWT4A360rMF4oV1vrFHy7rOkWxbH5TAdA0BADAACYgAQEAOAgAcaQCAyAAiIAUBADAACYgAQEAOAgAd6cvBAvw880Hfjlh7o79i1Dg+0zdd4oJ847R9N6nvktjofPNC71/ANHuink/gTV87V5h880PuXsBdqPskDPSah9n5v7lbqf9CWtNo9Xjfy1gF9SY4OiUvAA73Hd3ig+6tonVnOyIh5gF4PwMyitb38UUleAh7ogyuIqzU8XT7JAz1u/G4rwA/Fbl3PHma0G0vyM8WAB3oSD/RwFT+MDK+IwRBgV1BXgQfa5ls80ONV9GOGwZtqjRm68DaOGaxiGkrSuWufJ+GBvhA80PeC6RgAAmIAEBADgIAYAATEACCwIACAQGQAEBADgIAYAATEACAgBgABMQAINxbDd5jQ4T6c5WfoJ0a+ts/2u0zo13vMYSLO8TNUP+2Ly56o07zD9nS1eQom4gQ/g2U7bI0IzzjEh/OoA3qXQtTT9kcnTvZcx8Zp3br1xUrh/VK8pj8WMUzL+8Ww4wEc7VWt8ak4nlpDYhXDsxtxFwyPue4y9W797b2suMFg5Tv5k8iwroc2WPsX2nfbtfuPMDzmfSqGWz8G7/zotoYv4YQxQ2PCbcYMR57wagRvPKN2ZMgpPOgmGR7zfu2f/oDonQtx+/cdxQDTccrTpN6Uqz3hhkN8/wf7G3E/QHnMq1qGpbI2t35dFObqFRrgOm78dwaAvwUxAAiIAUBADAACYgAQ8EADCEQGAAExAAiIAUBADAACYgAQ2BT9XjRbX8t2QP0udcb8chxM74FN0U/mVXNEaRfMLXH6Gbv9fEb4DWyKvs+lTu6s8F7pD8TQfN1ufPULsYw7aeUJwb3dZHp3IJui73CZk7vbtFlXPVsKS3XP7pbYT2lsUi77aVVipaB2+roTwaboNn/g5FaX2n7tgxoD7XQwc/9L78rZ18euUTnYQ1Ef0ySZy2u7g73emiSnH7qwKbrNZU7uFHyIKbXdR+ejFkNbZH2pqUbDyEOM6pPn9l1vMt/t553MXXEnhU3RbS5zcucNspN0G3cfHdTIYG9zaix+YHz31L7r7VCJyPAqH7Ap+vlObpttT+Da2RvzfBAZago7W5q3ETvG9EwFrh253Kptmcufl++NDagng03Rj65DVbZTnNzDn0iaEf4WQYc/oRxFhv0dzIdt1/f3XW+bJiuc8TTpadgU/SXGcFHyrGrrGOd6pq+Ll8N0DAABMQAIiAFAQAwAAmIAEFgQAEAgMgAIiAFAQAwAAmIAEBADgMCCAPeCBQEuhAUBTuaOCwL8xsf6ybAgwD4zLgjw+LRHU3/fibYBTgELAuww5YIAzybxpsUC7pHM+2BBAJs5FwQwkmj3fq/HNL9QB1i7x6tG3jqgX1JgtAtNAgsC2Ey6IECfB/sRRG/q16+OC2Y4YFhSwCyHKWBBAJs5FwQYN343HditVXo84GHPzo52WZb1W8SwrisLAly1IMCQh59FhpfEMApQdwkmggUBjq5DVbYZFgQY8tCPGcZFxIwxQ99wDGMGfUA/RpD3dbv5WWBBgIthQYD7wHQMAAExAAiIAUBADAACHmgAgcgAICAGAAExAAiIAUBADADCf3QOhdZgD9IOAAAAAElFTkSuQmCC" alt="" /></p>