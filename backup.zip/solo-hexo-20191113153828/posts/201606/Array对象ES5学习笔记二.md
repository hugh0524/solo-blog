title: Array对象 --ES5学习笔记（二）
date: '2016-06-22 18:20:43'
updated: '2016-07-03 00:36:23'
tags: [array, js, foreach, map, ECMASCRIPT5, ES5, web, 前端]
permalink: /articles/2016/06/22/1466588778216.html
---
<h2>1、forEach方法</h2>
<h4 class="chapter"><a id="360">Array.prototype.forEach ( callbackfn [ , thisArg ] )</a></h4>
<p>1)如果提供了一个 thisArg 参数，它会被当作 this 值传给每个 callbackfn 调用。如果没提供它，用 undefined 替代。</p>
<p>2)callbackfn参数列表 value,index,array</p>
<p>value:每次遍历的当前值</p>
<p>index:数组下标</p>
<p>array：当前数组</p>
<pre class="brush: js">var data = [3,2,5,6];

data.forEach(function(value,i,c){
   data[i] = value+1;
   console.log(c)
})

console.log(data)</pre>
<p>--输出结果</p>
<div class="logRow logRow-log ">
<div class=" ">
<div class="logContent "><span class="objectBox objectBox-array "><a class="objectLink "><span class="arrayLeftBracket ">[</span></a><span class="objectBox objectBox-number ">4</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">2</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">5</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">6</span><a class="objectLink "><span class="arrayRightBracket ">]</span></a></span></div>
</div>
</div>
<div class="logRow logRow-log ">
<div class=" ">
<div class="logContent "><span class="objectBox objectBox-array "><a class="objectLink "><span class="arrayLeftBracket ">[</span></a><span class="objectBox objectBox-number ">4</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">3</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">5</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">6</span><a class="objectLink "><span class="arrayRightBracket ">]</span></a></span></div>
</div>
</div>
<div class="logRow logRow-log ">
<div class=" ">
<div class="logContent "><span class="objectBox objectBox-array "><a class="objectLink "><span class="arrayLeftBracket ">[</span></a><span class="objectBox objectBox-number ">4</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">3</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">6</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">6</span><a class="objectLink "><span class="arrayRightBracket ">]</span></a></span></div>
</div>
</div>
<div class="logRow logRow-log ">
<div class=" ">
<div class="logContent "><span class="objectBox objectBox-array "><a class="objectLink "><span class="arrayLeftBracket ">[</span></a><span class="objectBox objectBox-number ">4</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">3</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">6</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">7</span><a class="objectLink "><span class="arrayRightBracket ">]</span></a></span></div>
</div>
</div>
<p><span class="objectBox objectBox-array "><a class="objectLink "><span class="arrayLeftBracket ">[</span></a><span class="objectBox objectBox-number ">4</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">3</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">6</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">7</span><a class="objectLink "><span class="arrayRightBracket ">]</span></a></span></p>
<p><span class="objectBox objectBox-array " style="color: #ffcc00; font-size: large;"><span class="arrayRightBracket ">对 forEach 的调用不直接更改对象，但是对 callbackfn 的调用可能更改对象。</span></span></p>
<h2><span class="objectBox objectBox-array "><span class="arrayRightBracket ">2)map方法<br /></span></span></h2>
<h4 class="chapter"><a id="361">Array.prototype.map ( callbackfn [ , thisArg ] )</a></h4>
<p><span class="objectBox objectBox-array "><span class="arrayRightBracket ">将调用的数组的每个元素传个指定函数，并返回一个数组。并不会改变原有数组<br /></span></span></p>
<p><span class="objectBox objectBox-array "><span class="arrayRightBracket ">参数及调用方式同forEach<br /></span></span></p>
<h4 class="chapter"><a id="361">callbackfn应该有<span style="color: #ffcc00;">返回值</span></a></h4>
<p><span class="objectBox objectBox-array "><span class="arrayRightBracket ">&nbsp;</span></span></p>
<pre class="brush: js">var data = [4,3,5,6];

var dclone = data.map(function(value,i,c){
   return value+1;
})

console.log(dclone)
console.log(data)</pre>
<p><span class="objectBox objectBox-array "><span class="arrayRightBracket ">&nbsp;</span></span></p>
<p>结果：<span class="objectBox objectBox-array "><a class="objectLink "><span class="arrayLeftBracket ">[</span></a><span class="objectBox objectBox-number ">5</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">4</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">6</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">7</span><a class="objectLink "><span class="arrayRightBracket ">]</span></a></span></p>
<p><span class="objectBox objectBox-array "><span class="arrayRightBracket "><span class="objectBox objectBox-array "><a class="objectLink "><span class="arrayLeftBracket ">[</span></a><span class="objectBox objectBox-number ">4</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">3</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">5</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">6</span><a class="objectLink "><span class="arrayRightBracket ">]</span></a></span></span></span></p>
<h2><span class="objectBox objectBox-array "><span class="arrayRightBracket ">3、filter</span></span></h2>
<h4 class="chapter"><a id="362">Array.prototype.filter ( callbackfn [ , thisArg ] )</a></h4>
<p>filter返回指定数组的一个子集。 参数同foreach</p>
<p><a id="362">callbackfn需返回一个布尔类型的值</a></p>
<pre class="brush: js">var data = [4,3,5,6];

var dfilter = data.filter(function(value,i,c){
   return value&gt;4;
})

console.log(dfilter)
console.log(data)</pre>
<p><span class="objectBox objectBox-array "><span class="arrayRightBracket ">&nbsp;</span></span></p>
<p>结果：</p>
<div class="logRow logRow-log ">
<div class=" ">
<div class="logContent "><span class="objectBox objectBox-array "><a class="objectLink "><span class="arrayLeftBracket ">[</span></a><span class="objectBox objectBox-number ">5</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">6</span><a class="objectLink "><span class="arrayRightBracket ">]</span></a></span></div>
</div>
</div>
<p><span class="objectBox objectBox-array "><a class="objectLink "><span class="arrayLeftBracket ">[</span></a><span class="objectBox objectBox-number ">4</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">3</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">5</span><span class="arrayComma ">, </span><span class="objectBox objectBox-number ">6</span><a class="objectLink "><span class="arrayRightBracket ">]</span></a></span></p>
<h2><span class="objectBox objectBox-array "><span class="arrayRightBracket ">4、some和array<br /></span></span></h2>
<p><span class="objectBox objectBox-array "><span class="arrayRightBracket ">用于进行数组的逻辑判断，some即存在，every即所有<br /></span></span></p>
<p><span class="objectBox objectBox-array "><span class="arrayRightBracket ">在空数组上调用，some返回false;every返回true<br /></span></span></p>
<h2><span class="objectBox objectBox-array "><span class="arrayRightBracket ">5、reduce和reduceRight<br /></span></span></h2>
<h4 class="chapter"><a id="363">Array.prototype.reduce ( callbackfn [ , initialValue ] )</a></h4>
<p>参数列表</p>
<p>callbackfn</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; previousValue :（initialValue 的值或上次调用 callbackfn 的返回值</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; currentValue:当前元素的遍历对象</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; index:当前元素下标</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; array:遍历的数组</p>
<p><a id="363">initialValue:初始值</a></p>
<p><span style="color: #ffcc00;"><span style="color: #ff0000;">如果</span>为 reduce 调用提供了一个 initialValue，则 previousValue 将等于 initialValue 并且 currentValue 将等于数组的首个元素值。</span></p>
<p><span style="color: #ffcc00;"><span style="color: #ff0000;">如果</span>没提供 initialValue，则 previousValue 将等于数组的首个元素值并且 currentValue 将等于数组的第二个元素值。</span></p>
<p><span style="color: #ffcc00;"><span style="color: #ff0000;">如果</span>数组里<span style="color: #ff0000;">没有元素</span>并且<span style="color: #ff0000;">没有提供 initialValue</span>，则抛出一个 TypeError 异常</span></p>
<pre class="brush: js">var data = [4,5,6,7];

console.log(data.reduce(function(a,b){return a+b;}));

console.log(data.reduce(function(a,b){return a+b;},10));</pre>
<p><span class="objectBox objectBox-array "><span class="arrayRightBracket ">结果：</span></span></p>
<p><span class="objectBox objectBox-array "><span class="arrayRightBracket ">22<br /></span></span></p>
<p><span class="objectBox objectBox-array "><span class="arrayRightBracket ">32<br /></span></span></p>
<h2><span style="color: #ffcc00;"><span class="objectBox objectBox-array "><span class="arrayRightBracket ">reduceRight</span></span>处理按索引从高到低处理</span></h2>
<h2><span class="objectBox objectBox-array "><span class="arrayRightBracket ">6、indexOf 和 lastIndexOf<br /></span></span></h2>
<h4 class="chapter"><a id="356">Array.prototype.indexOf ( searchElement [ , fromIndex ] )</a></h4>
<p><span class="objectBox objectBox-array "><span class="arrayRightBracket ">用于查找数组中是否存在指定的值，不存在返回-1<br /></span></span></p>
<h4 class="chapter"><a id="356">fromIndex:指定开始搜索的下标</a></h4>