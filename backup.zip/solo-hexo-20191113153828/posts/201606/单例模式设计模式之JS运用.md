title: 单例模式--设计模式之JS运用
date: '2016-06-01 11:33:40'
updated: '2016-06-01 11:57:53'
tags: [web, 前端, 设计模式, js, 单例模式, singleton]
permalink: /articles/2016/06/01/1464751895534.html
---
<p>1、单例模式</p>
<p>这种模式涉及到一个单一的类，该类负责创建自己的对象，同时确保只有单个对象被创建。这个类提供了一种访问其唯一的对象的方式，可以直接访问，不需要实例化该类的对象。</p>
<p><strong>注意：</strong></p>
<ul>
<li>1、单例类只能有一个实例。</li>
<li>2、单例类必须自己创建自己的唯一实例。</li>
<li>3、单例类必须给所有其他对象提供这一实例。</li>
</ul>
<p>2、js中实现</p>
<pre class="brush: js">/**
 * 单例
 * @constructor
 */
function Singleton(){
    this.signle= null;
    this.index = 0;

}

Singleton.getInstance=function(){
    if(this.signle == null){
        this.signle = new Singleton();
    }
    return this.signle;
};

Singleton.prototype.countAdd=function(){
    console.log(this.index++);
};</pre>