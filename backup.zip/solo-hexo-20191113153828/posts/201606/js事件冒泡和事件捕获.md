title: js事件冒泡和事件捕获
date: '2016-06-27 15:10:42'
updated: '2016-06-27 15:23:15'
tags: [js, web, 前端, addEventListener, attachEvent]
permalink: /articles/2016/06/27/1467011442641.html
---
<h2>1、事件冒泡</h2>
<p>即由触发元素开始，依次触发上级元素的事件</p>
<h2>2、事件捕获</h2>
<p>即由最上层元素开始，依次向下直到触发本元素的事件</p>
<h2>3、addEventListener 和 attachEvent</h2>
<p>addEventListener(event,fn,useCapture)</p>
<p>useCapture:true -- 事件捕获；false--事件冒泡</p>
<p>attachEvent(event,fn) 默认事件冒泡方式触发</p>
<h2>4、范例</h2>
<pre class="brush: xml">&lt;body id="bt"&gt;

	&lt;span  id="p1"&gt;
		&lt;div id="c1" style="width:100px;height:100px;border:1px solid #000;"&gt;
			
		&lt;/div&gt;
	&lt;/span&gt;
  &lt;script&gt;
	var c1 = document.getElementById("c1");
	var p1 = document.getElementById("p1");
	var bt = document.getElementById("bt");
	if(window.addEventListener){
		c1.addEventListener("click",function(event){
			alert(1.1);
		},true)
		p1.addEventListener("click",function(event){
			alert(1.2);
		},true)
		bt.addEventListener("click",function(event){
			alert(1.3);
		},true)
	}else{
		c1.attachEvent("onclick",function(event){
			alert(2.1);
		})
		p1.attachEvent("onclick",function(event){
			alert(2.2);
		})
		bt.attachEvent("onclick",function(event){
			alert(2.3);
		})
	}
	
  &lt;/script&gt;

 &lt;/body&gt;</pre>
<p>-在firefox中触发了addEventListener。依次结果，1.3,1.2,1.1;</p>
<p>修改useCapture为false. 依次结果，1.1,1.2,1.3;</p>
<p>-在不支持addEventListener的浏览器，如IE</p>
<p>触发attachEvent，依次结果，1.1,1.2,1.3;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>