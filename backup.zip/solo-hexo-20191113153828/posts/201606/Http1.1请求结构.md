title: Http1.1请求结构
date: '2016-06-27 17:53:50'
updated: '2016-06-27 17:53:50'
tags: [response, request, 前端, http, web]
permalink: /articles/2016/06/27/1467021215909.html
---
<p>1)建立连接</p>
<p>2)发送请求</p>
<p><span style="color: #ff0000;">request headers</span></p>
<ul>
<li>get/post&nbsp; 资源路径 协议（http/1.1）</li>
<li>host: 主机域名</li>
<li>客户端相关信息</li>
<ul>
<li>Accept: text/html...</li>
<li>Accept-Encoding；gzip</li>
<li>Accept-Language:zh-CN...</li>
<li>User-Agent:...</li>
</ul>
<li><a target="_blank" href="http://blog.uproject.cn/articles/2016/06/26/1466919302840.html">缓存相关</a></li>
<ul>
<li>Cache-Control:...</li>
<li>Pragma:no-cache</li>
</ul>
<li>通信相关</li>
<ul>
<li>Connection:keep-alive</li>
</ul>
<li>其他</li>
<ul>
<li>Referer:...</li>
</ul>
</ul>
<p>3)接受响应</p>
<p><span style="color: #ff0000;">Response Headers</span></p>
<ul>
<li>Http/1.1 200 ok</li>
<li>缓存相关</li>
<ul>
<li>Cache-Control:max-age:xxx</li>
<li>Date:服务器响应时间</li>
<li>Expires:文档过期时间</li>
<li>Vary:</li>
</ul>
<li>文档实体相关</li>
<ul>
<li>Content-length:xxxx</li>
<li>Content-type:</li>
<li>ETag:文档标示</li>
<li>Last-Modifed:最后修改时间</li>
</ul>
<li>通信相关</li>
<ul>
<li>Connection：keep-alive</li>
<li>Content-Encoding:gzip</li>
</ul>
</ul>
<p>Response body</p>
<p>响应数据块</p>
<p>&nbsp;</p>
<p>&nbsp;</p>