title: 关于this作用域
date: '2016-06-24 19:03:06'
updated: '2016-06-30 12:48:19'
tags: [js, this, web, 前端]
permalink: /articles/2016/06/24/1466766186089.html
---
<p>一、作为函数调用</p>
<pre class="brush: js">function a(){
 this.p1 = 1;
 console.log(this)//window
}

a();//console.log:Window
window.p1 = 1;//验证</pre>
<p>--作为函数调用时 即a(),结果为Window对象</p>
<p>二、作为某个对象的属性方法调用</p>
<pre class="brush: js">function a(){
 //this.p1 = 1;//如果不注释，此p1将覆盖b的p1
 console.log(this.p1);//this:b
 
}

var b={};
b.p1 = 2；
b.m=a;

b.m();//2

b.p1;//2</pre>
<p>三、作为构造函数使用时</p>
<pre class="brush: js">function a(){
 this.p1 = 1;
 console.log(this);//值new出来的新对象 a1
  console.log(this === a);//false
  console.log(this instanceof a)//true
}

var a1 = new a();</pre>
<p>四、apply调用时</p>
<pre class="brush: js">var p1 = 1
function a(){
  console.log(this);
 console.log(this.p1);
}

var b={};
b.p1 = 2
b.m=a;

b.m.apply();//输出window,1
b.m.apply(b);//输出b,2<br />a.apply(b)；//输出b,2</pre>
<p>四、call调用</p>
<pre class="brush: js">function c(){
  this.cp = 1;
  console.log(this); 
}

function a(){
  this.ap = 1;
  c.call(this);
}

var a1 = new a();//console:new出的a的新对象。a1{ap:1,cp:1}
</pre>