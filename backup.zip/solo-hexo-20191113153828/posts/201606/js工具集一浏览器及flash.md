title: js工具集（一）--浏览器及flash
date: '2016-06-02 10:53:38'
updated: '2016-06-02 10:54:26'
tags: [js工具集, js tools, tool, js, 浏览器, flash, userAgent]
permalink: /articles/2016/06/02/1464836007730.html
---
<p>1、获取浏览器内核及版本</p>
<pre class="brush: js">var Browser = {
		IE : window.ActiveXObject?true:false,
		FF:(navigator.userAgent.indexOf('Firefox') &gt;= 0)?true:false,
		Chrome:(navigator.userAgent.indexOf('Chrome')&gt;=0)?true:false,
		Ipad:(navigator.userAgent.indexOf('iPhone')&gt;-1 || navigator.userAgent.indexOf('iPad')&gt;-1)?true:false,
		Android:(navigator.userAgent.indexOf('Android')&gt;=0)?true:false,
		version:function(v) {
			var nav = navigator.userAgent.toLowerCase();
			if(!v) return;
			switch(v) {
				case 'IE':return nav.match(/msie ([\d.]+)/)[1];break;
				case 'FF': return nav.match(/firefox\/([\d.]+)/)[1];break;
				case 'Chrome': return nav.match(/chrome\/([\d.]+)/)[1];break;
				case 'Opera': return nav.match(/opera\/([\d.]+)/)[1];break;
				case 'Safari': return nav.match(/version\/([\d.]+)/)[1];break;
			}
		}
	};

	Browser.IE6 = (function() { return !!(Browser.IE &amp;&amp; parseInt(Browser.version('IE'))&lt;7)})();
	Browser.lte7 = (function() { return !!(Browser.IE &amp;&amp; parseInt(Browser.version('IE'))&lt;8)})();
	Browser.lte8 = (function() {return !!(Browser.IE &amp;&amp; parseInt(Browser.version('IE'))&lt;9)})();
	Browser.lte9 = (function() {return !!(Browser.IE &amp;&amp; parseInt(Browser.version('IE'))&lt;10)})();<br /><br /></pre>
<p>2、获取flash及其版本</p>
<pre class="brush: js">var checkFlash = function() {
     	     var hasFlash=0;
             var flashVersion=0;
             if(document.all) {
                 var swf = new ActiveXObject('ShockwaveFlash.ShockwaveFlash');
                 if(swf) {
                     hasFlash = 1;
                     var VSwf=swf.GetVariable("$version");
                     flashVersion=parseInt(VSwf.split(" ")[1].split(",")[0]);
                 }
             }
             else{
                 if (navigator.plugins &amp;&amp; navigator.plugins.length &gt; 0) {
                     var swf=navigator.plugins["Shockwave Flash"];
                     if (swf) {
                         hasFlash=1;
                         var words = swf.description.split(" ");
                         for (var i = 0; i &lt; words.length; ++i) {
                             if (isNaN(parseInt(words[i]))) continue;
                                 flashVersion = parseInt(words[i]);
                         }
                     }
                 }
             }
             return {f:hasFlash,v:flashVersion};
             //安装flash插件：http://www.adobe.com/software/flash/about/
     }</pre>