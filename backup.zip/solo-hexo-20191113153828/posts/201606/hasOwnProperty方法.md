title: hasOwnProperty方法
date: '2016-06-24 18:13:19'
updated: '2016-06-24 18:13:19'
tags: [hasOwnProperty, web, 前端, js]
permalink: /articles/2016/06/24/1466763199614.html
---
<h2>1、解释</h2>
<p><code>hasOwnProperty()</code>函数用于指示一个对象自身(<span style="color: #ffcc00;">不包括原型链</span>)是否具有指定名称的属性。如果有，返回<code>true</code>，否则返回<code>false</code>。</p>
<h2>2、示例</h2>
<pre class="brush: js">var a={p1:1,p2:2,p3:function(){}};

a.hasOwnProperty("p1");//true
a.hasOwnProperty("p3");//true


var B = function(){this.p4=4;}
B.prototype={
  p1:1,
  p2:2,
  p3:function(){
    
  }
}
var c1 = new B();
c1.hasOwnProperty("p1");//false
c1.hasOwnProperty("p3");//false
c1.hasOwnProperty("p4");//true</pre>