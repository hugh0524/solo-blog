title: JS类数组对象
date: '2016-06-23 10:53:36'
updated: '2016-06-23 10:53:36'
tags: [类数组, array, web, js, 前端]
permalink: /articles/2016/06/23/1466650416595.html
---
<h2>一、特性</h2>
<p>把一个具备数值类型的length属性及其值为非负整数的对象看做是一种类数组的对象</p>
<p>eg:</p>
<pre class="brush: js">var o = {}
var i = 0;
for (var i=0;i&lt;5;i++){
 o[i] = i;
}
o.length=i;//定义length属性
//使用类数组方式循环遍历
for(var j=0;j&lt;o.length;j++){
 console.log(o[j]) 
}</pre>
<h2>二、判断类数组对象方法</h2>
<pre class="brush: js">function isArraylike(o){
  if(o &amp;&amp; typeof o =="object" &amp;&amp; isFinite(o.length) &amp;&amp; o.length&gt;0 &amp;&amp; o.length ==Math.floor(o.length)&amp;&amp; o.length&lt;4294967296) 
    return true;
  else 
    return false;
}</pre>
<p>--4294967296 == 2^32</p>
<h2>三、类数组对象转换成数组</h2>
<pre class="brush: js">var a = {length:2,0:1,1:2};
isArraylike({length:2,a:1,b:2})//true

var ac = Array.prototype.slice.call(a,0);

ac.length//2
ac.map(function(c){
  return ++c;
})</pre>
<p>--可使用Array对象中能返回数组的方式将类数组对象转换成数组，如slice,splice，map等</p>
<h2>四、应用</h2>
<h3>1)遍历dom元素</h3>
<pre class="brush: js">var tags = document.getElementsByTagName("div");
isArraylike(tags);//true


var tagarr = Array.prototype.slice.call(tags)
tagarr.length</pre>