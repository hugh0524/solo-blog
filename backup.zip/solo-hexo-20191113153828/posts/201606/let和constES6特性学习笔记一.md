title: let和const --ES6特性学习笔记(一)
date: '2016-06-20 15:29:14'
updated: '2016-06-20 15:30:41'
tags: [let, const, js, ES6, 前端, web]
permalink: /articles/2016/06/20/1466406834182.html
---
<h2>一、let</h2>
<h3>1、变量作用域</h3>
<blockquote>
<p>ES6新增了<code>let</code>命令，用来声明变量。它的用法类似于<code>var</code>，但是所声明的变量，只在<code>let</code>命令所在的代码块内有效。</p>
</blockquote>
<p>eg1:</p>
<pre class="brush: js">if(2&gt;1){
  let b=1;
 var a = 1; 
}

console.log(a);//1
console.log(b);//ReferenceError: b is not defined</pre>
<p>--let申明的变量在区块外部调用保错，b只在区块内生效</p>
<p>&nbsp;</p>
<p>eg2:使用循环+延迟测试let作用域</p>
<pre class="brush: js">for(var c = 0;c&lt;2;c++){
  setTimeout(function(){
    console.log(c)
  },100) 
}
//打印出两个2

for(let c = 0;c&lt;2;c++){
  setTimeout(function(){
    console.log(c)
  },100) 
}
//打印出0,1

</pre>
<p>--let在每次的for循环代码块内有效。var出的变量在全局范围内都有效</p>
<p>&nbsp;</p>
<h3>2、let变量提升？</h3>
<pre class="brush: java">console.log(e1)//undefined
console.log(e2)//ReferenceError: can't access lexical declaration `e2' before initialization

var e1 = 0;
let e2=1;</pre>
<p>--e1的变量声明提升，输出undefined. e2则未被提升，输出需先定义</p>
<h3>3、暂时性死区（在使用let、const声明的区块内，使用到这些命令什么的变量未被定义时会报错</h3>
<p>eg:</p>
<pre class="brush: js">var p1=1;

if(2&gt;1){
  p1 = 2; //ReferenceError: can't access lexical declaration `p1' before initialization
  let p1;
}</pre>
<p><br />--p1使用了let定义，不能在该区块先使用</p>
<h3>4、同作用域重复申明错误</h3>
<pre class="brush: js">if(2&gt;1){
  var p2 = 1;
  let p2 = 2;//SyntaxError: redeclaration of var p2
}</pre>
<h2>二、const（同java中final定义的变量</h2>
<blockquote>
<p><code>const</code>声明一个只读的常量。一旦声明，常量的值就不能改变。</p>
</blockquote>
<p>const具备和let1~4点相同的特性</p>
<h3>1、const申明的变量需赋值</h3>
<pre class="brush: js">const p3;//SyntaxError: missing = in const declaration

p3 = 1</pre>
<h3>2、const申明的变量不能被修改</h3>
<pre class="brush: js">const p4 = 1;

p4 = 2;//TypeError: invalid assignment to const `p4'</pre>
<p>&nbsp;</p>
<p>&nbsp;</p>