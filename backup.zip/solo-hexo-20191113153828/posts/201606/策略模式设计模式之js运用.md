title: 策略模式--设计模式之js运用
date: '2016-06-01 11:56:28'
updated: '2016-06-01 11:57:38'
tags: [web, 前端, 设计模式, js, 策略模式, Strategy]
permalink: /articles/2016/06/01/1464753388803.html
---
<h2>1、策略模式</h2>
<p>在策略模式（Strategy Pattern）中，一个类的行为或其算法可以在运行时更改。这种类型的设计模式属于行为型模式。</p>
<h2>2、js实现</h2>
<p>1）实现一个基础类</p>
<pre class="brush: js">function Context(strategy){
    this.strategy = strategy;
}
Context.prototype.do =function(a,b){
    return this.strategy.do(a,b);
}</pre>
<p>2）实现附加策略类</p>
<pre class="brush: js">//加法
function OperationAdd(){

}
OperationAdd.prototype.do = function (a,b) {
    return a+b;
}

//乘法
function OperationMultiply(){

}
OperationMultiply.prototype.do = function (a,b) {
    return a*b;
}</pre>
<p>3、测试</p>
<pre class="brush: xml">&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head lang="en"&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;title&gt;&lt;/title&gt;
    &lt;script src="OperationAdd.js"&gt;&lt;/script&gt;
    &lt;script src="OperationMultiply.js"&gt;&lt;/script&gt;
    &lt;script src="Context.js"&gt;&lt;/script&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;script&gt;
    var c1 = new Context(new OperationAdd());
    console.log(c1.do(2,3));

    var c2 = new Context(new OperationMultiply());
    console.log(c2.do(2,3));
&lt;/script&gt;
&lt;/body&gt;
&lt;/html&gt;</pre>
<p>结果：</p>
<p><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOQAAAApCAIAAACqQxKwAAABD0lEQVR4nO3cwY2DMBCGUXdERe4HGqACCkApgRqQKMd7SLLnPYy1+qX3CrBy+DQiFkMbEKL99w+AvxIrMcRKDLESozDWZ1vW1tbW1tavumPhozDWq2uUmSpj3fqxtLW1fbvrToWvymfW+7zuMcb9WoxYJpjxB+vZ+stspVxdrOexbM8YJiuzzLgNOM66Q+GXe1ZiiJUYYiWGWIkhVmKIlRjtgRAmKzHESgyxEkOsxBArMcRKDLESozTW83gvDHbvCDJBXazeuWayyk0BA5WpymK9t6P33WMA8xTGun92sMbVFwuD1JuwMChW5qi8DTj7e2HQRy6Ywj0rMcRKDLESQ6zEECsx7GARw2QlhliJ8QN7pwsQzhb2lQAAAABJRU5ErkJggg==" alt="" /></p>