title: JS中Boolean和Number
date: '2016-06-23 13:36:35'
updated: '2016-06-23 13:36:35'
tags: [Number, Boolean, 前端, web, js]
permalink: /articles/2016/06/23/1466660192378.html
---
<h3>一、案例</h3>
<pre class="brush: java">if(Boolean(0)){
 console.log("Boolean(0)");
}
if(new Boolean(0)){
console.log("new Boolean(0)");
}</pre>
<p>结果：输出new Boolean(0)</p>
<h2>二、ECMASCRIPT中Boolean和Number</h2>
<p>在js中Boolean 和 Number</p>
<h3>1)当把 Boolean/Number 作为函数来调用，而不是作为构造器，它执行一个类型转换。</h3>
<pre class="brush: js">Boolean(1);//true
Boolean(0);//false
Boolean(null);//false

Number(1.2);//1.2
Number("a");//NaN
Number(0xf);//15</pre>
<h3>2)当 Boolean/Number 作为 new 表达式的一部分来调用，那么它是一个构造器：它初始化新创建的对象。</h3>
<pre class="brush: jfx">new Boolean(0);//Boolean对象 toString()为&lsquo;false&rsquo;

new Number(0);//Number对象</pre>