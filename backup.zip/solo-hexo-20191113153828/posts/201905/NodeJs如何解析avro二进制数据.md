title: NodeJs如何解析avro二进制数据
date: '2019-05-14 12:10:49'
updated: '2019-05-14 12:10:49'
tags: [avro, avsc, node, js, 前端, web]
permalink: /articles/2019/05/14/1557806617681.html
---
<p>背景： 做监控系统时，需要接受kafaka中传输的监控数据，传输来源采用<a href="http://avro.apache.org/docs/current/" target="_blank">avro</a>编码 + application/octet-stream 二进制传输</p>
<p>处理方法:</p>
<p>1. 选择合适的框架 <a href="https://www.npmjs.com/package/avsc" target="_blank">avsc</a>， <a href="https://github.com/mtth/avsc/wiki/API" target="_blank">api文档</a></p>
<pre class="prettyprint">npm install avsc<br /><br /><br /></pre>
<p>2. 具体处理</p>
<pre class="prettyprint">// 定义长度标识
var i =0;
if("application/octet-stream" == req.headers['content-type']) {
            i = req.body.length
        }

// 定义schema
const type = avro.Type.forSchema({
                "namespace": "xxx",
                "name": "Model",
                "type": "record",
                "fields": [
                    {
                        "name": "appId",
                        "type": "string"
                    }...]

// 分段解析数据， 放入队列等待业务处理
try{
            var off = 0, total = 0;
            while(off &lt; req.body.length){
                let decoded = type.decode(req.body, off); // No precision loss.
                off = decoded.offset
                state.addToQueue("track_queue", {item:decoded.value})
                total++;
            }

        }catch(e){
            console.log(e)
        }</pre>