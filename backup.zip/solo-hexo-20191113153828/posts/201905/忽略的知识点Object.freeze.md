title: 忽略的知识点-Object.freeze
date: '2019-05-14 13:49:44'
updated: '2019-05-14 13:49:58'
tags: [js, 前端, object, freeze, web, js_base]
permalink: /articles/2019/05/14/1557812984715.html
---
<h2>1. freeze作用</h2>
<p><span>方法可以</span><strong>冻结</strong><span>一个对象。</span></p>
<p>1. 一个被冻结的对象再也<span style="color: #ff0000;">不能被修改</span>； <a href="http://tools.uproject.cn/tools/showDemo?id=56" target="_blank">demo</a></p>
<p><span>2. 冻结了一个对象则<span style="color: #ff0000;">不能</span>向这个对象<span style="color: #ff0000;">添加</span>新的属性，</span></p>
<p><span>3. <span style="color: #ff0000;">不能删除</span>已有属性，</span></p>
<p><span>4. 不能修改该对象已有属性的<span style="color: #ff0000;">可枚举性、可配置性、可写性</span>，</span></p>
<p><span>5. 不能修改已有属性的值。</span></p>
<p><span>6. 冻结一个对象后该<span style="color: #ff0000;">对象的原型</span>也不能被修改。</span></p>
<p><code>7. freeze()</code><span>&nbsp;返回和传入的参数相同的对象。</span></p>
<p><span>&nbsp;</span></p>
<h2><span>2. 注意点</span></h2>
<p><span>1. 使用freeze,在非严格模式下会<span style="color: #ff0000;">默默失败</span>， 在<span style="color: #ff0000;">严格模式</span>下会报错</span></p>
<p><span>2. freeze只是<span style="color: #ff0000;">浅冻结</span>， 只会冻结当前对象具备的属性， 但是深层次的对象不会被冻结</span></p>
<pre class="prettyprint">obj1 = {
  internal: {}
};

Object.freeze(obj1);
obj1.internal.a = 'aValue';

obj1.internal.a // 'aValue'</pre>
<p><span>&nbsp;</span></p>
<p>3. <span style="color: #ff0000;">深冻结</span>，需要遍历对象的属性，对<span style="color: #ff0000;">对象类型</span>的属性执行object.freeze</p>
<p><a href="https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Object/freeze" target="_blank">详例</a></p>