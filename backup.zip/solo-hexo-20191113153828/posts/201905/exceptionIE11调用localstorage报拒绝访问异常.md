title: 【exception】-IE11调用localstorage 报拒绝访问异常
date: '2019-05-23 19:50:11'
updated: '2019-05-24 09:51:37'
tags: [exception, js, 前端, web]
permalink: /articles/2019/05/23/1558612211154.html
---
<p>代码如下</p>
<pre class="prettyprint"> var LStorage = function () {
        var self = this;

        this.canUse = function () {
          
          return !!window.localStorage;  
        };

        this.setItem = function (key, value) {
            if (self.canUse()) {
                try {
                    localStorage.setItem(key, value);
                    return true;
                } catch (oException) {
                    if (oException.name == 'QuotaExceededError') {
                        return false;
                    }
                }
            }
            return false;
        };
        this.getItem = function (key) {
            if (self.canUse()) {
                return localStorage.getItem(key);
            }
            return null;
        };
        this.removeItem = function (key) {
            if (self.canUse()) {
                localStorage.removeItem(key);
            }
        }
    };
</pre>
<p>&nbsp;</p>
<p>错误：</p>
<p>&nbsp;</p>
<p><a href="http://tools.uproject.cn/upload/article/1558612056596.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/1558612056596.jpg" alt="" width="400" height="227" /></a></p>
<p>&nbsp;</p>
<p>解决：&nbsp;</p>
<p>对调用localstorage处加try... catch...</p>
<p>&nbsp;</p>
<p>附加</p>
<p>chrome 70.x 偶有报错&nbsp;</p>
<pre class="exc-message">Failed to read the 'localStorage' property from 'Window': Access is denied for this document.</pre>