title: 防止`运营商劫持`，CSP or JS方法处理
date: '2019-05-13 11:32:49'
updated: '2019-05-13 11:37:10'
tags: [web, js, csp, 前端]
permalink: /articles/2019/04/29/1556508575314.html
---
<p>如果有https的条件，尽量使用https，可以很大程度上防止劫持的发生</p>
<h2>csp</h2>
<p>&nbsp;问题： 可能导致部分js被莫名的 blocked</p>
<p>&nbsp;辅助用法： 基于csp的report功能，对运行环境中加载的资源进行上报监控</p>
<h2>js方式</h2>
<pre class="prettyprint">var MutationObserver = window.MutationObserver || window.WebKitMutationObserver ||  window.MozMutationObserver;
            var whiteListForCSP = [
                'http(s)?:\/\/(.)+.xxx.com',
                'http(s)?:\/\/hm.baidu.com',
                'http(s)?:\/\/res.wx.qq.com'
            ]

            // Mutation 观察者对象能监听在某个范围内的 DOM 树变化
            if(MutationObserver) {
                var observer = new MutationObserver(function(mutations) {
                    mutations.forEach(function(mutation) {
                        // 返回被添加的节点,或者为null.
                        var nodes = mutation.addedNodes;
                        for (var i = 0; i &lt; nodes.length; i++) {
                            var node = nodes[i];
                            var tagName = node.tagName &amp;&amp; node.tagName.toLowerCase()
                            if ((tagName === "script" || tagName === "iframe" || tagName === "img" || tagName === "link") &amp;&amp; node.src &amp;&amp; (node.src.indexOf(window.location.protocol+"://"+window.location.hostname) !=0 &amp;&amp; !new RegExp("^("+whiteListForCSP.join(")|(")+")").test(node.src))) {
                                try {
                                    node.parentNode.removeChild(node);
                                    console.log('拦截非白名单文件:', node.src);
                                } catch (e) {}
                            }
                        }
                    })
                })
            }
            // 传入目标节点和观察选项
            observer.observe(document, {
                subtree: true,
                childList: true
            });</pre>
<p>&nbsp;</p>
<p>&nbsp;</p>