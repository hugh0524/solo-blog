title: 忽略的知识点- 数组index
date: '2019-05-04 16:07:35'
updated: '2019-05-14 10:06:52'
tags: [array, web, 前端, js, js_base]
permalink: /articles/2019/05/04/1556957255162.html
---
<p>1. 来源</p>
<pre class="prettyprint">  function flushCallbacks () {
    pending = false;
    var copies = callbacks.slice(0);
    callbacks.length = 0;
    for (var i = 0; i &lt; copies.length; i++) {
      copies[i]();
    }
  }</pre>
<p>vue中有以上的一段代码， callbacks为一个Array。 作用是首先取了callbacks的copy对象， 接着讲callbacks设置为空数组</p>
<p>&nbsp;</p>
<p>2. 知识点</p>
<p><strong>array.length</strong></p>
<blockquote>
<p>来源：&nbsp;<a href="https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Array/length" target="_blank">https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Array/length</a></p>
<p><span>你可以设置&nbsp;</span><code>length</code><span>&nbsp;属性的值来截断任何数组。当通过改变</span><code>length</code><span>属性值来扩展数组时，实际元素的数目将会增加。例如：将一个拥有 2 个元素的数组的&nbsp;</span><code>length</code><span>&nbsp;属性值设为&nbsp;3 时，那么这个数组将会包含3个元素，并且，第三个元素的值将会是&nbsp;</span><code>undefined</code><span>&nbsp;。</span></p>
<p>&nbsp;</p>
</blockquote>
<pre class="prettyprint">var arr = [1,2,3]
arr.length = 0;// arr 变为 []
</pre>
<table class="standard-table" border="1">
<thead>
<tr><th class="header" colspan="2"><code>Array.length</code>&nbsp;属性的属性特性：</th></tr>
</thead>
<tbody>
<tr>
<td>writable</td>
<td>true</td>
</tr>
<tr>
<td>enumerable</td>
<td>false</td>
</tr>
<tr>
<td>configurable</td>
<td>false</td>
</tr>
</tbody>
</table>