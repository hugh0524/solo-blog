title: '【exception】- TypeError: Illegal invocation'
date: '2019-05-23 19:29:46'
updated: '2019-05-23 19:29:46'
tags: [js, web, 前端, exception]
permalink: /articles/2019/05/23/1558610986107.html
---
<p>案例：</p>
<pre class="prettyprint">function a() {
  return console.log
}

// 调用
a()(1) // chrome高版本下运行  1。 QQ9.0.x版本下：报错 Illegal invocation</pre>
<p>原因：</p>
<p>调用域不同导致</p>
<p>&nbsp;</p>
<p>解决：&nbsp;</p>
<pre class="prettyprint">a().call(console, 1) // 1</pre>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>参考：</p>
<p><a href="https://stackoverflow.com/questions/20229797/illegal-invocation-with-javascript">https://stackoverflow.com/questions/20229797/illegal-invocation-with-javascript</a></p>