title: 修复弹窗或者toast在页面被嵌入iframe展示的问题
date: '2019-10-17 12:23:06'
updated: '2019-10-17 12:23:06'
tags: [js, 前端, web, offset, top, toast, iframe]
permalink: /articles/2019/10/17/1571286186229.html
---
<p>1. 页面本身的toast 或者弹窗</p>
<p>我们可以基于fixed的层，进行排布，居中或置顶xx%</p>
<p>2. 如果页面本身被嵌入了一个iframe, iframe大小又不可控的情况下</p>
<p>如果还使用1中描述的方式， 将会出现以下位置的偏差， 如下</p>
<p><a href="http://tools.uproject.cn/upload/article/1571286015510.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/1571286015510.jpg" alt="" width="500" height="693" /></a></p>
<p>&nbsp;</p>
<p>修复方式</p>
<p>基于点击和默认窗口高度，计算出实际的top值</p>
<pre class="brush: css">iframe-alert {
  position: absolute;
}</pre>
<pre class="brush: js">resetTopOffset() {
      if(type !== "partner") {
        this.topOffset("20%");
        return;
      }
      // https://developer.mozilla.org/zh-CN/docs/Web/API/MouseEvent/pageX, 默认800兼容不支持pageY的情况
      var ev = window.event;
      let baseHeight = 500
      if(ev &amp;&amp; ev.pageY &gt; 40) {
        // 直接取事件对应的偏移
        this.topOffset((ev.pageY - 40) + "px");
      } else {
        // 取当前窗口 top + 视窗大小的一半
        this.topOffset(($("html").scrollTop() + baseHeight/2) + "px");
      }
    }
</pre>
<p>&nbsp;</p>
<p>&nbsp;</p>