title: mongodb 如何将查询出的数据格式转换成json
date: '2019-06-21 09:52:58'
updated: '2019-06-21 09:52:58'
tags: [mongodb, node, web, 前端, js]
permalink: /articles/2019/06/21/1561081978047.html
---
<p>1. 前提</p>
<p>NodeJS + Mongodb</p>
<p>2. 问题</p>
<p>node查询mongo，默认结果集是mongo数据格式， 如果要在业务中进行拼接会比较麻烦， 转换成json是个合适的选择</p>
<p>3. 如何处理</p>
<p>mongo查询query对象有个options的输入</p>
<p>接受参数可<a href="https://mongoosejs.com/docs/api/query.html#query_Query-setOptions" target="_blank">参考</a></p>
<p>内有<span style="color: #ff0000;"><strong>lean</strong></span>的参数，适用于以下操作</p>
<p><code>find()</code>,&nbsp;<code>findOne()</code>,&nbsp;<code>findById()</code>,&nbsp;<code>findOneAndUpdate()</code>, and&nbsp;<code>findByIdAndUpdate()</code></p>
<div>&nbsp;可返回json类型查询结果</div>
<div>&nbsp;</div>
<div>4. demo</div>
<div>
<pre class="prettyprint">var pros = await this.userProjectRoleDao.query({uid: uid}, null, {lean: true})
        // 根据project 查询项目
        var proIds = [];
        pros.forEach((pro) =&gt; {
            proIds.push(pro.projectId)
        })
</pre>
</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>参考：</p>
<p><a href="https://mongoosejs.com/docs/api/query.html#query_Query-setOptions">https://mongoosejs.com/docs/api/query.html#query_Query-setOptions</a></p>