title: '【转】exception-unable to locate package oracle-java7-installer '
date: '2017-08-14 10:52:35'
updated: '2017-08-14 10:52:35'
tags: [java, oracle, linux, exception]
permalink: /articles/2017/08/14/1502679155130.html
---
<p>1、错误</p>
<pre class="brush: bash">root@xxxx:/home/xxx# apt-get install oracle-java7-installer
Reading package lists... Done
Building dependency tree
Reading state information... Done
E: Unable to locate package oracle-java7-installer</pre>
<p>2、解决</p>
<div>Adding to&nbsp;<code>deb</code>.</div>
<pre><code> root@ubuntu:~# echo "deb http://ppa.launchpad.net/webupd8team/java/ubuntu precise main" &gt; /etc/apt/sources.list.d/webupd8team-java.list
</code></pre>
<div>Adding to&nbsp;<code>deb-src</code></div>
<pre><code> root@ubuntu:~# echo "deb-src http://ppa.launchpad.net/webupd8team/java/ubuntu precise main" &gt;&gt; /etc/apt/sources.list.d/webupd8team-java.list
</code></pre>
<div>Making sure we have the key as well.</div>
<pre><code> root@ubuntu:~# apt-key adv --keyserver keyserver.ubuntu.com --recv-keys EEA14886
</code></pre>
<div>Lets&nbsp;<code>update</code>&nbsp;our&nbsp;<code>apt-get</code>&nbsp;repository.</div>
<pre><code> root@ubuntu:~# apt-get update
</code></pre>
<div>Now Install Oracle Java</div>
<pre><code> root@ubuntu:~# apt-get install oracle-java7-installer</code></pre>