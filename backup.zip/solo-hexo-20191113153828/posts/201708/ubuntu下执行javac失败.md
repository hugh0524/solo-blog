title: ubuntu下执行javac失败
date: '2017-08-14 23:06:29'
updated: '2017-08-14 23:10:56'
tags: [ubuntu, linux, java, jdk]
permalink: /articles/2017/08/14/1502723189869.html
---
<p>1、失败症状</p>
<pre class="brush: java">BUILD FAILED
/home/hugh/runjs/RunJS/RunJS/build.xml:25: Unable to find a javac compiler;
com.sun.tools.javac.Main is not on the classpath.
Perhaps JAVA_HOME does not point to the JDK</pre>
<p>2、解决方案</p>
<p>执行 （可省）</p>
<pre class="brush: java">sudo update-java-alternatives -s java-1.7.0-openjdk-amd64</pre>
<p>java-1.7.0-openjdk-amd64 &nbsp;指你在/usr/lib/jvm下安装的java对应版本</p>
<p>执行 javac 提示需要安装 jdk</p>
<p>apt-get install openjdk-7-jdk</p>
<p>即可正常执行</p>
<p>&nbsp;</p>
<p>&nbsp;</p>