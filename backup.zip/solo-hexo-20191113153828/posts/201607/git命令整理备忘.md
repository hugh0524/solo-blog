title: git命令整理备忘
date: '2016-07-22 12:19:47'
updated: '2016-07-22 12:19:47'
tags: [构建, git]
permalink: /articles/2016/07/22/1469161187456.html
---
<h1>一、基本操作</h1>
<h2>1、版本回退</h2>
<div><ol>
<li><span>$ git reset&nbsp;</span><span>--</span><span>hard&nbsp;</span><span>3628164</span></li>
<li></li>
</ol></div>
<p><span>3628164 为版本号前几位</span></p>
<div><span style="color: #195f91; font-family: Menlo, Monaco, 'Courier New', monospace;"><span>HEAD^ 表示回退到上个版本</span></span></div>
<div><span style="color: #195f91; font-family: Menlo, Monaco, 'Courier New', monospace;"><span>HEAD^^ 回退到上上个版本</span></span></div>
<div><span style="color: #195f91; font-family: Menlo, Monaco, 'Courier New', monospace;"><span>&nbsp;</span></span></div>
<h2><span>2、查看操作日志</span></h2>
<div><span>git reflog</span></div>
<div>&nbsp;</div>
<div>可以查看到操作记录信息</div>
<div>&nbsp;</div>
<h2>3、撤销修改</h2>
<div><span>命令</span><span>git checkout -- readme.txt</span><span>意思就是，把</span><span>readme.txt</span><span>文件在工作区的修改全部撤销，这里有两种情况：</span></div>
<div>
<ul>
<li>一种是readme.txt自修改后还没有被放到暂存区，现在，撤销修改就回到和版本库一模一样的状态；</li>
<li>一种是readme.txt已经添加到暂存区后，又作了修改，现在，撤销修改就回到添加到暂存区后的状态。</li>
</ul>
<h2><span style="color: #333333; font-family: 'Helvetica Neue', Helvetica, Arial, 'Hiragino Sans GB', 'Hiragino Sans GB W3', 'Microsoft YaHei UI', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif; font-size: medium;">4、将文件从暂存区还原出来</span></h2>
</div>
<div><span>git reset HEAD file</span></div>
<div><span style="color: #333333; font-family: 'Helvetica Neue', Helvetica, Arial, 'Hiragino Sans GB', 'Hiragino Sans GB W3', 'Microsoft YaHei UI', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif; font-size: medium;">&nbsp;</span></div>
<h2><span style="color: #333333; font-family: 'Helvetica Neue', Helvetica, Arial, 'Hiragino Sans GB', 'Hiragino Sans GB W3', 'Microsoft YaHei UI', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif; font-size: medium;">5、版本库删除文件</span></h2>
<div><ol>
<li><span>$ git rm test</span><span>.</span><span>txt</span></li>
<li><span>$ git commit&nbsp;</span><span>-</span><span>m&nbsp;</span><span>"remove test.txt"</span></li>
</ol></div>
<h1><span style="color: #333333; font-family: 'Helvetica Neue', Helvetica, Arial, 'Hiragino Sans GB', 'Hiragino Sans GB W3', 'Microsoft YaHei UI', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif; font-size: medium;">二、分支管理</span></h1>
<h2><span style="color: #333333; font-family: 'Helvetica Neue', Helvetica, Arial, 'Hiragino Sans GB', 'Hiragino Sans GB W3', 'Microsoft YaHei UI', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif; font-size: medium;">1、创建并切换分支</span></h2>
<ol>
<li><span>$ git checkout&nbsp;</span><span>-</span><span>b dev</span></li>
</ol>
<div><span style="color: #333333; font-family: 'Helvetica Neue', Helvetica, Arial, 'Hiragino Sans GB', 'Hiragino Sans GB W3', 'Microsoft YaHei UI', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif; font-size: medium;">&nbsp; &nbsp;等同于</span></div>
<ol>
<li><span>$ git branch dev</span></li>
<li><span>$ git checkout dev</span></li>
</ol>
<div><span style="color: #333333; font-family: 'Helvetica Neue', Helvetica, Arial, 'Hiragino Sans GB', 'Hiragino Sans GB W3', 'Microsoft YaHei UI', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif; font-size: medium;">&nbsp;</span></div>
<div>
<p style="padding-left: 60px;"><span style="color: #ff9900;">查看分支：git branch</span></p>
<p style="padding-left: 60px;"><span style="color: #ff9900;">创建分支：git branch &lt;name&gt;</span></p>
<p style="padding-left: 60px;"><span style="color: #ff9900;">切换分支：git checkout &lt;name&gt;</span></p>
<p style="padding-left: 60px;"><span style="color: #ff9900;">创建+切换分支：git checkout -b &lt;name&gt;</span></p>
<p style="padding-left: 60px;"><span style="color: #ff9900;">合并某分支到当前分支：git merge &lt;name&gt;</span></p>
<p style="padding-left: 60px;"><span style="color: #ff9900;">删除分支：git branch -d &lt;name&gt;</span></p>
</div>
<div><span style="color: #333333; font-family: 'Helvetica Neue', Helvetica, Arial, 'Hiragino Sans GB', 'Hiragino Sans GB W3', 'Microsoft YaHei UI', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif; font-size: medium;">&nbsp;</span></div>
<h2><span style="color: #333333; font-family: 'Helvetica Neue', Helvetica, Arial, 'Hiragino Sans GB', 'Hiragino Sans GB W3', 'Microsoft YaHei UI', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif; font-size: medium;">2、合并分支</span></h2>
<ol>
<li><span>$ git merge&nbsp;</span><span>--</span><span>no</span><span>-</span><span>ff&nbsp;</span><span>-</span><span>m&nbsp;</span><span>"merged bug fix 101"</span><span>&nbsp;issue</span><span>-</span><span>101</span></li>
</ol>
<div>&nbsp;</div>
<h2><span>3、多人协作下</span></h2>
<div><span>因此，多人协作的工作模式通常是这样：</span>
<ul>
<li>首先，可以试图用<span>git push origin branch-name</span>推送自己的修改；</li>
<li>如果推送失败，则因为远程分支比你的本地更新，需要先用<span>git pull</span>试图合并；</li>
<li>如果合并有冲突，则解决冲突，并在本地提交；</li>
<li>没有冲突或者解决掉冲突后，再用<span>git push origin branch-name</span>推送就能成功！</li>
</ul>
<p>　　如果git pull提示<span>&ldquo;no tracking information&rdquo;</span>，则说明本地分支和远程分支的链接关系没有创建，用命令<span>git branch --set-upstream branch-name origin/branch-name</span>。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
<p>&nbsp;</p>
<h1>三、tag标签</h1>
<ul>
<li>命令<span>git tag &lt;name&gt;</span>用于新建一个标签，默认为<span>HEAD</span>，也可以指定一个<span>commit id</span>；</li>
<li><span>git tag -a &lt;tagname&gt; -m "blablabla..."</span>可以指定标签信息；</li>
<li><span>git tag -s &lt;tagname&gt; -m "blablabla..."</span>可以用PGP签名标签；</li>
<li>命令<span>git tag</span>可以查看所有标签。</li>
</ul>
<ol>
<li><span>$ git show v0</span><span>.</span><span>1</span></li>
</ol>
<p>查看v0.1的tag相关信息</p>
<ul>
<li><span>git push origin &lt;tagname&gt;</span>可以推送一个本地标签；</li>
<li><span>git push origin --tags</span>可以推送全部未推送过的本地标签；</li>
<li><span>git tag -d &lt;tagname&gt;</span>可以删除一个本地标签；</li>
<li><span>git push origin :refs/tags/&lt;tagname&gt;</span>可以删除一个远程标签。</li>
</ul>
<h1>四、config</h1>
<ol>
<li><span>$ git config&nbsp;</span><span>--</span><span>global</span><span>&nbsp;</span><span>alias</span><span>.</span><span>co checkout</span></li>
<li><span>$ git config&nbsp;</span><span>--</span><span>global</span><span>&nbsp;</span><span>alias</span><span>.</span><span>ci commit</span></li>
<li><span>$ git config&nbsp;</span><span>--</span><span>global</span><span>&nbsp;</span><span>alias</span><span>.</span><span>br branch</span></li>
<li></li>
</ol>