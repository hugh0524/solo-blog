title: 'java.net.UnknownHostException: bogon: bogon: nodename nor servname provided,
  or not known--异常'
date: '2016-07-16 23:57:04'
updated: '2016-07-16 23:59:09'
tags: [mac, java, 异常, exception]
permalink: /articles/2016/07/16/1468684624515.html
---
<p>异常：</p>
<p>在Mac下myeclipse启动web 报如下错误</p>
<p><span>Error: Exception thrown by the agent : java.net.MalformedURLException: Local host name unknown: java.net.UnknownHostException: bogon: bogon: nodename nor servname provided, or not known</span></p>
<p><span>&nbsp;</span></p>
<p><span>处理：</span></p>
<p><span>在 etc/hosts里加</span></p>
<p><span><span>127.0.0.1 &nbsp; &nbsp;localhost bogon</span></span></p>
<p>&nbsp;</p>