title: Exception:Parameter index out of range (1 > number of parameters, which is
  0)
date: '2017-01-10 11:48:05'
updated: '2017-01-10 11:48:05'
tags: [range, exception, 异常, mybatis, sql, java]
permalink: /articles/2017/01/10/1484020085384.html
---
<p>使用mybatis,在mapping中使用了 ''</p>
<pre class="brush: xml">&lt;if test="e.subjectId&gt;0"&gt;
				AND (&lt;![CDATA[ TEACHER.SUBJECT_LINK LIKE CONCAT('%', '#{e.subjectId}','%') ]]&gt;)
			&lt;/if&gt;</pre>
<p>原因：</p>
<p>不能带有'</p>
<p>&nbsp;</p>
<p>可能造成该错误的其他原因：</p>
<p>&nbsp; 1、</p>
<h3 style="padding-left: 30px;"><span>写like语句的时候 一般都会写成 like '% %'</span></h3>
<div style="padding-left: 30px;"><strong><span>在mybatis里面写就是应该是 like &nbsp;<span>'%</span><span>${name}</span><span>&nbsp;%' 而不是&nbsp;</span><span>'%</span><span>#{name}</span><span>&nbsp;%' &nbsp;</span></span></strong>
<h3 style="padding-left: 30px;"><span><span>${name}</span><span>&nbsp;是不带单引号的，而</span><span>#{name}</span><span>&nbsp;是带单引号的</span></span></h3>
<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
<p>&nbsp;</p>