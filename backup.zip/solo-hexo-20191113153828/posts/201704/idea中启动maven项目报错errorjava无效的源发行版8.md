title: 'idea中启动maven项目报错-  error:java: 无效的源发行版: 8'
date: '2017-04-28 18:15:50'
updated: '2017-04-28 18:15:50'
tags: [jdk, idea, java, exception]
permalink: /articles/2017/04/28/1493374550409.html
---
<p>原因：本地安装的jdk和编译使用的jdk版本不符</p>
<p>&nbsp;</p>
<p>解决方法：</p>
<p>1、升级jdk版本</p>
<p>&nbsp;</p>
<p>2、修改idea中项目的编译版本</p>
<p><a href="http://tools.uproject.cn/images/1493374376262.png" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/images/1493374376262.png" alt="" width="653" height="165" /></a></p>
<p>如果使用了maven</p>
<p>请修改</p>
<p><a href="http://tools.uproject.cn/images/1493374443155.png" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/images/1493374443155.png" alt="maven jdk" width="601" height="70" /></a></p>
<p>并且执行reimport</p>
<p><a href="http://tools.uproject.cn/images/1493374510095.png" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/images/1493374510095.png" alt="reimport" width="315" height="266" /></a></p>
<p>&nbsp;</p>