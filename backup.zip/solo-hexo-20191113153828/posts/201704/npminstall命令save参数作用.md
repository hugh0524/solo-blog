title: npm install命令 -save参数作用
date: '2017-04-25 15:00:50'
updated: '2017-04-25 15:00:50'
tags: [save, js, nodejs, npm]
permalink: /articles/2017/04/25/1493103650690.html
---
<p><code>-save</code><span>和</span><code>save-dev</code><span>可以省掉你手动修改package.json文件的步骤。</span><br /><code>npm install module-name -save</code><span>&nbsp;自动把模块和版本号添加到dependencies部分</span><br /><code>npm install module-name -save-dve</code><span>&nbsp;自动把模块和版本号添加到devdependencies部分</span></p>