title: 如何对一个url字符串分析其中的构成
date: '2019-07-26 11:06:14'
updated: '2019-08-08 10:13:54'
tags: [web, 前端, url, href]
permalink: /articles/2019/07/26/1564110374675.html
---
<p>1. URL对象</p>
<pre class="prettyprint">url = new URL(url, [base])
</pre>
<p>&nbsp;</p>
<p>案例</p>
<pre class="prettyprint">var url_0 = new URL("/test/a", "http://blog.uproject.cn")
var url_1 = new URL("http://blog.uproject.cn/test/a?p=1#/abc")
//host: "blog.uproject.cn"
//hostname: "blog.uproject.cn"
//origin: "http://blog.uproject.cn"
//password: ""
//pathname: "/test/a"
//port: ""
//protocol: "http:"
//search: ""
//searchParams: URLSearchParams {}
//username: ""
//hash: "#/abc"
//href: "http://blog.uproject.cn/test/a?p=1#/abc"
//search: "?p=1"</pre>
<p>配合 URLSearchParams</p>
<pre class="prettyprint">var url = new URL('https://blog.uproject.cn?foo=1&amp;bar=2');

var params = new URLSearchParams(url.search);

console.log(params.get("foo")) // 1</pre>
<p>&nbsp;</p>
<p><span style="color: #ff0000;">注: ie11及以下不支持</span></p>
<p>2. 使用a标签</p>
<pre class="prettyprint"> function _resolveUrl(url) {
    const link = document.createElement('a');
    link.href = url;
    for(let i in link) { console.log(i + "=" +link[i])}
}
_resolveUrl("http://uproject.cn/a?p=1#/a/d")
// 包含以下属性
//href=http://uproject.cn/a?p=1#/a/d
// origin=http://uproject.cn
// protocol=http:
// username=
// password=
// host=uproject.cn
// hostname=uproject.cn
// port=
// pathname=/a
// search=?p=1
// hash=#/a/d<br /><br /></pre>
<p><span style="color: #ff0000;">注： 测试chrome支持，其他浏览器未测试， 建议使用时通过属性鉴别是否支持</span></p>
<p><span style="color: #ff0000;">&nbsp;</span></p>
<p><span style="color: #000000;">3.使用正则解析</span></p>
<p><span style="color: #000000;">详见<a href="https://docs.uproject.cn/js%E5%B8%B8%E7%94%A8%E5%B7%A5%E5%85%B7/#/%E8%A7%A3%E6%9E%90URL" target="_blank">解析URL</a></span></p>