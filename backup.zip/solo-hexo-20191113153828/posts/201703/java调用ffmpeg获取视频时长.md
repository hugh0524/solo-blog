title: java 调用ffmpeg获取视频时长
date: '2017-03-28 17:18:52'
updated: '2017-03-28 17:18:52'
tags: [java, ffmpeg]
permalink: /articles/2017/03/28/1490692725651.html
---
<p>安装ffmpge查看<a href="http://blog.uproject.cn/articles/2017/01/09/1483962121934.html" target="_blank">该文</a></p>
<p>目的：</p>
<p>对文件夹的中的mp4获取时长</p>
<p>使用ffmpge获取视频详情，从中解析出 duration的信息</p>
<pre class="brush: java">public class VadioTest {
	public void getVideoDuration(String path, StringBuffer bf)
			throws IOException, InterruptedException {
		File[] files = new File(path).listFiles();

		for (int i = 0; i &lt; files.length; i++) {
			if (!files[i].isDirectory() &amp;&amp; files[i].toString().endsWith(".mp4")) {
				List&lt;String&gt; commend = new ArrayList&lt;String&gt;();
				commend.add("ffmpeg");
				commend.add("-i");
				commend.add(files[i].getPath());
				ProcessBuilder builder = new ProcessBuilder(commend);
				builder.command(commend);
				builder.redirectErrorStream(true);

				// 进程信息输出到控制台
				Process p = builder.start();
				BufferedReader br = new BufferedReader(new InputStreamReader(
						p.getInputStream()));
				String line = null;
				while ((line = br.readLine()) != null) {
					// System.out.println(line);
					int durationIndex = line.indexOf("Duration:");
					if (durationIndex &gt; -1) {
						System.out.println(line.substring(durationIndex + 10,
								durationIndex + 20));
						String time = line.substring(durationIndex + 10,
								durationIndex + 20);
						System.out.println(time.split("\\.")[0]);
						String[] timeArr = time.split("\\.")[0].split(":");
						int time2 = Integer.valueOf(timeArr[0]) * 60
								+ Integer.valueOf(timeArr[1]);
						System.out.println(time2);
						bf.append("update xx_table set duration = "
								+ time2 + " where vadio_url like %"
								+ files[i].getName() + "%;");
					}
				}
				p.waitFor();// 直到上面的命令执行完，才向下执行

			} else if (files[i].isDirectory()) {
				getVideoDuration(files[i].getPath(), bf);
			}
		}

	}

	public static void main(String[] args) {
		String filePath = "/Users/xx/Desktop/test";
		FileWriter fw = null;
		try {
			StringBuffer sf = new StringBuffer("");
			VadioTest videoDuration = new VadioTest();
			videoDuration.getVideoDuration(filePath, sf);
			File fileOut = new File(filePath + "/1.txt");
			System.out.println(sf);

			fw = new FileWriter(fileOut);
			fw.write(sf.toString());

			fw.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if(fw != null){
				try {
					fw.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
}</pre>
<p>&nbsp;</p>