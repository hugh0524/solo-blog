title: mongoose 执行基础的CURD操作
date: '2018-12-05 12:14:19'
updated: '2018-12-05 12:14:19'
tags: [mongodb, js, node, mongoose, CRUD]
permalink: /articles/2018/12/03/1543821799569.html
---
<p>1. 数据库链接</p>
<p>参考【<a href="https://blog.uproject.cn/articles/2018/12/03/1543818131615.html" target="_blank">连接mongodb</a>】</p>
<p>2. 使用schema结构及文档名，构建model对象</p>
<pre class="brush: js">mongoose.model('ModelName', { name: String })</pre>
<p>参数类型有：</p>
<ul>
<li><a href="https://mongoosejs.com/docs/4.x/docs/api.html#schema-string-js">String</a></li>
<li><a href="https://mongoosejs.com/docs/4.x/docs/api.html#schema-number-js">Number</a></li>
<li><a href="https://mongoosejs.com/docs/4.x/docs/api.html#schema-date-js">Date</a></li>
<li><a href="https://mongoosejs.com/docs/4.x/docs/api.html#schema-buffer-js">Buffer</a></li>
<li>Boolean</li>
<li>Mixed</li>
<li><a href="https://mongoosejs.com/docs/4.x/docs/api.html#schema-objectid-js">Objectid</a></li>
<li>Array</li>
</ul>
<p>&nbsp;</p>
<p>3. 新增记录</p>
<p>&nbsp;1. 创建model实例&nbsp; &nbsp;&nbsp;</p>
<pre class="brush: java">var Kitten = mongoose.model('Kitten', {name: String});
var kitten = new Kitten({name: "cat"})
</pre>
<p>&nbsp;2. 执行save方法</p>
<pre class="brush: js">kitten.save().then(function(res){
})</pre>
<p>&nbsp;</p>
<p>4. 修改记录</p>
<p>以model对象为更新的主体</p>
<pre class="brush: js">Kitten.updateMany({uid: 1}, {name:"dog"}).then(function(res){

})</pre>
<p>5. 删除记录</p>
<p>以model对象作为删除的主体</p>
<pre class="brush: js">Kitten.delete({uid: { $gte: 1 } }).then(function(res){
 // res为执行删除操作的结果汇总
})</pre>
<p>6. 查询</p>
<p>以model对象作为查询的主体</p>
<pre class="brush: js">Kitten.findOne({ name: 'cat' }).then(function(res){
  // res为查询出的结果集
})</pre>