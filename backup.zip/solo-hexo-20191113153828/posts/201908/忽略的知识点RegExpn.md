title: 忽略的知识点 - RegExp $n
date: '2019-08-14 16:01:11'
updated: '2019-08-14 16:01:40'
tags: [js_base, 前端, web, js]
permalink: /articles/2019/08/14/1565769670964.html
---
<p>当使用到一个正则匹配时</p>
<pre class="brush: js">let regex = /(\w+)\s(\w+)/;</pre>
<p>使用以下方法</p>
<pre class="brush: js">regex.match("a b")

"a b".replace(regex, "$1,$2")</pre>
<p>或者其他正则匹配的方法时</p>
<p>全局RegExp对象将会赋值为最近一次匹配的结果</p>
<pre class="brush: js">RegExp.$1 //a
RegExp.$2 //b</pre>