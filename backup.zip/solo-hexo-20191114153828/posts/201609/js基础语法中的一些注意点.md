title: js基础语法中的一些注意点
date: '2016-09-27 15:26:25'
updated: '2016-09-27 15:26:25'
tags: ['null', NaN, object, web, js]
permalink: /articles/2016/09/27/1474961184955.html
---
<p>1、类型及类型转换</p>
<p>（1）false,true</p>
<pre class="brush: java">0==false //true
0+false //0
0+true //1</pre>
<p>（2）null,undefined</p>
<pre class="brush: js">null == undefined//true</pre>
<p>&nbsp; (3)NaN</p>
<pre class="brush: js">NaN == NaN //false</pre>
<p>&nbsp;</p>
<p>&nbsp;2、作用域</p>
<p>js是函数作用域的，非块作用域</p>
<p>&nbsp;</p>
<p>3、初始化顺序</p>
<div class="page" title="Page 50">
<div class="section">
<div class="layoutArea">
<div class="column">
<p><span>1.&nbsp;</span><span>函数参数</span><span>(</span><span>若未传 ,初始化该参数值为</span><span>undefined</span><span>)<br /> </span><span>2. </span><span>函数声明</span><span>(</span><span>若发 命名冲突,会覆盖</span><span>)<br /> </span><span>3.&nbsp;</span><span>变量声明</span><span>(</span><span>初始化变量值为</span><span>undefined</span><span>,若发 命名冲突,会忽略。</span><span>)&nbsp;</span></p>
<pre class="brush: js"> 
alert(x);   // function                
var x = 10; 
 alert(x);  // 10         
 x = 20; 
function x() {}  
alert(x);   // 20 
if (true) {   
   var a = 1;  
} else {   
   var b = true; 
 } 
alert(a);   // 1  
 alert(b);   // undefined</pre>
<p><span>&nbsp;</span></p>
</div>
</div>
</div>
</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp; &nbsp; &nbsp;</p>