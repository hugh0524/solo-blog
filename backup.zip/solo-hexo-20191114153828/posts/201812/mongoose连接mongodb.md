title: mongoose 连接mongodb
date: '2018-12-03 14:46:57'
updated: '2018-12-03 14:46:57'
tags: [node, js, mongo, mongoose]
permalink: /articles/2018/12/03/1543818131615.html
---
<h1>1. mongodb 链接地址格式</h1>
<blockquote>
<pre class="prettyprint prettyprinted"><span class="pln">mongodb</span><span class="pun">:</span><span class="com">//[username:password@]host1[:port1][,host2[:port2],...[,hostN[:portN]]][/[database][?options]]</span></pre>
</blockquote>
<div><span class="com">mongodb://&nbsp; &nbsp;表示协议相关</span></div>
<div>host:port&nbsp; &nbsp;需要提供至少一组 （port 默认为27017）</div>
<div><span class="com">database&nbsp; &nbsp;对应的数据库名称</span></div>
<div><span class="com">options&nbsp; 链接参数</span></div>
<div>
<table class="reference table" border="1">
<tbody>
<tr>
<td>replicaSet=name</td>
<td>验证replica set的名称。 Impliesconnect=replicaSet.</td>
</tr>
<tr>
<td>slaveOk=true|false</td>
<td>
<ul>
<li>true:在connect=direct模式下，驱动会连接第一台机器，即使这台服务器不是主。在connect=replicaSet模式下，驱动会发送所有的写请求到主并且把读取操作分布在其他从服务器。</li>
<li>false: 在 connect=direct模式下，驱动会自动找寻主服务器. 在connect=replicaSet 模式下，驱动仅仅连接主服务器，并且所有的读写命令都连接到主服务器。</li>
</ul>
</td>
</tr>
<tr>
<td>safe=true|false</td>
<td>
<ul>
<li>true: 在执行更新操作之后，驱动都会发送getLastError命令来确保更新成功。(还要参考 wtimeoutMS).</li>
</ul>
false: 在每次更新之后，驱动不会发送getLastError来确保更新成功。</td>
</tr>
<tr>
<td>w=n</td>
<td>驱动添加 { w : n } 到getLastError命令. 应用于safe=true。</td>
</tr>
<tr>
<td>wtimeoutMS=ms</td>
<td>驱动添加 { wtimeout : ms } 到 getlasterror 命令. 应用于 safe=true.</td>
</tr>
<tr>
<td>fsync=true|false</td>
<td>
<ul>
<li>true: 驱动添加 { fsync : true } 到 getlasterror 命令.应用于 safe=true.</li>
<li>false: 驱动不会添加到getLastError命令中。</li>
</ul>
</td>
</tr>
<tr>
<td>journal=true|false</td>
<td>如果设置为 true, 同步到 journal (在提交到数据库前写入到实体中). 应用于 safe=true</td>
</tr>
<tr>
<td>connectTimeoutMS=ms</td>
<td>可以打开连接的时间。</td>
</tr>
<tr>
<td>socketTimeoutMS=ms</td>
<td>发送和接受sockets的时间。</td>
</tr>
</tbody>
</table>
</div>
<p>&nbsp;</p>
<h1>2. mongoose 连接replicaSet</h1>
<p>基于1的链接格式</p>
<p>url为 mongodb://127.0.0.1:27016,127.0.0.1:27015,127.0.0.1:27014/test?w=majority&amp;replicaSet=[your replicaset's name]</p>
<p>链接操作：</p>
<pre class="brush: js">mongoose.connect(url)
var db = mongoose.connection;
db.on('error', function(e) {
    logger.error("connect fail" )
});
db.once('open', function() {
    // we're connected!
logger.info('mongodb load success...');
    if(typeof callback === 'function'){
        callback.call(db)
    }
});</pre>
<pre><span><br /><br /></span></pre>