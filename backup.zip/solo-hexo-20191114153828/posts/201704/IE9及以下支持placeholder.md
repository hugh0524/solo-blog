title: IE9及以下支持placeholder
date: '2017-04-23 17:01:04'
updated: '2017-04-23 17:01:04'
tags: [placeholder, jquery, 前端, web]
permalink: /articles/2017/04/23/1492938064454.html
---
<h2>1、插件下载</h2>
<p><a href="https://github.com/mathiasbynens/jquery-placeholder" target="_blank">下载地址</a></p>
<p>&nbsp;</p>
<h2>2、使用</h2>
<p>在页面上引入插件</p>
<pre class="brush: xml">&lt;!--[if lte IE 9]&gt;&lt;script src="${ctx}/static/fst/web/js/jquery.placeholder.min.js"&gt;&lt;/script&gt;&lt;![endif]--&gt;</pre>
<p>调用插件</p>
<pre class="brush: js">&lt;!--[if lte IE 9]&gt;
&lt;script type="text/javascript"&gt;
$(function(){
	$('input').placeholder();
})
&lt;/script&gt;</pre>
<h2>&nbsp;</h2>
<p>&nbsp;</p>