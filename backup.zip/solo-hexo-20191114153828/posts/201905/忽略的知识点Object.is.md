title: 忽略的知识点 - Object.is
date: '2019-05-14 10:06:43'
updated: '2019-05-14 10:06:43'
tags: [js, js_base, 前端, web]
permalink: /articles/2019/05/14/1557799603731.html
---
<p>Object.is 是用于判断两个值是否是相同的值</p>
<ul>
<li>两个值都是&nbsp;<code>undefined</code></li>
<li>两个值都是&nbsp;<code>null</code></li>
<li>两个值都是&nbsp;<code>true</code>&nbsp;或者都是&nbsp;<code>false</code></li>
<li>两个值是由相同个数的字符按照相同的顺序组成的字符串</li>
<li>两个值指向同一个对象</li>
<li>两个值都是数字并且
<ul>
<li>都是正零&nbsp;<code>+0</code></li>
<li>都是负零&nbsp;<code>-0</code></li>
<li>都是&nbsp;<code>NaN</code></li>
<li>都是除零和&nbsp;<code>NaN</code>&nbsp;外的其它同一个数字</li>
</ul>
</li>
</ul>
<p>这种相等性判断逻辑和传统的&nbsp;<code>==</code>&nbsp;运算不同，<code>==</code>&nbsp;运算符会对它两边的操作数做<span style="color: #ff0000;">隐式类型转</span>换（如果它们类型不同），然后才进行相等性比较，（所以才会有类似&nbsp;<code>"" == false</code>&nbsp;等于&nbsp;<code>true</code>的现象），但&nbsp;<code>Object.is</code>&nbsp;<span style="color: #ff0000;">不会</span>做这种类型转换。</p>
<p>这与&nbsp;<code>===</code>&nbsp;运算符的判定方式也不一样。<code>===</code>&nbsp;运算符（和<code>==</code>&nbsp;运算符）将数字值&nbsp;<code>-0</code>&nbsp;和&nbsp;<code>+0</code>&nbsp;视为相等，并认为<span style="color: #ff0000;">&nbsp;<code>Number.NaN</code>&nbsp;不等于&nbsp;<code>NaN</code></span>。</p>
<p>&nbsp;</p>
<p><a href="http://tools.uproject.cn/tools/showDemo?id=55" target="_blank">Demo</a></p>
<p>关键点： 如何比较左右操作数都是NaN的情况， 可以使用&nbsp; <span style="color: #ff0000;">Object.js(NaN,NaN) === true</span></p>