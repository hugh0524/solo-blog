title: mysql索引学习一
date: '2016-03-11 20:10:35'
updated: '2016-03-11 20:13:15'
tags: [DB, 索引, 数据库优化, mysql]
permalink: /articles/2016/03/11/1457698217296.html
---
<p>Mysql索引有很多种，应用中主要使用B-tree索引，数据结构就是B+-tree<br />Mysql的索引可以在创建表的时候指定，也可以先创建表，然后再进行增删。<br />Mysql常见的索引包括下面几类：</p>
<ul>
<li>普通索引：最基本的索引</li>
<li>唯一索引：索引列的值必须是唯一的</li>
<li>主键索引：一个表只能有一个主键</li>
<li>组合索引：包含多列</li>
</ul>
<p>索引存储的值按索引列中的顺序排列。可以利用B-Tree索引进行全关键字、关键字范围和关键字前缀查询，当然，如果想使用索引，你必须保证按索引的最左边前缀来进行查询。<br /> (1)匹配全值：对索引中的所有列都指定具体的值。</p>
<p>(2)匹配最左前缀：你可以利用索引查找last name为Allen的人，仅仅使用索引中的第1列</p>
<p>(3)匹配列前缀：你可以利用索引查找last name以J开始的人，这仅仅使用索引中的第1列。</p>
<p>(4)匹配值的范围查询：可以利用索引查找last name在Allen和Barrymore之间的人，仅仅使用索引中第1列。</p>
<p>(5)匹配部分精确而其它部分进行范围匹配：可以利用索引查找last name为Allen，而first name以字母K开始的人。</p>
<p>(6)仅对索引进行查询：如果查询的列都位于索引中，则不需要读取元组的值。</p>
<p>&nbsp;</p>
<div>查询优化神器 &ndash; explain命令</div>
<div>
<ul>
<li>输入 explain select * from people\G后，出现一张表，各行的意思如下：</li>
<li>table－显示此行数据属于哪张表；</li>
<li>type－重要的一列，显示使用了何种连接，从好到差依次为const、eq_ref、ref、range、index、all；</li>
<li>possible_keys－可以应用在这张表中的索引，如果为null，则表示没有可用索引；</li>
<li>key－实际使用的索引，如为null，表示没有用到索引；</li>
<li>key_len－索引的长度，在不损失精确度的情况下，越短越好；</li>
<li>ref－显示索引的哪一列被使用了，如果可能的话，是个常数；</li>
<li>rows－返回请求数据的行数；extra－关于mysql如何解析查询的额外信息，下面会详细说明。</li>
<li>
<div>lextra行的描述：distinct－mysql找到了域行联合匹配的行，就不再搜索了；<br /> not exists－mysql优化了left join，一旦找到了匹配left join的行，就不再搜索了；<br /> range checked for each－没找到理想的索引，一次对于从前面表中来的每一个行组合；<br /> record(index map: #)－检查使用哪个索引，并用它从表中返回行，这是使用索引最慢的一种；<br /> using filesort－看到这个就需要优化查询了，mysql需要额外的步骤来发现如何对返回的行排序。他根据连接类型以及存储排序键值和匹配条件的全部行的行指针来排序全部行。<br /> using index－列数据是从单单使用了索引中的信息而没有读取实际行的表返回的，这发生在对表的全部的请求列都是同一个索引时；</div>
</li>
</ul>
</div>