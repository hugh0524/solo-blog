title: JAVA生成二维码
date: '2016-03-24 16:38:00'
updated: '2016-03-24 17:11:34'
tags: [qrcode, 二维码, java]
permalink: /articles/2016/03/24/1458806733096.html
---
<p>-----<span style="font-size: medium;"><a target="_blank" href="http://tools.uproject.cn/tools/toQCode"><strong>在线使用</strong></a></span></p>
<p>1、使用jar:QRCode.jar【<a href="http://hugh-10023362.file.myqcloud.com/static/jar/QRCode.jar">下载</a>】</p>
<p>2、代码</p>
<pre class="brush: java"> public static BufferedImage qRCode(String content, String imgType, int size,char correct) {    
        BufferedImage bufImg = null;    
        try {    
            Qrcode qrcodeHandler = new Qrcode();    
            // 设置二维码排错率，可选L(7%)、M(15%)、Q(25%)、H(30%)，排错率越高可存储的信息越少，但对二维码清晰度的要求越小    
            qrcodeHandler.setQrcodeErrorCorrect(correct);    
            qrcodeHandler.setQrcodeEncodeMode('B');    
            // 设置设置二维码尺寸，取值范围1-40，值越大尺寸越大，可存储的信息越大    
            qrcodeHandler.setQrcodeVersion(size);    
            // 获得内容的字节数组，设置编码格式    
            byte[] contentBytes = content.getBytes("utf-8");    
            // 图片尺寸    
            int imgSize = 67 + 12 * (size - 1);    
            bufImg = new BufferedImage(imgSize, imgSize, BufferedImage.TYPE_INT_RGB);    
            Graphics2D gs = bufImg.createGraphics();    
            // 设置背景颜色    
            gs.setBackground(Color.WHITE);    
            gs.clearRect(0, 0, imgSize, imgSize);    
    
            // 设定图像颜色&gt; BLACK    
            gs.setColor(Color.BLACK);    
            // 设置偏移量，不设置可能导致解析出错    
            int pixoff = 2;    
            // 输出内容&gt; 二维码    
            if (contentBytes.length &gt; 0 &amp;&amp; contentBytes.length &lt; 800) {    
                boolean[][] codeOut = qrcodeHandler.calQrcode(contentBytes);    
                for (int i = 0; i &lt; codeOut.length; i++) {    
                    for (int j = 0; j &lt; codeOut.length; j++) {    
                        if (codeOut[j][i]) {    
                            gs.fillRect(j * 3 + pixoff, i * 3 + pixoff, 3, 3);    
                        }    
                    }    
                }    
            } else {    
                throw new Exception("QRCode content bytes length = " + contentBytes.length + " not in [0, 800].");    
            }    
            gs.dispose();    
            bufImg.flush();    
        } catch (Exception e) {    
            e.printStackTrace();    
        }    
        return bufImg;    
    }  </pre>
<p>3、页面输出</p>
<pre class="brush: java">public void generatorQCode(){
        
        String cont = getPara("cont");
        if(cont != null &amp;&amp; !cont.equals("")){
            cont = cont.trim();
            String correct = getPara("correct");
            char correctChar = 'M';
            if(correct != null &amp;&amp; !correct.equals("")){
                correctChar = correct.charAt(0);
            }
            BufferedImage bi = QRCode.qRCodeCommon(cont, "png", 20, correctChar);
            ServletOutputStream sos = null;
            try {
                getResponse().setContentType("image/png");
                sos = getResponse().getOutputStream();
                 ImageIO.write(bi, "png", sos);
                 sos.flush();
                 sos.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } finally{
                if(sos != null){
                    try {
                        sos.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
          
        }else{
            
        }
        
    }</pre>