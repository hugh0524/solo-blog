title: 【转】Nginx+Tomcat+Redis实现负载均衡、资源分离、session共享
date: '2016-04-08 20:07:04'
updated: '2017-03-06 14:51:29'
tags: [java, tomcat, ngnix, radis, 负载均衡, 资源分离, session共享]
permalink: /articles/2016/04/08/1460117223687.html
---
<p><strong>1</strong><strong>、Nginx实现多Tomcat负载均衡</strong></p>
<p>Tomcat服务</p>
<p>192.168.1.177:8001</p>
<p>192.168.1.177:8002</p>
<p>192.168.1.177:8003</p>
<p><span style="text-decoration: underline;">Nginx</span><span style="text-decoration: underline;">配置</span></p>
<pre class="brush: xml">upstream mytomcats { 

server 192.168.1.177:8001; 

server 192.168.1.177:8002; 

server 192.168.1.177:8003; 

}

server { 

listen 80; 

server_name www.iu14.com;

location ~* \.(jpg|gif|png|swf|flv|wma|wmv|asf|mp3|mmf|zip|rar)$ { 

        root /web/www/html/; 

} 

location / { 

        proxy_pass http://mytomcats; 

        proxy_redirect off; 

        proxy_set_header Host $host; 

        proxy_set_header X-Real-IP $remote_addr; 

        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for; 

        client_max_body_size 10m; 

        client_body_buffer_size 128k; 

        proxy_connect_timeout 90; 

        proxy_send_timeout 90; 

        proxy_read_timeout 90; 

        proxy_buffer_size 4k; 

        proxy_buffers 4 32k; 

        proxy_busy_buffers_size 64k; 

        proxy_temp_file_write_size 64k;

}

}</pre>
<p>upstream指定负载均衡组，指定其Tomcat成员</p>
<p>location ~* \.(jpg|gif|&hellip;&hellip;实现了静态资源分离。ps：在location指令使用正则表达式后再用alias指令，Nginx是不支持的。</p>
<p><strong>2</strong><strong>、Nginx实现静态资源分离</strong></p>
<p>Tomcat服务</p>
<p>192.168.1.177:8000</p>
<p><span style="text-decoration: underline;">Nginx</span><span style="text-decoration: underline;">配置</span></p>
<pre class="brush: xml">server { 

listen 80; 

server_name www.iu14.com; 

root /web/www/html;

location /img/ { 

alias /web/www/html/img/; 

}

location ~ (\.jsp)|(\.do)$ { 

proxy_pass http://192.168.1.177:8000; 

proxy_redirect off; 

        proxy_set_header Host $host; 

        proxy_set_header X-Real-IP $remote_addr; 

        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for; 

        client_max_body_size 10m; 

        client_body_buffer_size 128k; 

        proxy_connect_timeout 90; 

proxy_send_timeout 90; 

proxy_read_timeout 90; 

        proxy_buffer_size 4k; 

        proxy_buffers 4 32k; 

        proxy_busy_buffers_size 64k; 

        proxy_temp_file_write_size 64k; 

}  

}</pre>
<p>第一个location指令将/web/www/html/img/目录下的静态文件交给Nginx来完成。最后一个location指令将所有以.jsp、.do结尾的文件都交给Tomcat服务器的8080端口来处理。</p>
<p><strong>3</strong><strong>、Nginx+Tomcat+Redis实现session共享</strong></p>
<p>Redis服务</p>
<p>192.168.1.178:6379</p>
<p>Tomcat服务</p>
<p>192.168.1.177:8001</p>
<p>192.168.1.177:8002</p>
<p>192.168.1.177:8003</p>
<p>Nginx服务</p>
<p>192.168.1.179</p>
<p>配置Tomcat让其session保存到redis上，在context.xml配置(Value标签一定要在Manager标签前面)[<a href="https://pan.baidu.com/s/1jI1Dzka" target="_blank">依赖包下载</a>，依赖包放到tomcat lib下]：</p>
<p>&nbsp;</p>
<pre class="brush: xml">&lt;Valve className="com.orangefunction.tomcat.redissessions.RedisSessionHandlerValve" /&gt; 
&lt;Manager className="com.orangefunction.tomcat.redissessions.RedisSessionManager" 
      host="192.168.1.178" port="6379" database="0" maxInactiveInterval="60"/&gt;</pre>
<p>&nbsp;</p>
<p>配置Nginx</p>
<pre class="brush: xml">upstream mytomcats { 

server 192.168.1.177:8001; 

server 192.168.1.177:8002; 

server 192.168.1.177:8003; 

}

log_format www_iu14_com '$remote_addr - $remote_user [$time_local] $request ' '"$status" $body_bytes_sent "$http_referer"'  '"$http_user_agent" "$http_x_forwarded_for"'; 

server {

listen  80; 

server_name www.iu14.com;  

    location / { 

        proxy_pass http:// mytomcats; 

        proxy_set_header Host $host; 

        proxy_set_header X-Real-IP $remote_addr; 

        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for; 

} 

access_log /usr/tmp/logs/redis.iu14.log www_iu14_com;  

} </pre>
<p>依次启动Redis、Tomcat、Nginx，访问Nginx</p>
<p>&nbsp;</p>