title: url中参数获取
date: '2017-05-20 20:04:25'
updated: '2017-05-20 20:04:25'
tags: [js, 前端, web]
permalink: /articles/2017/05/20/1495281865673.html
---
<pre class="brush: js">function getQueryString(name) {  
        var reg = new RegExp("(^|&amp;)" + name + "=([^&amp;]*)(&amp;|$)", "i");  
        var r = window.location.search.substr(1).match(reg);  
        if (r != null) return unescape(r[2]);  
        return null;  
    }  </pre>