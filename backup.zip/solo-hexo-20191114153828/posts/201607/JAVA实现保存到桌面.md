title: JAVA实现保存到桌面
date: '2016-07-22 23:56:47'
updated: '2016-07-22 23:56:47'
tags: [保存到桌面, java]
permalink: /articles/2016/07/22/1469203007374.html
---
<h1>1、了解.url文件内容</h1>
<p>[DEFAULT]<br />BASEURL=<br /><br />[InternetShortcut]<br />URL=<br />WorkingDirectory=<br />ShowCommand=<br />IconIndex=<br />IconFile=<br />Modified=<br />HotKey=</p>
<p>&nbsp;</p>
<h2>2、java实现</h2>
<pre class="brush: java">String rid = req.getParameter("rid");
	String idIndex = rid.substring(1,2);
	String contIndex = rid.substring(2,3);
	String roomId = rid.substring(2+Integer.valueOf(idIndex),2+Integer.valueOf(idIndex)+Integer.valueOf(contIndex));
	Map rinfo = vs.getRoomInfo(roomId);
	String shortInfo =  "[InternetShortcut]\n";
	shortInfo+="URL="+req.getScheme()+"://"+req.getServerName()+":"+req.getServerPort()+req.getContextPath()+"/servlet/VadioAction?ac=iroom&amp;rid="+rid+"\n";
	shortInfo+="IconIndex=1\n IconFile=http://www.rainheng.com/"+rinfo.get("img")+" \n";
	shortInfo+=" IDList=[{000214A0-0000-0000-C000-000000000046}]\n Prop3=19,2";
	resp.setHeader("Content-type", "application/octet-stream");
	resp.setHeader("Content-Disposition", "attachment; filename="+URLEncoder.encode((String)rinfo.get("cname"),"UTF-8")+".url;");
	resp.getOutputStream().write(shortInfo.getBytes());</pre>
<p>shortInfo的拼装内容为 构建.url内的内容</p>
<pre class="brush: java">URLEncoder.encode((String)rinfo.get("cname"),"UTF-8") 解决中文乱码</pre>
<pre class="brush: java">IconIndex 和 IconFile指定了 图标</pre>