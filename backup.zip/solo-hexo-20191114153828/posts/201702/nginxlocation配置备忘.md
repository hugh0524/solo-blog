title: nginx location配置备忘
date: '2017-02-21 18:01:06'
updated: '2017-02-21 18:01:06'
tags: [location, linux, nginx]
permalink: /articles/2017/02/21/1487671266413.html
---
<h1 id="1-location正则写法">1. location正则写法</h1>
<p>一个示例：</p>
<pre class="brush: xml">location = / {
# 精确匹配 / ，主机名后面不能带任何字符串
[ configuration A ]
}
 
location / {
# 因为所有的地址都以 / 开头，所以这条规则将匹配到所有请求
# 但是正则和最长字符串会优先匹配
[ configuration B ]
}
 
location /documents/ {
# 匹配任何以 /documents/ 开头的地址，匹配符合以后，还要继续往下搜索
# 只有后面的正则表达式没有匹配到时，这一条才会采用这一条
[ configuration C ]
}
 
location ~ /documents/Abc {
# 匹配任何以 /documents/Abc 开头的地址，匹配符合以后，还要继续往下搜索
# 只有后面的正则表达式没有匹配到时，这一条才会采用这一条
[ configuration CC ]
}
 
location ^~ /images/ {
# 匹配任何以 /images/ 开头的地址，匹配符合以后，停止往下搜索正则，采用这一条。
[ configuration D ]
}
 
location ~* \.(gif|jpg|jpeg)$ {
# 匹配所有以 gif,jpg或jpeg 结尾的请求
# 然而，所有请求 /images/ 下的图片会被 config D 处理，因为 ^~ 到达不了这一条正则
[ configuration E ]
}
 
location /images/ {
# 字符匹配到 /images/，继续往下，会发现 ^~ 存在
[ configuration F ]
}
 
location /images/abc {
# 最长字符匹配到 /images/abc，继续往下，会发现 ^~ 存在
# F与G的放置顺序是没有关系的
[ configuration G ]
}
 
location ~ /images/abc/ {
# 只有去掉 config D 才有效：先最长匹配 config G 开头的地址，继续往下搜索，匹配到这一条正则，采用
[ configuration H ]
}
 
location ~* /js/.*/\.js</pre>
<p>&nbsp;</p>
<p>&nbsp;</p>
<ul>
<li><br />顺序 no优先级：已<code>=</code>开头表示精确匹配<br />如 A 中只匹配根目录结尾的请求，后面不能带任何字符串。</li>
<li><code>^~</code>&nbsp;开头表示uri以某个常规字符串开头，不是正则匹配</li>
<li>~ 开头表示区分大小写的正则匹配;</li>
<li>~* 开头表示不区分大小写的正则匹配</li>
<li>/ 通用匹配, 如果没有其它匹配,任何请求都会匹配到</li>
</ul>
<p>(location =) &gt; (location 完整路径) &gt; (location ^~ 路径) &gt; (location ~,~* 正则顺序) &gt; (location 部分起始路径) &gt; (/)</p>
<p>上面的匹配结果<br />按照上面的location写法，以下的匹配示例成立：</p>
<ul>
<li>/ -&gt; config A<br />精确完全匹配，即使/index.html也匹配不了</li>
<li>/downloads/download.html -&gt; config B<br />匹配B以后，往下没有任何匹配，采用B</li>
<li>/images/1.gif -&gt; configuration D<br />匹配到F，往下匹配到D，停止往下</li>
<li>/images/abc/def -&gt; config D<br />最长匹配到G，往下匹配D，停止往下<br />你可以看到 任何以/images/开头的都会匹配到D并停止，FG写在这里是没有任何意义的，H是永远轮不到的，这里只是为了说明匹配顺序</li>
<li>/documents/document.html -&gt; config C<br />匹配到C，往下没有任何匹配，采用C</li>
<li>/documents/1.jpg -&gt; configuration E<br />匹配到C，往下正则匹配到E</li>
<li>/documents/Abc.jpg -&gt; config CC<br />最长匹配到C，往下正则顺序匹配到CC，不会往下到E</li>
</ul>