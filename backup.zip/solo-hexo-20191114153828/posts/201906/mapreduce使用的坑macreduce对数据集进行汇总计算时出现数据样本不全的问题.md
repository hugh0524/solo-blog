title: mapreduce使用的坑 - mac reduce对数据集进行汇总计算时，出现数据样本不全的问题
date: '2019-06-13 18:34:21'
updated: '2019-06-21 09:57:19'
tags: [map, reduce, js, node, mongo, 前端, web, mongodb]
permalink: /articles/2019/06/13/1560396099637.html
---
<h2>1. mapreduce</h2>
<p>复习下map reduce， 经典图例如下</p>
<p><a href="http://tools.uproject.cn/upload/article/1560421213678.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/1560421213678.jpg" alt="" width="500" height="282" /></a></p>
<p>&nbsp;</p>
<h2>2.&nbsp; 问题案例</h2>
<p>需要对性能数据分数段进行统计平均耗时，使用mapreduce如下</p>
<pre class="prettyprint"> async getPerformanceAvgByHour(query) {
        let model = this.trackingTmplDao.getModel()
        query.trackingtype = "performance";
        var o = {}
        o.map = function () {
            var d = new Date(this.localts)
            d.setMinutes(0)
            d.setMilliseconds(0)
            d.setSeconds(0)
            emit(d.getTime(), this.parameters)
        };
        o.reduce = function (k, vals) {
            var len = vals.length;
            function financial(x) {
                return Number.parseFloat(x).toFixed(2);
            }
            var sum = vals.reduce((cur,item) =&gt; {
                return {dns: (item.dns &gt;&gt; 0) + cur.dns,
                    tcp:(item.tcp&gt;&gt; 0) + cur.tcp,
                    ssl:(item.ssl&gt;&gt; 0) + cur.ssl,
                    ttfb:(item.ttfb&gt;&gt; 0) + cur.ttfb,
                    trans:(item.trans&gt;&gt; 0) + cur.trans,
                    dom:(item.dom&gt;&gt; 0) + cur.dom,
                    res:(item.res&gt;&gt; 0) + cur.res,
                    firstbyte:(item.firstbyte&gt;&gt; 0) + cur.firstbyte,
                    fpt:(item.firstbyte&gt;&gt; 0) + cur.firstbyte,
                    tti:(item.tti&gt;&gt; 0) + cur.tti,
                    ready:(item.ready&gt;&gt; 0) + cur.ready,
                    load:(item.load&gt;&gt; 0) + cur.load}
            }, {dns: 0, tcp:0, ssl:0, ttfb:0, trans:0, dom:0, res:0,firstbyte:0,fpt:0,tti:0,ready:0, load:0})
            // return sum
             var sumTotal = {total: len, dns: financial(sum.dns/len), tcp:financial(sum.tcp/len), ssl:financial(sum.ssl/len), ttfb:financial(sum.ttfb/len), trans:financial(sum.trans/len), dom:financial(sum.dom/len),
                res:financial(sum.res/len),firstbyte:financial(sum.firstbyte/len),fpt:financial(sum.fpt/len),tti:financial(sum.tti/len),ready:financial(sum.ready/len), load:financial(sum.load/len)}
            var sumTotal = sum
            sumTotal.total = len
            return sumTotal
        };

        o.out = { replace: 'sumEachHour_performance_ForResults' }
        o.verbose = true;
        o.query = query
        

        let res = await model.mapReduce(o)
        let r = await res.model.find()
        return r
    }
</pre>
<p>&nbsp;</p>
<p>总样本数：433， 实际计算结果集只有73条</p>
<p>&nbsp;</p>
<h2>3. 原因</h2>
<blockquote>
<ul class="simple">
<li>MongoDB can invoke the&nbsp;<code class="docutils literal">reduce</code>&nbsp;function more than once for the same key. In this case, the previous output from the&nbsp;<code class="docutils literal">reduce</code>&nbsp;function for that key will become one of the input values to the next&nbsp;<code class="docutils literal">reduce</code>function invocation for that key.</li>
</ul>
</blockquote>
<p>&nbsp;</p>
<p>reduce fun会被分批次调用多次，如果在方法内进行汇总， 后面调用的得到的结果会覆盖前面的</p>
<h2>4. 解决方案</h2>
<p>利用scope(在map\reduce\finalize方法作用域中可访问)暂存数据</p>
<p>利用finalize在最终一步，对scope存储的数据进行汇总计算</p>
<p>&nbsp;</p>
<pre class="prettyprint">async getPerformanceAvgByHour(query) {
        let model = this.trackingTmplDao.getModel()
        query.trackingtype = "performance";
        var o = {}
        o.map = function () {
            var d = new Date(this.localts)
            d.setMinutes(0)
            d.setMilliseconds(0)
            d.setSeconds(0)
            emit(d.getTime(), this.parameters)
        };
        o.reduce = function (k, vals) {
            var len = vals.length;
            function financial(x) {
                return Number.parseFloat(x).toFixed(2);
            }
            var sum = vals.reduce((cur,item) =&gt; {
                return {dns: (item.dns &gt;&gt; 0) + cur.dns,
                    tcp:(item.tcp&gt;&gt; 0) + cur.tcp,
                    ssl:(item.ssl&gt;&gt; 0) + cur.ssl,
                    ttfb:(item.ttfb&gt;&gt; 0) + cur.ttfb,
                    trans:(item.trans&gt;&gt; 0) + cur.trans,
                    dom:(item.dom&gt;&gt; 0) + cur.dom,
                    res:(item.res&gt;&gt; 0) + cur.res,
                    firstbyte:(item.firstbyte&gt;&gt; 0) + cur.firstbyte,
                    fpt:(item.firstbyte&gt;&gt; 0) + cur.firstbyte,
                    tti:(item.tti&gt;&gt; 0) + cur.tti,
                    ready:(item.ready&gt;&gt; 0) + cur.ready,
                    load:(item.load&gt;&gt; 0) + cur.load}
            }, {dns: 0, tcp:0, ssl:0, ttfb:0, trans:0, dom:0, res:0,firstbyte:0,fpt:0,tti:0,ready:0, load:0})
          
            var sumTotal = sum
            sumTotal.total = len

            if(result[k]) {
                result[k].push(sumTotal)
            }else {
                result[k] = [sumTotal]
            }

            return sumTotal
        };

        o.out = { replace: 'sumEachHour_performance_ForResults' }
        o.verbose = true;
        o.query = query
        o.scope = {result: {}}
        o.finalize = function(key, rval) {
            function financial(x) {
                return Number.parseFloat(x).toFixed(2);
            }
            var sum = result[key].reduce((cur,item) =&gt; {
                return {dns: (item.dns &gt;&gt; 0) + cur.dns,
                    tcp:(item.tcp&gt;&gt; 0) + cur.tcp,
                    ssl:(item.ssl&gt;&gt; 0) + cur.ssl,
                    ttfb:(item.ttfb&gt;&gt; 0) + cur.ttfb,
                    trans:(item.trans&gt;&gt; 0) + cur.trans,
                    dom:(item.dom&gt;&gt; 0) + cur.dom,
                    res:(item.res&gt;&gt; 0) + cur.res,
                    firstbyte:(item.firstbyte&gt;&gt; 0) + cur.firstbyte,
                    fpt:(item.firstbyte&gt;&gt; 0) + cur.firstbyte,
                    tti:(item.tti&gt;&gt; 0) + cur.tti,
                    ready:(item.ready&gt;&gt; 0) + cur.ready,
                    load:(item.load&gt;&gt; 0) + cur.load,
                    total: item.total + cur.total
                }
            }, {total:0, dns: 0, tcp:0, ssl:0, ttfb:0, trans:0, dom:0, res:0,firstbyte:0,fpt:0,tti:0,ready:0, load:0})
            var len = sum.total;
            var sumTotal = {total: len, dns: financial(sum.dns/len), tcp:financial(sum.tcp/len), ssl:financial(sum.ssl/len), ttfb:financial(sum.ttfb/len), trans:financial(sum.trans/len), dom:financial(sum.dom/len),
                   res:financial(sum.res/len),firstbyte:financial(sum.firstbyte/len),fpt:financial(sum.fpt/len),tti:financial(sum.tti/len),ready:financial(sum.ready/len), load:financial(sum.load/len)}

            return sumTotal
        }

        let res = await model.mapReduce(o)
        let r = await res.model.find()
        logger.info(JSON.stringify(r))
        return r
    }</pre>
<p>&nbsp;</p>
<p>参考：&nbsp;<a href="https://docs.mongodb.com/manual/reference/command/mapReduce/#mapreduce-reduce-cmd">https://docs.mongodb.com/manual/reference/command/mapReduce/#mapreduce-reduce-cmd</a></p>
<p>&nbsp;</p>