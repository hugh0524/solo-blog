title: 如何关闭password输入框的自动填写
date: '2019-06-04 11:08:09'
updated: '2019-06-04 11:08:09'
tags: [ko, autoComplete, web, 前端, js, password]
permalink: /articles/2019/06/04/1559617671724.html
---
<h2>1. 场景</h2>
<p>在<span style="color: #ff0000;">登录</span>时， 我们需要自动填写， 可以提高用户体验， 但是有些常见，如<span style="color: #ff0000;">修改密码、更改绑定手机</span>等功能，就不能自动填写， 因为我们需要保证账号的<span style="color: #ff0000;">安全性</span></p>
<p><span style="color: #ff0000;">&nbsp;</span></p>
<h2><span style="color: #000000;">2. 如何取消自动填写</span></h2>
<p><span style="color: #000000;">浏览器根据输入框类型 和 域名确认是否有保存的账号密码</span></p>
<p><span style="color: #000000;">基于此，我们可以使用以下方式操作</span></p>
<p><span style="color: #000000;">a. 使用</span>autocomplete =<span>"new-password"</span></p>
<blockquote>
<p>A new password. When creating a new account or changing passwords, this should be used for an "Enter your new password" or "Confirm new password" field, as opposed to a general "Enter your current password" field that might be present. This may be used by the browser both to avoid accidentally filling in an existing password and to offer assistance in creating a secure password (see also&nbsp;<a href="https://developer.mozilla.org/en-US/docs/Web/Security/Securing_your_site/Turning_off_form_autocompletion#Preventing_autofilling_with_autocompletenew-password">Preventing autofilling with autocomplete="new-password"</a>).【<a href="https://developer.mozilla.org/en-US/docs/Web/HTML/Attributes/autocomplete" target="_blank">详情</a>】</p>
</blockquote>
<p>b. 以上方式不是所有浏览器都支持的， chrome显示支持，但是实测并没有生效，可以结合下面的代码</p>
<pre class="prettyprint">&lt;input type="password" style="display: none"&gt;</pre>
<p>&nbsp;</p>
<p>完整按理如下（基于ko）：</p>
<pre class="prettyprint">&lt;template&gt;
  &lt;div data-bind="css: params.containerCss"&gt;
    &lt;!-- ko if: params.closeAutoComplete--&gt;
      &lt;input type="password" style="display: none"&gt;
    &lt;!-- /ko --&gt;
    &lt;input type="password" autocomplete="off"
           data-bind='attr:{placeHolder: i18n.prop(params.placeHolder), name: params.name, autocomplete: needAutoComplete}, value: value, css: {"has-error": notValid()}'/&gt;
    &lt;!-- ko if: !params.hiddenError &amp;&amp; notValid() --&gt;
    &lt;p class="error-msg" data-bind="html: i18n.prop(notValid())"&gt;&lt;/p&gt;
    &lt;!-- /ko --&gt;
  &lt;/div&gt;
&lt;/template&gt;

&lt;script&gt;

  define(["jquery", "knockout", "ko_validation", "state", "BaseInput"], function ($, ko, v, state, BaseInput) {

    /**
     * pop password输入框
     */
    class PopPassword extends BaseInput {
      constructor(params, components) {
        super(params, components, "input");
        params = params || {};
        this.i18n = state.page().i18n;
        this.params = params;
        this.needAutoComplete = !params.closeAutoComplete ? "on" : "new-password"
      }
    }

    return {
      viewModel: PopPassword
    }
  })

&lt;/script&gt;</pre>