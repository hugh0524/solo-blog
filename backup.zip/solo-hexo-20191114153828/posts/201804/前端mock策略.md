title: 前端mock策略
date: '2018-04-15 12:27:40'
updated: '2018-04-15 14:12:04'
tags: [前端, web, serviceWorker, mock Server, yapi, mock]
permalink: /articles/2018/04/15/1523766437851.html
---
<h2>1、简单mock</h2>
<p>如果只是数据的简单mock， 建议包装ajax或者fetch，在请求之前通过读取mock数据，来返回mock结果</p>
<p>eg:根据请求参数，获取mock数据</p>
<pre class="brush: js"> var getMockByUrl = function (mock, url, pdata) {
      if(!url){
        return null;
      }
      // url中解析出queryString部分
      var urlArr = url.split("?"),path="",queryStrings=[], queryMockType="";
      if(urlArr.length&gt;=1){
        path = urlArr[0];
        queryStrings = urlArr[1]?urlArr[1]:"";
        if(queryStrings){
          var reg = new RegExp("(^|&amp;)" + "mocktype" + "=([^&amp;]*)(&amp;|$)", "i");
          var r = queryStrings.match(reg);
          if (r != null)  queryMockType = r[2];
        }
      }
      var data = mock[path] || mock[url];
      if(!queryMockType){
        queryMockType = pdata? pdata["mocktype"]: null;
      }
      if(data){
        if(queryMockType){
          data = data[queryMockType];
        }else{
          data = data.hasOwnProperty("defaultResult")? data["defaultResult"] : data;
        }
      }
      return data;
    }</pre>
<p>&nbsp;</p>
<p><strong>优点</strong>： 纯前端就可以完成，简单便捷， 兼容性好</p>
<p><strong>缺点</strong>：缺乏灵活性, 不能真实模拟请求过程， 对复杂情况的mock需要在业务中增加耦合性高的测试代码</p>
<p><span style="color: #ff0000;">注</span>： mock数据来源 可以使用<a href="https://github.com/nuysoft/Mock/wiki/Getting-Started" target="_blank">mock.js</a>生成</p>
<h2>2、基于serviceWorker的请求拦截</h2>
<p>安装serviceWorker之后， 通过监听fetch来对结果做响应的处理</p>
<pre class="brush: js">self.addEventListener('fetch', function(event) {
  event.respondWith(
    return cacheData || fetch(testUrl)
 )
})</pre>
<pre class="hljs php"></pre>
<p><strong>优点</strong>：模拟真实请求</p>
<p><strong>缺点</strong>： 复杂性提高，灵活性不高</p>
<p>&nbsp;</p>
<h2>3、基于代理服务的mock</h2>
<p>可以使用charles等工具，对请求做拦截</p>
<p><strong><span style="font-family: 'arial black', 'avant garde';">优点</span></strong>： 灵活性高、复杂度也较低</p>
<p><strong>缺点</strong>： 多人协作情况下，数据同步是个问题。&nbsp;</p>
<p>&nbsp;</p>
<h2>4、自建mock服务</h2>
<p>基于<a href="https://yapi.ymfe.org/" target="_blank">yapi</a>的mock server</p>
<p><strong>优点</strong>： 前端可以完成mock的设置、复杂度低、灵活性也较高， 可以为前端e2e测试等提供数据基础</p>
<p><strong>缺点</strong>： 高级mock等有一定的学习成本</p>