title: 记一次GraphicsMagick处理图片的问题
date: '2018-06-02 12:51:51'
updated: '2018-06-02 12:51:51'
tags: [imageMagick, gm, js, node, web]
permalink: /articles/2018/06/02/1527915111817.html
---
<p>1、安装<a href="https://www.npmjs.com/package/gm" target="_blank">GraphicsMagick</a> 和&nbsp;<span>ImageMagick</span></p>
<p><span>mac下 安装</span></p>
<pre class="brush: java">brew install ImageMagick;
brew install GraphicsMagick;</pre>
<p><span>&nbsp;</span></p>
<p>2、目标：</p>
<p>利用GraphicsMagick对2倍图进行缩放 <a href="http://aheckmann.github.io/gm/docs.html#resize" target="_blank">resize方法</a></p>
<pre class="brush: js">  imageMagick("./src/assets/images/home/logo2.png").resize(92, 48, "!").write("./src/assets/images/home/logo2-4.png", function (err) {
    if (err) {
      console.log(err);
      return;
    }
  })
</pre>
<p>3、问题</p>
<p>缩放之后的图片严重失真</p>
<p>&nbsp;</p>
<p>4、解决</p>
<p>通过查看api， 找到<a href="http://aheckmann.github.io/gm/docs.html#thumb" target="_blank"> thumb方法</a> 生成缩略图</p>
<pre class="brush: js">imageMagick("./src/assets/images/home/logo2.png").thumb(92, 48, "./src/assets/images/home/logo2-2.png", 100, function (err) {
     if (err) {
       console.log(err);
       return;
     }
  })</pre>
<p>质量100，效果也和resize一样。</p>
<p>最后 找到了<a href="http://aheckmann.github.io/gm/docs.html#scale" target="_blank"><span style="color: #ff0000;"> scala方法</span></a> 进行缩放</p>
<pre class="brush: js">imageMagick("./src/assets/images/home/logo2.png").scale(92, 48).write("./src/assets/images/home/logo2-3.png", function (err) {
  if (err) {
    console.log(err);
     return;
  }
})</pre>
<pre><span>经尝试，基本保真缩放！</span></pre>