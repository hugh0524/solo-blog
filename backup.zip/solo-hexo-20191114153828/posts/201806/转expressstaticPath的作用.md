title: '[转]express staticPath的作用'
date: '2018-06-06 10:18:12'
updated: '2018-06-06 10:18:12'
tags: [staticPath, express, js, node]
permalink: /articles/2018/06/06/1528251481153.html
---
<p>为了提供诸如图像、CSS 文件和 JavaScript 文件之类的静态文件，请使用 Express 中的&nbsp;<code>express.static</code>&nbsp;内置中间件函数。</p>
<p>将包含静态资源的目录的名称传递给&nbsp;<code>express.static</code>&nbsp;中间件函数，以便开始直接提供这些文件。例如，使用以下代码在名为&nbsp;<code>public</code>&nbsp;的目录中提供图像、CSS 文件和 JavaScript 文件：</p>
<pre class="  language-javascript"><code class="  language-javascript">
app<span class="token punctuation">.</span><span class="token function">use<span class="token punctuation">(</span></span>express<span class="token punctuation">.</span><span class="token keyword">static</span><span class="token punctuation">(</span><span class="token string">'public'</span><span class="token punctuation">)</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
</code>
</pre>
<p>现在，可以访问位于&nbsp;<code>public</code>&nbsp;目录中的文件：</p>
<pre class="  language-javascript"><code class="  language-javascript">
http<span class="token punctuation">:</span><span class="token operator">/</span><span class="token operator">/</span>localhost<span class="token punctuation">:</span><span class="token number">3000</span><span class="token operator">/</span>images<span class="token operator">/</span>kitten<span class="token punctuation">.</span>jpg
http<span class="token punctuation">:</span><span class="token operator">/</span><span class="token operator">/</span>localhost<span class="token punctuation">:</span><span class="token number">3000</span><span class="token operator">/</span>css<span class="token operator">/</span>style<span class="token punctuation">.</span>css
http<span class="token punctuation">:</span><span class="token operator">/</span><span class="token operator">/</span>localhost<span class="token punctuation">:</span><span class="token number">3000</span><span class="token operator">/</span>js<span class="token operator">/</span>app<span class="token punctuation">.</span>js
http<span class="token punctuation">:</span><span class="token operator">/</span><span class="token operator">/</span>localhost<span class="token punctuation">:</span><span class="token number">3000</span><span class="token operator">/</span>images<span class="token operator">/</span>bg<span class="token punctuation">.</span>png
http<span class="token punctuation">:</span><span class="token operator">/</span><span class="token operator">/</span>localhost<span class="token punctuation">:</span><span class="token number">3000</span><span class="token operator">/</span>hello<span class="token punctuation">.</span>html
</code>
</pre>
<div class="doc-box doc-info">Express 相对于静态目录查找文件，因此静态目录的名称不是此 URL 的一部分。</div>
<p>要使用多个静态资源目录，请多次调用&nbsp;<code>express.static</code>&nbsp;中间件函数：</p>
<pre class="  language-javascript"><code class="  language-javascript">
app<span class="token punctuation">.</span><span class="token function">use<span class="token punctuation">(</span></span>express<span class="token punctuation">.</span><span class="token keyword">static</span><span class="token punctuation">(</span><span class="token string">'public'</span><span class="token punctuation">)</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
app<span class="token punctuation">.</span><span class="token function">use<span class="token punctuation">(</span></span>express<span class="token punctuation">.</span><span class="token keyword">static</span><span class="token punctuation">(</span><span class="token string">'files'</span><span class="token punctuation">)</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
</code>
</pre>
<p>Express 以您使用&nbsp;<code>express.static</code>&nbsp;中间件函数设置静态目录的顺序来查找文件。</p>
<p>要为&nbsp;<code>express.static</code>&nbsp;函数提供的文件创建虚拟路径前缀（路径并不实际存在于文件系统中），请为静态目录指定<span style="color: #ff0000;">安装路径</span>，如下所示：</p>
<pre class="  language-javascript"><code class="  language-javascript">
app<span class="token punctuation">.</span><span class="token function">use<span class="token punctuation">(</span></span><span class="token string">'/static'</span><span class="token punctuation">,</span> express<span class="token punctuation">.</span><span class="token keyword">static</span><span class="token punctuation">(</span><span class="token string">'public'</span><span class="token punctuation">)</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
</code>
</pre>
<p>现在，可以访问具有&nbsp;<code>/static</code>&nbsp;路径前缀的&nbsp;<code>public</code>&nbsp;目录中的文件。</p>
<pre class="  language-javascript"><code class="  language-javascript">
http<span class="token punctuation">:</span><span class="token operator">/</span><span class="token operator">/</span>localhost<span class="token punctuation">:</span><span class="token number">3000</span><span class="token operator">/</span><span class="token keyword">static</span><span class="token operator">/</span>images<span class="token operator">/</span>kitten<span class="token punctuation">.</span>jpg
http<span class="token punctuation">:</span><span class="token operator">/</span><span class="token operator">/</span>localhost<span class="token punctuation">:</span><span class="token number">3000</span><span class="token operator">/</span><span class="token keyword">static</span><span class="token operator">/</span>css<span class="token operator">/</span>style<span class="token punctuation">.</span>css
http<span class="token punctuation">:</span><span class="token operator">/</span><span class="token operator">/</span>localhost<span class="token punctuation">:</span><span class="token number">3000</span><span class="token operator">/</span><span class="token keyword">static</span><span class="token operator">/</span>js<span class="token operator">/</span>app<span class="token punctuation">.</span>js
http<span class="token punctuation">:</span><span class="token operator">/</span><span class="token operator">/</span>localhost<span class="token punctuation">:</span><span class="token number">3000</span><span class="token operator">/</span><span class="token keyword">static</span><span class="token operator">/</span>images<span class="token operator">/</span>bg<span class="token punctuation">.</span>png
http<span class="token punctuation">:</span><span class="token operator">/</span><span class="token operator">/</span>localhost<span class="token punctuation">:</span><span class="token number">3000</span><span class="token operator">/</span><span class="token keyword">static</span><span class="token operator">/</span>hello<span class="token punctuation">.</span>html
</code>
</pre>
<p>然而，向&nbsp;<code>express.static</code>&nbsp;函数提供的路径相对于您在其中启动&nbsp;<code>node</code>&nbsp;进程的目录。如果从另一个目录运行 Express 应用程序，那么对于提供资源的目录使用绝对路径会更安全：</p>
<pre class="  language-javascript"><code class="  language-javascript">
app<span class="token punctuation">.</span><span class="token function">use<span class="token punctuation">(</span></span><span class="token string">'/static'</span><span class="token punctuation">,</span> express<span class="token punctuation">.</span><span class="token keyword">static</span><span class="token punctuation">(</span>__dirname <span class="token operator">+</span> <span class="token string">'/public'</span><span class="token punctuation">)</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
</code></pre>
<div><code class="  language-javascript"><span class="token punctuation">&nbsp;</span></code></div>