title: NodeJs实现运行用户输入的代码段
date: '2019-03-01 16:31:41'
updated: '2019-03-01 16:34:11'
tags: [node, sandbox, vm, 前端, js, web]
permalink: /articles/2019/02/28/1551350125299.html
---
<p>需要实现效果如下</p>
<p>&nbsp;<a href="http://tools.uproject.cn/upload/article/1551428398325.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/1551428398325.jpg" alt="" width="500" height="309" /></a></p>
<p>&nbsp;用户可以根据自己设定的规则和过滤条件， 执行响应的报警。</p>
<p>&nbsp;</p>
<p>运用知识点：</p>
<p><a href="http://nodejs.cn/api/vm.html" target="_blank">node vm</a></p>
<p>1.&nbsp;<span style="font-size: 1.17em;">new vm.Script(code, options)</span></p>
<p><span style="font-size: 14.04px;">将输入的code 进行预编译（但是不执行）</span></p>
<p><span style="font-size: small;">2.vm.createContext([sandbox[, options]])</span></p>
<p><span style="font-size: small;">依据sandbox对象，创建一个执行上下文</span></p>
<p><span style="font-size: small;">3.</span><span style="font-size: 1.17em;">script.runInContext(contextifiedSandbox[, options])</span></p>
<p><span style="font-size: 1.17em;">在指定的上下文中执行编译好的js代码。<span><span style="color: #ff0000;">被执行的代码无法获取本地作用域</span>。</span></span></p>
<p><span style="font-size: 1.17em;"><span>&nbsp;</span></span></p>
<p><span style="font-size: 1.17em;"><span>code:</span></span></p>
<pre class="brush: java">exeInSandbox: function(sandbox, script){
        const vm = require('vm');
        sandbox = sandbox || {};
        script = new vm.Script(script);
        const context = new vm.createContext(sandbox);
        script.runInContext(context, {
            timeout: 3000
        });
        return sandbox;
     }</pre>
<p><span style="font-size: 1.17em;"><span>&nbsp;</span></span></p>