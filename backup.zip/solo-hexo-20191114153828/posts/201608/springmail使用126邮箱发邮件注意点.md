title: spring mail使用126邮箱发邮件注意点
date: '2016-08-17 18:28:37'
updated: '2016-08-17 18:28:37'
tags: ['126', email, spring, mail]
permalink: /articles/2016/08/17/1471429717646.html
---
<p>问题：126邮箱直接设置邮箱+密码的方式无法发送</p>
<p>&nbsp;</p>
<p>原因：126邮箱限制</p>
<p>进入126邮箱，设置SMTP服务，开启，提示设置授权码。</p>
<p>在邮件配置中使用邮箱+授权码即可成功</p>
<p>&nbsp;</p>