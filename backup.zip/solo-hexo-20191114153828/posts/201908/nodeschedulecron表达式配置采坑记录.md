title: node schedule cron表达式配置采坑记录
date: '2019-08-03 23:11:43'
updated: '2019-08-03 23:18:23'
tags: [node, web, 前端, cron, schedule]
permalink: /articles/2019/08/03/1564845101181.html
---
<p>1. 使用node-shedule做任务调度，</p>
<p>按文档，是支持cron风格的时间配置， 结果发现并不是完全一样</p>
<p>&nbsp;</p>
<p>例如：</p>
<pre class="prettyprint">0 0/10 * * * ?</pre>
<p>执行cron的结果应该是：<span style="color: #ff0000;">从0分钟开始，每10分钟执行一次</span></p>
<p>实际在node中执行结果是<span style="color: #ff0000;">每小时的第0分钟执行了</span></p>
<p>&nbsp;</p>
<p>2. 原因</p>
<p>node使用了 cron-parse库进行解析</p>
<p>我们可以在运行前使用以下代码进行检查是否正确</p>
<pre class="prettyprint">var parser = require('cron-parser');
function testCron () {
    var interval = parser.parseExpression('0 0/10 * * * ?');

    console.log('Date: ', interval.next().toString()); // Sat Dec 29 2012 00:42:00 GMT+0200 (EET)
    console.log('Date: ', interval.next().toString()); // Sat Dec 29 2012 00:44:00 GMT+0200 (EET)

}

testCron()</pre>