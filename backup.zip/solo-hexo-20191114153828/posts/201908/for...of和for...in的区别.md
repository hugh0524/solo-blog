title: for...of和for...in的区别
date: '2019-08-13 18:28:50'
updated: '2019-08-13 18:28:50'
tags: [前端, js, web, for...in, for...of]
permalink: /articles/2019/08/13/1565692129812.html
---
<p>看一个例子</p>
<pre class="brush: js">var a = [1,2,3]
for(let i in a) {
  console.log(i)
}
//0
//1
//2

for(let i of a) {
  console.log(i)
}
//1
//2
//3</pre>
<p><a href="http://tools.uproject.cn/upload/article/1565691806220.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/1565691806220.jpg" alt="" width="400" height="143" /></a></p>
<p><em><strong>注意点：</strong></em></p>
<p><em><strong>for...in 遍历的是可枚举属性， 应谨慎用于遍历数组等对象</strong></em></p>
<p><em><strong>for...in 遍历是无序的</strong></em></p>
<pre class="brush: js">var c={a:1,1:2,c:4,b:5}
for(let i in c) {
  console.log(i)
}
//1
//a
//c
//b</pre>
<p>&nbsp;</p>
<p>&nbsp;</p>