title: wex5设置页面title
date: '2016-05-07 21:47:58'
updated: '2016-05-07 21:47:58'
tags: [微信, html, js, wex5]
permalink: /articles/2016/05/07/1462628878827.html
---
<p>在使用wex5制作微信站点时，需要设置页面的title</p>
<p>设置方法</p>
<p>在model的初始化方法中使用</p>
<pre class="brush: xml">$("head").append("&lt;title&gt;战略布局&lt;/title&gt;");</pre>