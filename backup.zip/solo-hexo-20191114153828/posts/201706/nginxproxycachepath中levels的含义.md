title: nginx proxy_cache_path中levels的含义
date: '2017-06-06 11:29:06'
updated: '2017-06-06 11:29:06'
tags: [proxy, levels, nginx]
permalink: /articles/2017/06/06/1496719746571.html
---
<pre><strong><br /><br /><span>The&nbsp;</span><code>levels</code><span>&nbsp;parameter defines hierarchy levels of a cache: from 1 to 3, each level accepts values 1 or 2. For example, in the following configuration</span><br /><br /></strong></pre>
<pre><br class="Apple-interchange-newline" />proxy_cache_path /data/nginx/cache levels=1:2 keys_zone=one:10m;<br />eg:</pre>
<pre>/data/nginx/cache/<strong>c</strong>/<strong>29</strong>/b7f54b2df7773722d382f4809d650<strong>29c<br /></strong><br /><br /><strong>levels可以设置 1到3层 每层有1和2两个值。 表示目录名称是1个字符还是2个字符</strong></pre>
<pre><strong><br /><br /></strong></pre>