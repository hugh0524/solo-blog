title: 使用html2casvas将html元素写入canvas并转化为图片
date: '2017-06-30 14:36:04'
updated: '2017-06-30 14:38:45'
tags: [js, web, 前端, canvas, html2canvas, 跨域]
permalink: /articles/2017/06/30/1498804564395.html
---
<h2>1、html2canvas</h2>
<p><a href="https://html2canvas.hertzen.com/" target="_blank">官网</a></p>
<h2>2、使用中的问题</h2>
<h3>1）图片、文字模糊</h3>
<p>解决： 根据屏幕像素比，缩放相应的倍数</p>
<pre class="brush: js"> var getPixelRatio = function (context) {
                    var backingStore = context.backingStorePixelRatio ||
                        context.webkitBackingStorePixelRatio ||
                        context.mozBackingStorePixelRatio ||
                        context.msBackingStorePixelRatio ||
                        context.oBackingStorePixelRatio ||
                        context.backingStorePixelRatio || 1;
                    console.log("backingStore=="+backingStore+",window.devicePixelRatio=="+window.devicePixelRatio)
                    return (window.devicePixelRatio || 1) / backingStore;
                };</pre>
<pre class="brush: js">// srcEl 需要被写入的元素
var originalWidth = srcEl.width();
                 var originalHeight = srcEl.height();
             
                 var scaledCanvas = document.createElement("canvas");
                 var scaledContext = scaledCanvas.getContext("2d");

                 scaledContext.webkitImageSmoothingEnabled = false;
                 scaledContext.mozImageSmoothingEnabled = false;
                 scaledContext.imageSmoothingEnabled = false;

                 var scaleFactor = getPixelRatio(scaledContext);
              
                 scaledCanvas.width = originalWidth * scaleFactor;
                 scaledCanvas.height = originalHeight * scaleFactor;
                 scaledCanvas.style.width = originalWidth + "px";
                 scaledCanvas.style.height = originalHeight + "px";
               
                 scaledContext.scale(scaleFactor, scaleFactor);

 html2canvas(srcEl[0], {canvas: scaledCanvas})
                     .then(function (canvas) {
                        var imgData = canvas.toDataURL('image/png', 1);
                     })</pre>
<p>&nbsp;</p>
<h3>2) 在safair上测试，当包含图片或背景图片跨域时，报 security excetion</h3>
<p>解决1、背景图片换成img</p>
<p>&nbsp; &nbsp; &nbsp; 2、<a href="http://blog.uproject.cn/articles/2017/06/05/1496652336416.html" target="_blank">img 上加<span>crossOrigin = "anonymous" &nbsp;或 将讲图片先上传到服务器，在从同域服务器读取</span></a></p>