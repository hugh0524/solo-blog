title: 观察者模式--设计模式之js运用
date: '2016-06-01 11:47:01'
updated: '2016-06-01 11:57:47'
tags: [web, 前端, pattern, 设计模式, js, 观察者模式]
permalink: /articles/2016/06/01/1464752821518.html
---
<h2>1、观察者模式</h2>
<p>当对象间存在一对多关系时，则使用观察者模式（Observer Pattern）。比如，当一个对象被修改时，则会自动通知它的依赖对象。观察者模式属于行为型模式。</p>
<h2>2、js实现</h2>
<p>1）实现一个被观察主题</p>
<pre class="brush: js">/**
 * 被观察者
 * @constructor
 */
function Subject(){
    this.observers = [];
    this.state = 0;
}
Subject.prototype.setState=function(val){
    this.state = val;
    this.notifyAllObservers();
}
//添加观察者对象
Subject.prototype.addObs=function(obj){
    this.observers.push(obj);
}
//触发通知
Subject.prototype.notifyAllObservers = function(){
    for(var i in this.observers){
        this.observers[i].update();
    }
}</pre>
<p>2）实现几个观察者</p>
<pre class="brush: js">/**
 * 观察者1
 * @param subject
 * @constructor
 */
function FirstObserver(subject){
    this.subject = subject;
    subject.addObs(this);
}
FirstObserver.prototype.update=function(){
    console.log("first observer:"+this.subject.state);
};

/**
 * 观察者2
 */
function SecondObserver(subject){
    this.subject = subject;
    subject.addObs(this);
}
SecondObserver.prototype.update=function(){
    console.log("second observer:"+this.subject.state);
};</pre>
<p>3）测试</p>
<pre class="brush: xml">&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head lang="en"&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;title&gt;&lt;/title&gt;
    &lt;script src="FirstObserver.js"&gt;&lt;/script&gt;
    &lt;script src="SecondObserver.js"&gt;&lt;/script&gt;
    &lt;script src="Subject.js"&gt;&lt;/script&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;script&gt;
        var sub = new Subject();
        var fo = new FirstObserver(sub);
        var so = new SecondObserver(sub);
        sub.setState("222");
    &lt;/script&gt;
&lt;/body&gt;
&lt;/html&gt;</pre>
<p>&nbsp;结果</p>
<p><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMsAAAAqCAIAAACSgThDAAAC8ElEQVR4nO2bwW3EIBBF6YiKKGhayYkC0kMuSCnHORiGgQFjO5lkFf+nlbLGYxabz4Ajvnt7/8AHH7uP2wCwBAoDtkBhwBYoDNgChQFboDBgCxQGbLmvsBicc845T2nbtm1L5F2IFypIRKfDE3n+oT+k3HNpSyKfC/Kd9wHgvsJiuCQnTSJ/pYZE4a87rTYhBk9JPIN8LyoA3FQYj1Qeq3tJUUw5EqXdaK81THuiy5GJQgheXqHyRSkQv1DbsDfAU9rPeEq1UeLAU+TAUmcdCCmVfJ2lVAqK1lQA+MEc1pZ0XTOYEQ+zYE0C+Vsiv5eU3Bep7cNaHZ9p28AR+W9VAbfu3GSs5NPfCfQlMFRYez4nmEGHj5B9tMfpGShnILUkkquivg2eEgtQZGKRKFfSiKHVoFp+9gFP55cUJtIKP/6rOSywlHbF1byTp0VVnSpKFIiIpjPZSmExsHhjnvuLNmNMgwBwT2HqFUrkgxD7o/aKOr5z2Uxmah02e23TjeDVVp82hSRUnaMmthNtn/RU2hxkRYD/hwFboDBgCxQGbIHCgC1QGLAFCgO2uE8ALEEOA7ZAYcAWKAzYAoUBW6AwYAsUBmyBwoAtL6awblfqDwSasnSC6H1Oj+PFFHbBYfJtK8r3WTpB+oAnclNhxy6MrTNZiONq0wih2Ve9HO1tDdsWw6qGY6MH21T2M41BZegl4TrlHsaVE6QPeB73FLZyYfCQzU+6DuG657l4kPau4F3Tk66Y11C3Wbdmk7XRo0TUNqy8JLPHsXKCPFdft3PYwoWhLRh8nJ8+D/oiwTq/DDtjXkMVX2s2OWH02K8sAjzjJRk/iUMnyGWn8j/j5j79hQtDLDtijOMMNE5yswXLvAZe83Rmk1NGjxgCce474yVRrTp2gqiA53Fzljx2YcjjfpHULHGqTZazoveTeUmvw2avbWrtNzd6CEmoOodeEjnRLp0go6z4OF7uXRL8M6AwYAsUBmyBwoAtUBiwBfv0gS1fK/DvHoQl7fAAAAAASUVORK5CYII=" alt="" /></p>