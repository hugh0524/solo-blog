title: CSS垂直居中(未完待续。。。)
date: '2016-06-27 20:29:56'
updated: '2016-06-27 20:29:56'
tags: [CSS, web, 前端, 垂直居中]
permalink: /articles/2016/06/27/1467027919791.html
---
<p>1、使用table</p>
<pre class="brush: xml">&lt;table style="width:100%;height:100%;position:absolute;"&gt;
	&lt;tbody&gt;
		&lt;tr&gt;
			&lt;td style="text-align:center; vertical-align:middle;"&gt;
				&lt;div style="display: inline-block;*zoom:1;*display:inline; background:red;height:200px;"&gt;
					&lt;div&gt;
						sssss
						&lt;p&gt;&lt;/p&gt;
					&lt;/div&gt;
				&lt;/div&gt;
			&lt;/td&gt;
		&lt;/tr&gt;
	&lt;/tbody&gt;
&lt;/table&gt;
</pre>
<p>--经测试，Firefox，chrome,IE8以上，IE5.5成功居中显示</p>
<p>2、使用css3属性 <a target="_blank" href="http://caibaojian.com/flexbox-guide.html">flexbox</a></p>
<pre class="brush: xml"> &lt;body style="padding:0;margin:0;"&gt;
  
&lt;div style="position:absolute;width:100%;height:100%;border:1px solid red;display:flex;justify-content:center;align-items:center;"&gt;
	&lt;div style="border:1px solid #000;width:100px;height:100px;"&gt;111&lt;/div&gt;
&lt;/div&gt;

 &lt;/body&gt;</pre>