title: css3动画steps属性
date: '2016-06-30 19:20:57'
updated: '2016-06-30 19:23:05'
tags: [steps, animation, web, 前端, css3]
permalink: /articles/2016/06/30/1467280814461.html
---
<p>1、首先看个效果，进度条</p>
<style><!--
@keyframes  spkf{
       0% {width:10px;}
       100% {width: 300px;}
    }
    .s1{
        width: 100px;
        height: 20px;
        background: red;
        animation: spkf 10s steps(100) infinite;
    }
  @keyframes spnum {
        0% {background-position: -57px -35px;}
        100% {background-position: -544px -35px;}
    }
    .s2{
        width: 80px;
        height: 140px;
        background: url("http://hugh-10023362.cos.myqcloud.com/static/imgs/blog/b093ccff2875.jpg") -57px -35px no-repeat;
        animation: spnum 5s steps(5) infinite;
    }
--></style>
<div class="s1">&nbsp;</div>
<p>代码:</p>
<pre class="brush: xml">&lt;style&gt;
    @keyframes  spkf{
       0% {width:10px;}
       100% {width: 300px;}
    }
    .s1{
        width: 100px;
        height: 20px;
        background: red;
        animation: spkf 10s steps(100) infinite;
    }
&lt;/style&gt;
&lt;div&gt;
    &lt;div class="s1"&gt;&lt;/div&gt;
&lt;/div&gt;</pre>
<p>2、steps</p>
<p>例1中，将动画平均分成了100份，在10s内变化完成一个循环</p>
<p>效果2：计时</p>
<div class="s2">&nbsp;</div>
<p>代码：</p>
<pre class="brush: css">  @keyframes spnum {
        0% {background-position: -57px -35px;}
        100% {background-position: -544px -35px;}
    }
    .s2{
        width: 80px;
        height: 140px;
        background: url("http://hugh-10023362.cos.myqcloud.com/static/imgs/blog/b093ccff2875.jpg") -57px -35px no-repeat;
        animation: spnum 5s steps(5) infinite;
    }


&lt;div class="s2"&gt;&lt;/div&gt;</pre>