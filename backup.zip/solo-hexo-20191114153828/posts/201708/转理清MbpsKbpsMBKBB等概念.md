title: 【转】理清Mbps,Kbps,MB,KB,B等概念
date: '2017-08-11 10:46:08'
updated: '2017-08-11 10:46:08'
tags: [带宽, 网络, B, MB, Mbps, Kbps]
permalink: /articles/2017/08/11/1502419559308.html
---
<div class="bct fc05 fc11 nbw-blog ztag js-fs2">
<p><span style="color: #ff9900;">什么是Mbps、Kbps、bps、kb、mb及其换算和区别：</span></p>
<p>Mbps 即 Milionbit pro second(百万位每秒)；</p>
<p>Kbps 即 Kilobit pro second（千位每秒）；</p>
<p>bps 即 bit pro second（位每秒）；</p>
<p>速度单位，bit即比特，通常用b（小写）表示，指一位二进制位，Milionbit=1000Kilobit=1000000bit；</p>
<p>所以1Mbps=1000000bps；</p>
<p>这是通常用来衡量带宽的单位，指每秒钟传输的二进制位数；</p>
<p>而通常软件上显示的速度则是指每秒种传输的字节数（Byte）通常用B（大写）表示；</p>
<p>MB即百万字节也称兆字节；</p>
<p>KB即千字节；</p>
<p>B即字节；</p>
<p>之间关系为1MB=1024KB=1024*1024B；</p>
<p>1B=8b；</p>
<p><span style="color: #ff0000;">所以1M带宽即指1Mbps=1000Kbps=1000/8KBps=125KBps；</span></p>
<p><span style="color: #ff0000;">因此1M的带宽下载的速度一般不会超过125KB每秒。</span></p>
<p><span style="color: #ff0000;">2M、3M带宽分别是250KBps、375KBps；</span></p>
<p><span style="color: #ff0000;">2M、3M带宽的下载速度分别不会超过250KB、375KB每秒。</span></p>
<p>&nbsp;</p>
<p>假设要对<strong>10kbps</strong>进行换算，则有 <strong><span style="text-decoration: underline;">10kbps=10000bps=0.01Mpbs</span></strong>.<br /><span style="font-size: medium;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 数据传输速率的衡量单位K是十进制含义,但数据存储的K是2进制含义。</span><span style="display: none;">1fd知1fK:JFD()本文来自移动通信网www.mscbsc.com,版权所有</span><br /><span style="font-size: medium;">1kbit/s就是1000bit/s,而KB是1024个字节,注意KB和kbit的区别，</span><span style="font-size: medium;">另外，数据传输速率的单位是bit/s 记作：bps 。</span><span style="display: none;">5%#(么K:JFD(本文来自移动通信网www.mscbsc.com,版权所有</span><br /><span style="font-size: medium;">在实际应用中,1kbps=1000bps，1Mbps=1000,000bps.</span><br /><span style="font-size: medium;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1bps=0.000001bps</span></p>
<p><span style="font-size: large;">1Mbps与 1m/s 是有区别的，1m/s指的是是1024KB/S&nbsp;&nbsp;</span></p>
<p><span style="font-size: large;">而1Mbps指的是1000/8KB/S也就是125KB/S，&nbsp; </span><br /><span style="font-size: large;"><span style="color: #ff0000;">记住K和k是没区别的&nbsp; ，区别在于bps属于位每秒的单位</span>，而m/s ,KB/S这两个属于字节每秒的单位，一字节等于8位，即1k=8b</span></p>
</div>