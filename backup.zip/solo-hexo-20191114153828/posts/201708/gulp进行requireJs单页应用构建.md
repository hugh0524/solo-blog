title: gulp进行requireJs 单页应用构建
date: '2017-08-10 17:33:21'
updated: '2017-08-10 17:33:21'
tags: [web, 前端, js, requireJs, gulp]
permalink: /articles/2017/08/10/1502357582790.html
---
<h1>1、安装gulp</h1>
<p><a href="http://docs.uproject.cn/gulp%E8%BF%90%E7%94%A8/#/" target="_blank">gulp使用</a></p>
<p>&nbsp;</p>
<h1>2、代码结构</h1>
<p><a href="http://tools.uproject.cn/images/1502355823451.png" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/images/1502355823451.png" alt="" width="279" height="305" /></a></p>
<p>&nbsp;</p>
<h1>3、目标及步骤</h1>
<p>将使用app.js、app目录中的内容打包到一个js，并使用版本控制</p>
<h2>1）选择需要的插件</h2>
<p>合并文件(gulp-concat)、压缩js(gulp-uglify)、清除目录(gulp-clean)、版本控制（gulp-rev）、requireJs打包插件（amd-optimize）</p>
<h2>2) 创建Task</h2>
<h3>① 压缩js &nbsp; gulp.src 目录以gulpfile所在目录为准</h3>
<pre class="brush: js">gulp.task('minJs',function () {
    
   return gulp.src("static/js/**/*.js")
        .pipe(amdOptimize.src("app",{
            configFile:"static/js/config.js",
            baseUrl:"static/js" //作用 指定了加载js的baseUrl， src第一个参数就会使用到给url,js内部依赖的模板同样使用该url
        }))
        .pipe(concatFile("app.min.js"))
        .pipe(uglifyJS())
        .pipe(gulp.dest("static/js/dist"))


});</pre>
<h3>② 对压缩后的app.min.js 加指纹</h3>
<pre class="brush: js">gulp.task("version",['minJs'],function () {
    return gulp.src("static/js/dist/*.js")
        .pipe(rev({merge:true}))
        .pipe(gulp.dest("static/js/dist"))
        .pipe(rev.manifest())//生成一个 json 映射文件及其版本
        .pipe(gulp.dest('static/js/dist/rev'))

})</pre>
<p>rev-manifest.json文件<a href="http://tools.uproject.cn/images/1502357405956.png" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/images/1502357405956.png" alt="" width="260" height="50" /></a></p>
<h3>③ 更改html内对该js的引用</h3>
<pre class="brush: js">gulp.task('build',['version'], function() {
    // 替换html
    gulp.src(['static/js/dist/rev/*.json', 'pages/index_source.html'])        //- 读取 rev-manifest.json 文件以及需要进行替换的文件
        .pipe(revCollector())                               //- 执行文件内 的替换
        .pipe(concatFile("index.html"))
        .pipe(gulp.dest('pages/'));    //- 替换后的文件输出的目录

});</pre>