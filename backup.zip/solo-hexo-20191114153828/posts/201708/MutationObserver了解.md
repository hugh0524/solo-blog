title: MutationObserver了解
date: '2017-08-17 11:19:57'
updated: '2017-08-17 11:29:34'
tags: [MutationObserver, js, 前端, web, Observe]
permalink: /articles/2017/08/17/1502939973958.html
---
<h1>1、<a href="http://tools.uproject.cn/tools/showDemo?id=30" target="_blank">简单demo</a></h1>
<p>&nbsp;<a href="http://tools.uproject.cn/tools/showDemo?id=30" target="_blank" style="font-size: 2em;">简单demo</a></p>
<h1>2、api</h1>
<p>构造方法 得到 Observe对象</p>
<pre class="eval line-numbers  language-html"><code class=" language-html">MutationObserver(
  function callback
);</code></pre>
<p>callback回调对象的属性</p>
<table class="standard-table" border="1">
<tbody>
<tr>
<td><code>type</code></td>
<td><code>String</code></td>
<td>如果是属性发生变化,则返回<code>attributes</code>.如果是<code>一个CharacterData</code>节点发生变化,则返回<code>characterData</code>,如果是目标节点的某个子节点发生了变化,则返回<code>childList.</code></td>
</tr>
<tr>
<td><code>target</code></td>
<td><code><a href="https://developer.mozilla.org/zh-CN/docs/Web/API/Node" title="Node是一个接口，许多DOM类型从这个接口继承，并允许类似地处理（或测试）这些各种类型。">Node</a></code></td>
<td>返回此次变化影响到的节点,具体返回那种节点类型是根据<code>type值的不同而不同的</code>. 如果<code>type</code>为<code>attributes</code>,则返回发生变化的属性节点所在的元素节点,如果<code>type</code>值为<code>characterData</code>,则返回发生变化的这个<code>characterData</code>节点.如果<code>type</code>为<code>childList</code>,则返回发生变化的子节点的父节点.</td>
</tr>
<tr>
<td><code>addedNodes</code></td>
<td><code><a href="https://developer.mozilla.org/zh-CN/docs/Web/API/NodeList" title="NodeList 对象是一个节点的集合，是由 Node.childNodes&nbsp;和 document.querySelectorAll 返回的.">NodeList</a></code></td>
<td>返回被添加的节点,或者为<code>null</code>.</td>
</tr>
<tr>
<td><code>removedNodes</code></td>
<td><code><a href="https://developer.mozilla.org/zh-CN/docs/Web/API/NodeList" title="NodeList 对象是一个节点的集合，是由 Node.childNodes&nbsp;和 document.querySelectorAll 返回的.">NodeList</a></code></td>
<td>返回被删除的节点,或者为<code>null</code>.</td>
</tr>
<tr>
<td><code>previousSibling</code></td>
<td><code><a href="https://developer.mozilla.org/zh-CN/docs/Web/API/Node" title="Node是一个接口，许多DOM类型从这个接口继承，并允许类似地处理（或测试）这些各种类型。">Node</a></code></td>
<td>返回被添加或被删除的节点的前一个兄弟节点,或者为<code>null</code>.</td>
</tr>
<tr>
<td><code>nextSibling</code></td>
<td><code><a href="https://developer.mozilla.org/zh-CN/docs/Web/API/Node" title="Node是一个接口，许多DOM类型从这个接口继承，并允许类似地处理（或测试）这些各种类型。">Node</a></code></td>
<td>返回被添加或被删除的节点的后一个兄弟节点,或者为<code>null</code>.</td>
</tr>
<tr>
<td><code>attributeName</code></td>
<td><code>String</code></td>
<td>返回变更属性的本地名称,或者为<code>null</code>.</td>
</tr>
<tr>
<td><code>attributeNamespace</code></td>
<td><code>String</code></td>
<td>返回变更属性的命名空间,或者为<code>null</code>.</td>
</tr>
<tr>
<td><code>oldValue</code></td>
<td><code>String</code></td>
<td>
<p>根据<code>type值的不同,返回的值也会不同</code>.如果type为&nbsp;<code>attributes</code>,则返回该属性变化之前的属性值.如果type为<code>characterData</code>,则返回该节点变化之前的文本数据.如果type为<code>childList</code>,则返回<code>null</code>.</p>
</td>
</tr>
</tbody>
</table>
<p>Observer对象 方法：</p>
<table class="standard-table">
<tbody>
<tr>
<td><code>void&nbsp;<a href="https://developer.mozilla.org/zh-CN/docs/Web/API/MutationObserver#observe()">observe</a>(&nbsp;<a href="https://developer.mozilla.org/zh-CN/docs/Web/API/Node" title="Node是一个接口，许多DOM类型从这个接口继承，并允许类似地处理（或测试）这些各种类型。"><code>Node</code></a>&nbsp;target, optional&nbsp;<a href="https://developer.mozilla.org/zh-CN/docs/Web/API/MutationObserver#MutationObserverInit">MutationObserverInit</a>&nbsp;options );</code></td>
</tr>
<tr>
<td><code>void&nbsp;<a href="https://developer.mozilla.org/zh-CN/docs/Web/API/MutationObserver#disconnect()">disconnect</a>();</code></td>
</tr>
<tr>
<td><code>Array&nbsp;<a href="https://developer.mozilla.org/zh-CN/docs/Web/API/MutationObserver#takeRecords()">takeRecords</a>();</code></td>
</tr>
</tbody>
</table>
<p>属性 Options</p>
<table class="standard-table" border="1">
<tbody>
<tr>
<td><code>childList</code></td>
<td>如果需要观察目标节点的子节点(新增了某个子节点,或者移除了某个子节点),则设置为<code>true</code>.</td>
</tr>
<tr>
<td><code>attributes</code></td>
<td>如果需要观察目标节点的属性节点(新增或删除了某个属性,以及某个属性的属性值发生了变化),则设置为<code>true</code>.</td>
</tr>
<tr>
<td><code>characterData</code></td>
<td>如果目标节点为<code>characterData节点(一种抽象接口,具体可以为文本节点</code>,注释节点,以及处理指令节点<code>)</code>时,也要观察该节点的文本内容是否发生变化,则设置为<code>true</code>.</td>
</tr>
<tr>
<td><code>subtree</code></td>
<td>除了目标节点,如果还需要观察目标节点的所有后代节点(观察目标节点所包含的整棵DOM树上的上述三种节点变化),则设置为<code>true</code>.</td>
</tr>
<tr>
<td><code>attributeOldValue</code></td>
<td>
<p>在<code>attributes</code>属性已经设为<code>true的前提下,如果需要将发生变化的</code>属性节点之前的属性值记录下来(记录到下面MutationRecord对象的oldValue属性中),则设置为<code>true</code>.</p>
</td>
</tr>
<tr>
<td><code>characterDataOldValue</code></td>
<td>在<code>characterData</code>属性已经设为<code>true的前提下,如果需要将发生变化的</code><code>characterData</code><code>节点之前的</code>文本内容记录下来(记录到下面MutationRecord对象的oldValue属性中),则设置为<code>true</code>.</td>
</tr>
<tr>
<td><code>attributeFilter</code></td>
<td>一个属性名数组(不需要指定命名空间),只有该数组中包含的属性名发生变化时才会被观察到,其他名称的属性发生变化后会被忽略.</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
<h1>&nbsp;3、<a href="http://tools.uproject.cn/tools/showDemo?id=38" target="_blank">修改属性的demo</a></h1>
<p><a href="http://tools.uproject.cn/tools/showDemo?id=38" target="_blank">修改属性的demo</a></p>