title: safari Cookie跨域注入的bug
date: '2018-07-31 22:44:18'
updated: '2018-12-03 14:31:58'
tags: [跨域, cookie, safari, iframe]
permalink: /articles/2018/07/31/1533048245132.html
---
<p>问题1：</p>
<p>&nbsp; &nbsp;有A、B两个域名， 访问A域名时需要将部分Cookie注入到B域名下</p>
<p>&nbsp;</p>
<p>处理1：</p>
<p>&nbsp; &nbsp;A域名下使用CORS调用B域名下的Url, set-cookie</p>
<p>&nbsp;</p>
<p>问题2：</p>
<p>&nbsp;在safari下， 如果B域名下本身没有cookie, 则发现注入失败</p>
<p>&nbsp;</p>
<p>处理2：</p>
<p>在A域名下，使用location显式访问一次B域名， 在执行&lsquo;处理1&rsquo;</p>