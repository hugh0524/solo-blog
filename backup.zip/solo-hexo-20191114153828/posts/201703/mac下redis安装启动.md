title: mac下redis安装，启动
date: '2017-03-02 23:28:27'
updated: '2017-03-06 22:56:35'
tags: [缓存, mac, redis]
permalink: /articles/2017/03/02/1488468471418.html
---
<p>1、安装：</p>
<p>&nbsp; &nbsp; brew install redis</p>
<p>&nbsp;</p>
<p>2、启动</p>
<p>&nbsp; &nbsp;cd /usr/local/bin</p>
<p>&nbsp; &nbsp;sudo ./redis-server</p>
<p>&nbsp;</p>
<p>&nbsp;</p>