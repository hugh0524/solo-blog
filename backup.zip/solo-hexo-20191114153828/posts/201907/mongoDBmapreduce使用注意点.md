title: mongoDB map reduce使用注意点
date: '2019-07-04 15:09:31'
updated: '2019-07-04 15:10:48'
tags: [mongo, web, 前端, mongodb, map, reduce]
permalink: /articles/2019/07/04/1562224171165.html
---
<p>1. 问题原因</p>
<p>当前时间段内只有一条记录， 经过reduce预处理时并没有进入，导致变量未正确赋值</p>
<p>在finalize中发现变量不存在，导致程序异常</p>
<p>&nbsp;</p>
<p>2. 原因</p>
<p>参考<a href="https://blog.uproject.cn/articles/2019/06/13/1560396099637.html" style="font-size: 1.5em;">mapreduce使用的坑 - mac reduce对数据集进行汇总计算时，出现数据样本不全的</a><span style="font-size: 1.5em;">问题</span></p>
<p><span style="font-size: 1.5em;">map reduce 执行过程中， 如果只有一条记录不会进入reduce，但是会进入finalize</span></p>
<p><span style="font-size: 1.5em;">&nbsp;</span></p>
<p><span style="font-size: 1.5em;">3. 处理</span></p>
<p><span style="font-size: 1.5em;">在finalize中对这种情况单独处理， 返回该条数据项</span></p>
<p><span style="font-size: 1.5em;">4. 修改原文code如下</span></p>
<p>&nbsp;</p>
<pre class="prettyprint">o.finalize = function(key, rval) {
            function financial(x) {
                return Number.parseFloat(x).toFixed(2);
            }
            // fix 只有一条记录时的bug
            if(!result[key]) {
                return { dns: rval.dns, tcp:rval.tcp &gt;&gt; 0, ssl:rval.ssl &gt;&gt; 0, ttfb:rval.ttfb &gt;&gt; 0, trans:rval.trans &gt;&gt; 0, dom:rval.dom &gt;&gt; 0, res:rval.res &gt;&gt; 0, firstbyte:rval.firstbyte &gt;&gt; 0,fpt:rval.fpt &gt;&gt; 0,tti:rval.tti &gt;&gt; 0,ready:rval.ready &gt;&gt; 0, load:rval.load &gt;&gt; 0}
            }
            var sum = result[key].reduce((cur,item) =&gt; {
                return {dns: (item.dns &gt;&gt; 0) + cur.dns,
                    tcp:(item.tcp&gt;&gt; 0) + cur.tcp,
                    ssl:(item.ssl&gt;&gt; 0) + cur.ssl,
                    ttfb:(item.ttfb&gt;&gt; 0) + cur.ttfb,
                    trans:(item.trans&gt;&gt; 0) + cur.trans,
                    dom:(item.dom&gt;&gt; 0) + cur.dom,
                    res:(item.res&gt;&gt; 0) + cur.res,
                    firstbyte:(item.firstbyte&gt;&gt; 0) + cur.firstbyte,
                    fpt:(item.firstbyte&gt;&gt; 0) + cur.firstbyte,
                    tti:(item.tti&gt;&gt; 0) + cur.tti,
                    ready:(item.ready&gt;&gt; 0) + cur.ready,
                    load:(item.load&gt;&gt; 0) + cur.load,
                    total: item.total + cur.total
                }
            }, {total:0, dns: 0, tcp:0, ssl:0, ttfb:0, trans:0, dom:0, res:0,firstbyte:0,fpt:0,tti:0,ready:0, load:0})
            var len = sum.total;
            var sumTotal = {total: len, dns: financial(sum.dns/len), tcp:financial(sum.tcp/len), ssl:financial(sum.ssl/len), ttfb:financial(sum.ttfb/len), trans:financial(sum.trans/len), dom:financial(sum.dom/len),
                   res:financial(sum.res/len),firstbyte:financial(sum.firstbyte/len),fpt:financial(sum.fpt/len),tti:financial(sum.tti/len),ready:financial(sum.ready/len), load:financial(sum.load/len)}

            return sumTotal
        }
</pre>
<p><span style="font-size: 1.5em;">&nbsp;</span></p>
<p><span style="font-size: 1.5em;">&nbsp;</span></p>