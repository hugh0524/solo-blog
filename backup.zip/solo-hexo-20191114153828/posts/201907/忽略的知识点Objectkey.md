title: 忽略的知识点-Object key
date: '2019-07-04 10:01:52'
updated: '2019-07-04 10:01:52'
tags: [symbol, object, keys, js, js_base, 前端, web]
permalink: /articles/2019/07/04/1562205712090.html
---
<p>起因：</p>
<pre class="prettyprint">const obj = {1: "a", 2: "b"}

console.log(obj["1"]) // a
console.log(obj[1]) // a
</pre>
<p>根据MDN中关于object构造器的描述</p>
<blockquote>
<pre class="line-numbers language-html"><code class=" language-html">// 对象初始化器（Object initialiser）或对象字面量（literal）
{ [ nameValuePair1[, nameValuePair2[, ...nameValuePairN] ] ] }</code></pre>
<p><code>nameValuePair1, nameValuePair2, ... nameValuePairN</code>成对的名称（字符串）与值（任何值），其中名称通过冒号与值分隔。</p>
</blockquote>
<p>键值会被存放为字符串类型(除symbol外)</p>
<p>范例：</p>
<pre class="prettyprint">var b = {}
b[1] = 1;
b["2"] = 2;
b[{c:3}] = 3
b[{e:4}] = 4
b[Symbol("f")] = 5

for(var i in b){
   console.log(Object.prototype.toString.call(i))// [object String] * 3
}</pre>
<p>Q1： 为什么结果只输出了三个</p>
<p>A1: Symbol作为键时，无法被遍历器遍历， 只能通过特定函数获取&nbsp;Object.getOwnPropertySymbols(b)</p>
<p>同时因为{c:3}、{e:4}同时被转换成String -&gt; '[object String]'存储, 所以只有三个输出</p>