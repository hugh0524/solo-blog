title: 利用sourceMap库还原错误堆栈
date: '2019-07-20 17:09:55'
updated: '2019-07-21 10:10:15'
tags: [js, sourceMap, fe_monitor, web, 前端, 前端错误监控, 监控]
permalink: /articles/2019/07/18/1563414926541.html
---
<p>前端监控中， js错误是一项至关重要的监控点及指标，只要包含收集及解析阶段</p>
<p>&nbsp;<a href="http://tools.uproject.cn/upload/article/1563461482238.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/1563461482238.jpg" alt="" width="500" height="407" /></a></p>
<p>由于sourcemap和源文件生成各有不同的策略</p>
<h2>1.源文件构建</h2>
<p>1. 将hash生成到文件名中</p>
<p>该方式可以直接在监控平台读取源文件对应的sourcemap保存， 在解析时使用</p>
<p>2. 将hash或时间戳放到文件url search中</p>
<p>该方式需要在监控平台对url进行处理，将search中的参数加入到文件名进行保存</p>
<p>3. 没有使用hash或时间戳</p>
<p>这种情况就需要客户端上报错误时，加上版本号，构建时将sourcemap文件上传到服务器， 解析时获取对应版本的文件即可</p>
<h2>2.&nbsp;<a href="https://www.webpackjs.com/configuration/devtool/#devtool" target="_blank">sourcemap</a>生成</h2>
<p>sourcemap生成在webpack中有多种配置， 但是功效有细微差异</p>
<p>在生产环境， 我们是不能暴露sourcemap文件的</p>
<p>为保证安全同时又可以还原错误堆栈 有以下方式</p>
<p>方法一. 将sourcemap文件在构建时上传到服务器，然后删除即可</p>
<p>方法二. 在服务器端使用nginx等代理服务器，对文件做访问限制，只可监控服务器访问即可</p>
<p>&nbsp;</p>
<h2>3. 如何使用<a href="https://github.com/mozilla/source-map#sourcemapconsumerprototypesourcecontentforsource-returnnullonmissing" target="_blank">sourcemap</a>库进行堆栈还原</h2>
<p>上报的错误堆栈内容如下</p>
<pre class="prettyprint">[{"url":"https://blog.uproject.cn/static/js/app.c95d3bd2ec81c488ba30.js","func":"registerEventHandler","args":[],"line":29,"column":12174},<br />{"url":"https://blog.uproject.cn/static/js/app.c95d3bd2ec81c488ba30.js","func":"onEvent","args":[],"line":32,"column":26680}]</pre>
<p>&nbsp;解析流程如下</p>
<p><a href="http://tools.uproject.cn/upload/article/1563613132275.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/1563613132275.jpg" alt="" width="500" height="366" /></a></p>
<p>1. 根据sourcemap创建SourceMapCustomer对象</p>
<pre class="prettyprint">var smc = await new sourceMap.SourceMapConsumer(mapfileData);</pre>
<p>2. 根据每行堆栈信息获取源文件及错误行和列</p>
<pre class="prettyprint">var po = smc.originalPositionFor({
                        line: line,
                        column: column
                    });
console.log(po)// line: 1, column:200, source: xxx.js</pre>
<p>3. 根据源文件内容及行列获取源文件信息</p>
<pre class="prettyprint"> var co = smc.sourceContentFor(po.source)
// co 包含了源文件所有的源码  
var coList = co.split("\n")
// 按需取行即可</pre>
<p>4. 将内容展示在监控平台</p>
<p><a href="http://tools.uproject.cn/upload/article/1563613734124.jpg" class="fancybox" data-fancybox-group="group"><img src="http://tools.uproject.cn/upload/article/1563613734124.jpg" alt="" width="500" height="339" /></a>&nbsp;</p>
<p>&nbsp;</p>