title: 忽略的知识点- fetch发送cors请求
date: '2019-07-11 19:19:06'
updated: '2019-07-11 19:19:06'
tags: [xhr, fetch, web, 前端, js_base]
permalink: /articles/2019/07/11/1562843911424.html
---
<p>1. fetch 发送cors请求</p>
<p>为了让浏览器发送包含凭据的请求（即使是跨域源），要将credentials: 'include'添加到传递给 fetch()方法的init对象。</p>
<pre class="prettyprint">fetch('https://example.com', {
  credentials: 'include'  
})
</pre>
<p>&nbsp;</p>
<p>2. xhr发送cor请求</p>
<pre class="brush: java">const invocation = new XMLHttpRequest();
const url = 'http://example.com/';
   
if (invocation) {    
  invocation.open('GET', url, true);
  invocation.withCredentials = true;  
  invocation.onreadystatechange = function(){};
  invocation.send(); 
}
</pre>