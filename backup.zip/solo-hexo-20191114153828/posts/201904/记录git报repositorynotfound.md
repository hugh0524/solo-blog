title: 【记录】- git报repository not found
date: '2019-04-23 15:38:04'
updated: '2019-04-23 15:38:04'
tags: [git, cerdential, respository]
permalink: /articles/2019/04/23/1556005055176.html
---
<p>1. 原因</p>
<p>电脑里原先使用git的用户，存储了自己的用户名密码， 导致再次输入时不需要再输。 同时原用户有被注销了权限</p>
<p>这时候报错如下</p>
<pre class="prettyprint">$ git clone http:/xxx.git
Cloning into 'api'...
remote: Not Found
fatal: repository 'http://xxx.git/' not found</pre>
<p>2. 解决方法</p>
<pre class="brush: java">git credential-manager uninstall
git credential-manager install</pre>