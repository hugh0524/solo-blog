title: MAC下将命令加入到系统
date: '2019-09-12 10:11:03'
updated: '2019-09-12 10:11:03'
tags: [shell, bash]
permalink: /articles/2019/09/12/1568254262948.html
---
<p>Flutter + zsh为例</p>
<p>下载的flutter有个bin目录， 将该目录挂载到path下即可</p>
<p>打开home下.zshrc文件</p>
<p>将flutter地址写入</p>
<pre class="brush: bash">export PATH="$PATH:$HOME/Desktop/flutter/bin"</pre>
<p>执行source命令更新</p>
<pre class="brush: bash">source .zshrc</pre>
<p>使用echo $PATH检查是否正确加入到path即可</p>